const babel = require('babel-core');
const fs = require('fs');

const result = babel.transformFileSync('./public/img/gz-vue/icons/icons-symbol.src.js', {
    minified: true
}).code;

fs.writeFileSync('./public/img/gz-vue/icons/icons-symbol.js', result, 'UTF-8');
