<template lang="pug">
    .doc__main
        doc-header
            h2 {{api.title}}
            span.fn-right &nbsp;&nbsp;Author: {{api.author}}
            template(slot="desc") {{api.description}}
        section.section__body.example
            h2.section__title Example
            slot
        doc-api(:api="api")
        doc-footer
</template>
<script>
    export default {
        props: ['api'],
        mounted() {
            this.$emit('view', {
                title: `${this.api.title} Component`,
                description: this.api.description,
                keywords: `gzvue, ${this.api.title}, components`
            });
        }
    };
</script>
