<template lang="pug">
    header.doc__header
        div.fn-clear
            slot
        div
            slot(name="desc")
</template>
