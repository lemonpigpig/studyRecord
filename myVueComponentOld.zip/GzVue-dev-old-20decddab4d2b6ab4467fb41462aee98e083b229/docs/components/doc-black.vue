<template lang="pug">
    div.doc__page
        doc-side
        .doc__main
            slot
            doc-footer
</template>