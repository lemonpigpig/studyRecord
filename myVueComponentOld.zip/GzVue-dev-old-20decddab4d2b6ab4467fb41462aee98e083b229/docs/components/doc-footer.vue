<template lang="pug">
    footer.doc__footer &copy; 2017&nbsp;
        a(href="http://gznb.com" target="_blank") gznb.com&nbsp;
        | 国资商城 Powered by GZ FE TEAM • GZ Vue {{version}} •
        span.ft-gray {{time}}ms
</template>
<script>
    import packageInfo from '../../package.json';

    export default {
        data() {
          return  {
              time: 0,
              version: '0.1.0'
          }
        },
        mounted() {
            this.version = packageInfo.version;

            // TODO: 在该周期内 querySelector 获取不到 #app 外的内容
            var it = this;
            setTimeout(() => {
                var time = document.querySelector('#time')
                it.time = ` ${time.textContent}`;
            }, 100)
        }
    }
</script>