<template lang="pug">
  section.section__body(v-if="api.props || api.slots || api.events || api.functional")
    h2.section__title API
    .tabs(v-if="api.props || api.slots || api.events || api.functional")
      .tabs__header(ref="tabs")
        .tab__title(v-if="api.props" class="tab__title--active" @click="setCurrentTab('tabsProps', $event)") Props
        .tab__title(v-if="api.slots" @click="setCurrentTab('tabsSlots', $event)") Slots
        .tab__title(v-if="api.events" @click="setCurrentTab('tabsEvents', $event)") Events
        .tab__title(v-if="api.functional" @click="setCurrentTab('tabsFunctional', $event)") Functional
        .tabs__slider(ref="slider")
      .tabs__items.gz-content(ref="contents")
        .tab__content(v-if="api.props" id="tabsProps")
          doc-api-parameters(":titles"="propHeaders" ":parameters"="api.props")
        .tab__content(v-if="api.slots" class="fn-none" id="tabsSlots")
          doc-api-parameters(":titles"="slotHeaders" ":parameters"="api.slots")
        .tab__content(v-if="api.events" class="fn-none" id="tabsEvents")
          doc-api-parameters(":titles"="eventHeaders" ":parameters"="api.events")
        .tab__content(v-if="api.functional" class="fn-none" id="tabsFunctional")
          doc-api-parameters(":titles"="functionalHeaders" ":parameters"="api.functional")
</template>
<script>
export default {
  data () {
    return {
      propHeaders: ['Option', 'Type(s)', 'Default', 'Description'],
      slotHeaders: ['Name', 'Description'],
      functionalHeaders: ['Name', 'Class'],
      eventHeaders: ['Name', 'Description'],
    }
  },
  props: ['api'],
  mounted () {
    if (this.api.props || this.api.slots || this.api.events || this.api.functional) {
      this.init();
    }
  },
  methods: {
    init () {
      this.$refs.tabs.childNodes.forEach((e, index) => {
        if (index === 0) this.slider(e);
      });
    },
    setCurrentTab (id, event) {
      this.$refs.tabs.childNodes.forEach((e) => {
        if (e.className !== 'tabs__slider') {
          e.className = 'tab__title';
        }
      });

      event.target.className = 'tab__title tab__title--active';
      this.slider(event.target);

      this.$refs.contents.childNodes.forEach((e) => {
        if (e.id === id) {
          e.className = 'tab__content';
        } else {
          e.className = 'tab__content fn-none';
        }
      });
    },
    slider (el) {
      this.$refs.slider.style.width = `${el.clientWidth}px`;
      this.$refs.slider.style.left = `${el.offsetLeft}px`;
    },
  }
}
</script>
