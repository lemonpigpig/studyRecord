const title = state => state.title;
const keywords = state => state.keywords;
const description = state => state.description;

export default {
    title,
    keywords,
    description,
};
