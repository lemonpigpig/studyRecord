<template lang="pug">
    .form(v-loading.three.fullscreen="isLoading")
        button(@click='loading') 开始加载
</template>

<script>
    export default {
        data() {
            return {
                isLoading: true
            };
        },
        methods: {
            loading() {
                this.isLoading = true;
            }
        },
        mounted() {
            setTimeout(() => {
                this.isLoading = false;
            }, 5000);
        }
    };
</script>
<style lang="stylus" scoped>
    @import "../../../stylus/_theme-sky";

    .form
        padding 10px

        button
            cursor: pointer;
            color: #fff;
            border-radius: 3px;
            padding: 6px 12px;
            background-color: $theme.primary.base;
            width: 100%;
            line-height: 20px;
            white-space: nowrap;
            border: 0;
            margin-bottom: 10px;
</style>
