export default {
    title: 'v-dpr',
    description: '根据 dpr 自动适配存在的 @nx 图片',
    author: '李丽媛-Vanessa'
}
