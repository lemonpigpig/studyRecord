<template lang="pug">
    doc-view(":api"="api")
        doc-example(file="directives/dpr/1" title="Directive")
        doc-example(file="directives/dpr/2" title="Load")
        doc-example(file="directives/dpr/3" title="CSS")
        doc-code.
            @import "../../../../src/stylus/mixin/_dpr";

            .dpr-demo
                height 200px
                width 200px
                dpr('/public/img/vue.png')
                background-size contain
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            api: api
        }
    }
}
</script>

<style lang="stylus">
    @import "../../../../src/stylus/mixin/_dpr";

    .dpr-demo
        height 200px
        width 200px
        dpr('/public/img/vue.png')
        background-size contain
</style>
