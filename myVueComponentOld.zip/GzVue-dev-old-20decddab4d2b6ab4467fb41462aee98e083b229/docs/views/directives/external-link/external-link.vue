<template>
<doc-view :api="api">
  <div class="" data-url="http://www.baidu.com" v-externalLink>


  </div>
</doc-view>
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            api: api
        }
    },

}
</script>
