export default {
    title: 'v-externalLink',
    description: '判断是否为第三方外链，如果是则调用webview的openUrl方法进行跳转',
    author: '贺贤娟-lemon',
    props: {
        'v-externalLink': [
            [
                'data-url',
                'String',
                '-',
                '需要进行判断的url链接'
            ]
        ]
    }
}
