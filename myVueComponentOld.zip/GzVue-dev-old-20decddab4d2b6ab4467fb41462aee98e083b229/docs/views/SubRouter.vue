<template lang="pug">
    div.doc__page
        doc-side
        router-view
</template>

