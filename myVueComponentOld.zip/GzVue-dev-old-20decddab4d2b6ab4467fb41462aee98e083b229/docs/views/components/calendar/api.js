export default {
  author: '邓斌-Bean',
  title: 'Calendar',
  description: '日历组件',
  props: {
    'gz-calendar': [
      [
        'chooseDateType',
        'number',
        '0',
        '选择日期的类型，0: 开始日期，1: 结束日期'
      ],
      [
        'availableStartDate',
        'string',
        '今天',
        '可用日期的开始日期，默认为今天，如"2017-04-20"'
      ],
      [
        'availableEndDate',
        'string',
        '',
        '可用日期的结束日期，默认没有，设置该值会无视下面的availableDaysCount'
      ],
      [
        'availableDaysCount',
        'number',
        '-1',
        '可用日期的数量，未设置时availableEndDate时用于计算availableEndDate'
      ],
      [
        'initStartDate',
        'string',
        'null',
        '初始化选择的开始日期，如"2017-04-19"'
      ],
      [
        'initEndDate',
        'string',
        'null',
        '初始化选择的结束日期，如"2017-04-28"'
      ],
      [
        'startDateLabel',
        'string',
        '开始日期',
        '开始日期下面的文字'
      ],
      [
        'endDataLabel',
        'string',
        '结束日期',
        '结束日期下面的文字'
      ],
    ]
  },
  events: {
    'gz-calendar': [
      [
        'selectDate',
        'function',
        '选择的日期，格式如"2017-04-19"'
      ]
    ]
  }
}