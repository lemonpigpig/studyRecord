<template lang="pug">
	doc-view(":api"="api")
		doc-example(src="components/picker/1" title="demo1" width="320")
		doc-example(src="components/picker/2" title="demo2" width="320")
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            api: api
        }
    }
}
</script>
