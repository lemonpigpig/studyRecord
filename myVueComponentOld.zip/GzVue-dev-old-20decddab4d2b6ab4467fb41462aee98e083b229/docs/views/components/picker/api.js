export default {
    title: 'PICKER-V2',
    description: 'picker选择组件',
    author: '贺贤娟-lemon',
    props: {
        'gz-picker-v2': [
            [
                'value',
                'String',
                '默认为第一个',
                '默认选中的值'
            ],
            [
                'slots',
                'Array',
                '[]',
                'slots对象数组，决定渲染的列数'
            ],
            [
                'valueKey',
                'String',
                '-',
                '渲染时选择对象里面的那个key作为页面显示名称'
            ],
            [
                'showToolbar',
                'false',
                '是否显示工具栏'
            ],
            [
                'visibleItemCount',
                'Number',
                "5",
                '每个slot里面显示item的个数'
            ],
            [
                'itemHeight',
                'Number',
                "36",
                '每个slot的高度'
            ],
            [
                'filter',
                'Oject',
                "{}",
                '图片过滤器'
            ],
            [
                'lazyComponent',
                'Boolean',
                "false",
                '是否懒加载组件'
            ],
            [
              'change',
              'Function',
              '-',
              'slotchange的时候执行'
            ]
        ]
    },

}
