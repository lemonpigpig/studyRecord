<template lang="pug">
    doc-view(":api"="api")
        doc-example(src="components/popover/1" title="示例" width="320")
        doc-example(src="components/popover/2" title="白色主题" width="320")
</template>

<script>
    import api from './api';

    export default {
        data() {
            return {
                api: api
            };
        }
    };
</script>
