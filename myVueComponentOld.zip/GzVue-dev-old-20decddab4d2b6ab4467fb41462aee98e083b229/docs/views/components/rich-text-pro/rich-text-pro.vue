<template lang="pug">
doc-view(:api="api")
	doc-example(src="components/rich-text-pro/demo", title="普通富文本", width="100%")
</template>

<script>
import api from './api';

export default {
  data() {
    return  {
      example1data: {
      },
      api: api,
    }
  }
}
</script>
