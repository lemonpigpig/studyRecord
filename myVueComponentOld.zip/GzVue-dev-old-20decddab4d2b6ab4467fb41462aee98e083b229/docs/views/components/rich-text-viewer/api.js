export default {
    title: 'RichTextViewer',
    author: '张锐-Ken',
    description: '富文本展示组件',
    props: {
        'RichTextViewer': [
            [
                'contents',
                'Object || Array',
                '-',
                '组件中显示的文本内容',
            ],
            [
                'nodeClass',
                'Object',
                '-',
                '给不同类型的组件设置class',
            ],
            [
                'type',
                'String',
                'normal(default) | pro',
                '区分 viewer 对应的 rich-text 类型',
            ]
        ]
    },
};
