<template>
    <gz-rich-text-viewer
        :contents="contents"
        @img-jump-to="imgJumpToHandler"
        type="pro">
    </gz-rich-text-viewer>
</template>
<script>
export default {
    computed: {
        contentsString() {
            return JSON.stringify(this.contents, null, 2);
        },
    },
    data() {
        return {
            contents: {
                gridColumn: 12,
                gridData: [{
                    "columns": [{
                        "id": 1,
                        "span": 10,
                        "class": "bg-green",
                        "content": {
                            "mode": "1",
                            "content": "一级标题真厉害",
                            "type": "header"
                        }
                    }],
                    "editing": false
                }, {
                    "columns": [{
                        "id": 2,
                        "span": 5,
                        "class": "border-green",
                        "content": {
                        "mode": "2",
                        "content": "三级标题真厉害",
                        "type": "header"
                        }
                    }],
                    "editing": false
                }, {
                    "columns": [{
                        "id": 3,
                        "span": 4,
                        "content": {
                            "mode": "ul",
                            "content": [
                                "无序1",
                                "无序2",
                                "无序3"
                            ],
                            "type": "list"
                        }
                    }],
                    "editing": false
                }, {
                    "columns": [{
                        "id": 4,
                        "span": 4,
                        "content": {
                            "mode": "4",
                            "content": "四级标题真厉害",
                            "type": "header"
                        }
                    }],
                    "editing": false
                },
                {
                    "columns": [{
                        "id": 5,
                        "span": 7,
                        "content": {
                            "content": "11111111111111111111\n2222222222222222222\n3333333333333\n4444444444444444444444\n555555555555\n66666666666666666\n7777777777\n8888888888888",
                            "type": "paragraph"
                        }
                    }, {
                        "id": 6,
                        "span": 3,
                        "content": {
                            "content": {
                                imgURL: "https://www.google.com.hk/logos/doodles/2017/marie-harels-256th-birthday-5737545781477376-s.png",
                                linkType: "URL",
                                linkValue: "/components"
                            },
                            "type": "image"
                        }
                    }],
                    "editing": false
                }],
            },
            allowClasses: [{
                tag: 'border-green',
                displayName: '绿色边框'
            }, {
                tag: 'border-red',
                displayName: '红色边框'
            }, {
                tag: 'border-blue',
                displayName: '蓝色边框'
            }, {
                tag: 'bg-green',
                displayName: '绿色背景'
            }, {
                tag: 'bg-red',
                displayName: '红色背景'
            }, {
                tag: 'bg-blue',
                displayName: '蓝色背景'
            }]
        };
    },
    methods: {
        imgJumpToHandler({ imgURL, linkURL }) {
            alert(`点击了图片:${imgURL},\n将要跳转到:${linkURL}`)
        },
    },
};
</script>
<style lang="stylus">
*
    box-sizing: border-box

.gz-rich-text-viewer-pro
    width: 100%;
    position: relative;

    .gz-rich-text-viewer-row
        position: relative
        width: 100%;

        &:after
            content: ''
            display: table
            clear: both

        .gz-rich-text-viewer-col
            position: relative
            border: 1px dashed #eee
            color: #333
            line-height: 40px
            font-weight: bolder
            background-color: #fff
            float: left
            min-height: 80px

.border-green
    border-color: green !important

.border-red
    border-color: red !important

.border-blue
    border-color: blue !important

.bg-green
    background-color: RGBA(0, 193, 139, .7) !important

.bg-red
    background-color: RGBA(246, 65, 10, .7) !important

.bg-blue
    background-color: RGBA(0, 112, 156, 1.00) !important

</style>
