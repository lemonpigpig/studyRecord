<template lang="pug">
doc-view(:api="api")
    doc-example(file="components/notify/1",title="通知组件")
    button(@click="showNotify") 显示Notify
</template>

<script>
import api from './api';

export default {
  data() {
    return  {
      api: api
    }
  },
  methods: {
      showNotify() {
          console.log(this)
          this.$notify({
              message: '显示一段 notify',
          });
      },
  },
}
</script>
