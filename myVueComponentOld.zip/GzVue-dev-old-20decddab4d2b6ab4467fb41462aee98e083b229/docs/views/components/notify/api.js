export default {
    title: 'Notify',
    author: '张锐-Ken',
    description: 'show a notify.',
    props: {
        notify: [
            ['duration', 'Number', '-', '设定 notify 悬停的时间'],
            ['message', 'String', '-', 'Notify 显示的文本'],
            ['customClass', 'Array', '-', '自定义 class']
        ],
    },
}
