export default {
    author: '李丽媛-Vanessa',
    title: 'Icons',
    props: {
        'icon': [
            [
                'color',
                'string',
                '#34495e',
                '图标颜色'
            ],
            [
                'size',
                'string',
                '-',
                '图片大小：medium | large | x-large | size (eg: 160, 高宽160px) | width height（eg: 196 60, 宽193px 高60px）'
            ],
            [
                'icon',
                'string',
                '-',
                '图标名称，参见 http://10.66.30.40:1024/public/img/gz-vue/icons/demo.html'
            ],
            [
                'class-name',
                'string',
                '',
                '图标 class'
            ]
        ]
    }
}
