export default {
    author: '邓斌-Bean',
    title: 'Slider',
    description: '轮播组件',
    props: {
        'options': [
            [
                'height',
                'String',
                '-',
                '高度，例如 "400px"'
            ],
            [
                'width',
                'String',
                '-',
                '宽度，例如 "100%"'
            ],
            [
                'showPreNextButton',
                'Boolean',
                'false',
                '是否显示上一页、下一页'
            ],
            [
                'showPagination',
                'Boolean',
                'true',
                '是否显示下方页码'
            ],
            [
                'paginationClickable',
                'Boolean',
                'false',
                '页码区域是否可点击'
            ],
            [
                'loop',
                'Boolean',
                'true',
                '是否开启循环'
            ],
            [
                'autoplay',
                'Integer',
                '-',
                '自动播放间隔，不传为不自动播放'
            ],
            [
                'lazyLoading',
                'Boolean',
                'true',
                '是否开启懒加载图片'
            ],
            [
                'reInitializeWhenUpdate',
                'Boolean',
                'true',
                '更新时是否初始化'
            ],
            [
                'direction',
                'String',
                '\'horizontal\'',
                '轮播方向，horizontal为横向，vertical为纵向'
            ]
        ],
        'items': [
            [
                'url',
                'String',
                '-',
                '点击跳转的地址'
            ],
            [
                'customClickData',
                'Object',
                'null',
                '自定义Click事件参数，有值的情况下，click之后会触发customClick事件，并返回customClickData的值'
            ],
            [
                'background',
                'String',
                '-',
                '背景图片地址'
            ]
        ]
    }
}
