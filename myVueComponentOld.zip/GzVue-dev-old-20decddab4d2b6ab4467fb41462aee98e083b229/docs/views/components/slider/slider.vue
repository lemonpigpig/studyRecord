<template lang="pug">
    doc-view(":api"="api")
        doc-example(src="components/slider/1" width="100%" title="demo")
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            api: api
        };
    },
};
</script>
