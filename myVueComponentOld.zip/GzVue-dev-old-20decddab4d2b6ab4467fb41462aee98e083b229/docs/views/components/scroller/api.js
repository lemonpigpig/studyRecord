export default {
  author: '邓斌-Bean',
  title: 'Scroller',
  description: '滑动组件',
  props: {
    'options': [
      [
        'height',
        'String',
        '-',
        '高度，例如 "400px"'
      ],
      [
        'width',
        'String',
        '-',
        '宽度，例如 "100%"'
      ],
      [
        'direction',
        'String',
        '\'horizontal\'',
        '轮播方向，horizontal为横向，vertical为纵向'
      ]
    ]
  }
}