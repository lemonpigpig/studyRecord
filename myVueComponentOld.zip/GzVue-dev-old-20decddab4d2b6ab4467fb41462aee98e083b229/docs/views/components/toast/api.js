export default {
    author: '李丽媛-Vanessa',
    title: 'Toast - 轻提示',
    description: '一种轻量级反馈/提示，可以用来显示不会打断用户操作的内容，适合用于页面转场、数据交互的等场景中',
    props: {
        'toast': [
            [
                'content',
                'string',
                '',
                '提示内容'
            ],
            [
                'duration',
                'int',
                '2000',
                '自动关闭的延时，单位毫秒'
            ],
            [
                'mask',
                'boolean',
                'false',
                '是否显示透明蒙层，防止触摸穿透'
            ],
            [
                'type',
                'string',
                'info',
                '提示类型：info | warn | error | fail | success | loading | offline'
            ],
            [
                'onClose',
                'function',
                '-',
                '关闭后回调函数'
            ]
        ]
    }
}
