<template lang="pug">
    .form
        button(@click='toast') 默认提示
        button(@click='warnToast') 带 mask 的警告提示
        button(@click='errorToast') 带回调函数的错误提示
        button(@click='failToast') duration 为 6000ms 的失败提示
        button(@click='loadingToast') 加载提示
        button(@click='offlineToast') 离线提示
        button(@click='successToast') 成功提示
        button(@click='destoryToast') 销毁
</template>

<script>
    export default {
        methods: {
            toast() {
                this.$toast({
                    content: 'info toast'
                });
            },
            warnToast() {
                this.$toast({
                    type: 'warn',
                    mask: true,
                    content: 'warn toast: has mask'
                });
            },
            errorToast() {
                this.$toast({
                    type: 'error',
                    content: 'error toast: has callback',
                    onClose: () => {
                        alert('error toast callback');
                    }
                });
            },
            failToast() {
                this.$toast({
                    type: 'fail',
                    content: 'fail toast: duration 6000',
                    duration: 6000
                });
            },
            loadingToast() {
                this.$toast({
                    type: 'loading',
                    content: 'loading toast'
                });
            },
            offlineToast() {
                this.$toast({
                    type: 'offline',
                    content: 'offline toast'
                });
            },
            successToast() {
                this.$toast({
                    type: 'success',
                    content: 'success toast'
                });
            },
            destoryToast() {
                this.$toast.prototype.destroy();
            }
        }
    };
</script>
<style lang="stylus" scoped>
    @import "../../../stylus/_theme-sky";

    .form
        padding 10px

        button
            cursor: pointer;
            color: #fff;
            border-radius: 3px;
            padding: 6px 12px;
            background-color: $theme.primary.base;
            width: 100%;
            line-height: 20px;
            white-space: nowrap;
            border: 0;
            margin-bottom: 10px;
</style>
