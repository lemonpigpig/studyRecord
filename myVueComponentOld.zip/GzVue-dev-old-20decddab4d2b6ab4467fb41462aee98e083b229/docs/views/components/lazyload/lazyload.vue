<template lang="pug">
	doc-view(":api"="api")
		doc-example(file="components/lazyload/1" ":data"="example1data")
		doc-example(file="components/lazyload/2" ":data"="example2data")
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            example1data: {

                lists: [{
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test1.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    }, {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test2.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test3.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test4.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test5.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test6.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test7.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test8.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test9.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test10.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test11.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test12.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    },
                    {
                        src: 'http://hilongjw.github.io/vue-lazyload/dist/test12r.jpg',
                        error: "http://hilongjw.github.io/vue-lazyload/dist/404.png",
                        loading: "http://cdn.uehtml.com/201402/1392662524764_1140x0.gif"
                    }
                ]
            },
            example2data: {
                src: 'http://hilongjw.github.io/vue-lazyload/dist/test11.jpg'
            },
            api: api
        }
    }
}
</script>
