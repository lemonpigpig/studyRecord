const demo = [
    { path: '/components/calendar/1', component: require('../views/components/calendar/1.vue') },
    { path: '/components/calendar/2', component: require('../views/components/calendar/2.vue') },
    { path: '/components/datetime-picker/1', component: require('../views/components/datetime-picker/1.vue') },
    { path: '/components/loadmore/1', component: require('../views/components/loadmore/1.vue') },
    { path: '/components/picker/1', component: require('../views/components/picker/1.vue') },
    { path: '/components/picker/2', component: require('../views/components/picker/2.vue') },
    { path: '/components/popover/1', component: require('../views/components/popover/1.vue') },
    { path: '/components/popover/2', component: require('../views/components/popover/2.vue') },
    { path: '/components/rich-text/demo', component: require('../views/components/rich-text/demo.vue') },
    { path: '/components/rich-text-pro/demo', component: require('../views/components/rich-text-pro/demo.vue') },
    { path: '/components/rich-text-viewer/demo', component: require('../views/components/rich-text-viewer/demo.vue') },
    { path: '/components/rich-text-viewer/demo1', component: require('../views/components/rich-text-viewer/demo1.vue') },
    { path: '/components/slider/1', component: require('../views/components/slider/1.vue') },
    { path: '/components/toast/1', component: require('../views/components/toast/1.vue') },
    { path: '/components/uploader/1', component: require('../views/components/uploader/1.vue') },
    { path: '/directives/loading/1', component: require('../views/directives/loading/1.vue') },
    { path: '/directives/loading/2', component: require('../views/directives/loading/2.vue') },
    { path: '/directives/loading/3', component: require('../views/directives/loading/3.vue') },
];
const components = [
    { path: 'calendar', component: require('../views/components/calendar/calendar.vue') },
    { path: 'datetime-picker', component: require('../views/components/datetime-picker/datetime-picker.vue') },
    { path: 'gallery', component: require('../views/components/gallery/gallery.vue') },
    { path: 'icons', component: require('../views/components/icons/icons.vue') },
    { path: 'lazyload', component: require('../views/components/lazyload/lazyload.vue') },
    { path: 'loadmore', component: require('../views/components/loadmore/loadmore.vue') },
    { path: 'notify', component: require('../views/components/notify/notify.vue') },
    { path: 'picker', component: require('../views/components/picker/picker.vue') },
    { path: 'popover', component: require('../views/components/popover/popover.vue') },
    { path: 'rich-text', component: require('../views/components/rich-text/rich-text.vue') },
    { path: 'rich-text-pro', component: require('../views/components/rich-text-pro/rich-text-pro.vue') },
    { path: 'rich-text-viewer', component: require('../views/components/rich-text-viewer/rich-text-viewer.vue') },
    { path: 'scroller', component: require('../views/components/scroller/scroller.vue') },
    { path: 'slider', component: require('../views/components/slider/slider.vue') },
    { path: 'toast', component: require('../views/components/toast/toast.vue') },
    { path: 'uploader', component: require('../views/components/uploader/uploader.vue') },
    { path: 'zoom-preview', component: require('../views/components/zoom-preview/zoom-preview.vue') },
];
const directives = [
    { path: 'dpr', component: require('../views/directives/dpr/dpr.vue') },
    { path: 'external-link', component: require('../views/directives/external-link/external-link.vue') },
    { path: 'loading', component: require('../views/directives/loading/loading.vue') },
];
export default {
    demo,
    components,
    directives
};