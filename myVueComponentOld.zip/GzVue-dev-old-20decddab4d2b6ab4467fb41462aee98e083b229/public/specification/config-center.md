# 使用

## 前往配置中心进行配置

* 配置方法：[GZ 配置中心官方文档](http://10.66.2.13/InfrastructureTeam/mozart/tree/master/config)
* 配置文件：[各环境配置模版](http://10.66.2.13/FrontEndTeam/GzVue/tree/dev/src/zookeeper/template)

## 添加配置项

* 项目根目录下添加 [ecosystem.json](http://10.66.2.13/FrontEndTeam/GzVue/blob/dev/src/zookeeper/template/ecosystem.json)
* `/build` 下添加 `server.js` 文件

```
require(`./server.${process.env.NODE_ENV}`);
```

* 修改 CI 命令

```
yarn && yarn build && pm2 start ecosystem.json --env test
```
 
`注`： 
* env 可为 test/dev, 默认为 production
* 请确保 `yarn.lock` 中已包含 `zookeeper`
* 需要在同一台服务器上运行多个环境时，可创建多个 `ecosystem[.dev|.test|.pre|.prd].json`，修改其 `name` 及对应的启动命令即可
## 获取配置数据

* 使用 pm2 启动后，会自动生产 `config/config-center.json` 文件。所有配置项可到该文件中获取。

```
try {
    configCenter = require('./config/config-center.json');
} catch (e) {
    fs.writeFileSync('./config/config-center.json', '{}'.toString('utf8'), 'UTF-8');
}
```

# 介绍

请移步 [GZ 官方文档](http://10.66.2.13/InfrastructureTeam/mozart/tree/master/config)

## 使用技术

* [ZooKeeper](http://zookeeper.apache.org/)

> ZooKeeper is a centralized service for maintaining configuration information, naming, providing distributed synchronization, and providing group services. All of these kinds of services are used in some form or another by distributed applications. Each time they are implemented there is a lot of work that goes into fixing the bugs and race conditions that are inevitable. Because of the difficulty of implementing these kinds of services, applications initially usually skimp on them ,which make them brittle in the presence of change and difficult to manage. Even when done correctly, different implementations of these services lead to management complexity when the applications are deployed.

## 配置中心

开发环境运维平台地址：[http://10.66.30.95:8086/console](http://10.66.30.95:8086/console)

账号：admin

密码：gznb@1234
