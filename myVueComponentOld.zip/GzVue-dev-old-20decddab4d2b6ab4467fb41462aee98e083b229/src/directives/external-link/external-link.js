import url from 'url';

export default {
    inserted: (el, binding) => {
        const jumpUrl = binding.value;
        if (global.gzNative && global.gzNative.openUrl) {
	        el.addEventListener('click', () => {
		        const host = jumpUrl ? url.parse(jumpUrl).host : '';
		        if (host) global.gzNative.openUrl({ url: jumpUrl });
	        });
        } else {
	        console.error('please require gz-native.js');
        }
    },
    bind() {
        // console.log('bind');
    },
    componentUpdated() {
        // console.log('componentUpdated');
    }
};
