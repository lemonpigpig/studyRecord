<template>
    <div class="gz-uploader-progress"
         :style="{backgroundImage:`url('${backgroundDataUrl}')`}">
        <div class="progress-mask"
             v-if="!success"
             :style="{height:(100-progress)+'%'}">
            <div class="upload-error"
                 v-if="error"
                 @click="startUpload">
                <div>上传失败</div>
                <div>请点击重新上传</div>
            </div>
            <div class="progress-info"
                 v-if="progress<80 && !error ">图片上传{{progress}}%</div>
        </div>
        <div class="bottom-area"
             v-if="success"
             @click="bottomClicked">
            <div v-if="isPrimary">主图</div>
            <div v-if="!isPrimary">设为主图</div>
        </div>
        <div class="delete-button"
             @click="deleteClicked"></div>
    </div>
</template>

<script>
import base64toBlob from '../../utilities/base64-to-blob';

export default {
    name: 'gz-uploader-progress',
    author: '邓斌-Bean',
    title: '上传进度组件',
    props: {
        index: Number,
        dataURL: String,
        serverUrl: String,
        isPrimary: Boolean,
        needUpload: {
            type: Boolean,
            default() {
                return true;
            }
        }
    },
    data() {
        return {
            progress: 0,
            error: false,
            success: false
        };
    },
    computed: {
        backgroundDataUrl() {
            if (this.needUpload && this.dataURL.indexOf(',') < 0) {
                return 'data:image/jpeg;base64,' + this.dataURL;
            }
            return this.dataURL;
        }
    },
    methods: {
        bottomClicked() {
            this.$emit('setPrimary', this.index);
        },
        deleteClicked() {
            this.$emit('delete', this.index);
        },
        startUpload(isFirstTime, serverUrl) {
            if (this.needUpload) {
                if (!isFirstTime) {
                    this.$emit('reUpload', this.index);
                    return;
                }
                this.$set(this, 'error', false);
                let base64String = this.dataURL;
                if (base64String.indexOf(',') > 0) {
                    base64String = base64String.split(',')[1];
                }
                const blob = base64toBlob(base64String, 'image/jpeg');
                const data = new FormData();
                data.append('files', blob, 'image.jpg');
                const xhr = new XMLHttpRequest();
                xhr.addEventListener('progress', this.uploadProgress);
                xhr.addEventListener('error', this.uploadError);
                xhr.addEventListener('abort', this.uploadAbort);
                xhr.addEventListener('load', this.uploadComplete);
                xhr.open('POST', serverUrl || this.serverUrl);
                xhr.send(data);
            }
            else {
                this.$set(this, 'success', true);
            }
        },
        uploadProgress(e) {
            if (e.lengthComputable) {
                const progress = parseInt((100 * e.loaded) / e.total, 10);
                this.$set(this, 'progress', progress);
            }
        },
        uploadComplete(e) {
            if (e.target.status === 200) {
                const response = JSON.parse(e.target.response);
                this.$set(this, 'success', true);
                this.$emit('done', {
                    index: this.index,
                    url: response[0].file
                });
            } else {
                this.$set(this, 'progress', 0);
                this.$set(this, 'error', true);
                this.$emit('error', {
                    index: this.index,
                    status: e.target.status
                });
            }
        },
        uploadError() {
            this.$set(this, 'progress', 0);
            this.$set(this, 'error', true);
            this.$emit('error', {
                index: this.index
            });
        },
        uploadAbort() {
            this.$set(this, 'progress', 0);
            this.$set(this, 'error', true);
            this.$emit('abort', {
                index: this.index
            });
        }
    },
    mounted() {
        if (this.needUpload) {
            this.startUpload(true);
        }
        else {
            this.$set(this, 'progress', 100);
            this.$set(this, 'success', true);
        }
    }
};
</script>

<style lang="less">
.gz-uploader-progress {
    width: 100%;
    height: 100%;
    background-color: #f8f8f8;
    background-repeat: no-repeat;
    background-position: center;
    background-size: cover;
    position: relative;
    .progress-mask {
        position: absolute;
        left: 0;
        bottom: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.6);
        display: flex;
        align-items: center;
        justify-content: center;
        .progress-info {
            color: #fff;
        }
        .upload-error {
            width: 100%;
            height: 100%;
            color: #fff;
            background-color: rgba(251, 72, 18, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            div {
                font-size: 12px;
                line-height: 150%;
            }
        }
    }
    .bottom-area {
        position: absolute;
        bottom: 0;
        width: 100%;
        height: 20%;
        background-color: rgba(0, 0, 0, 0.5);
        color: #fff;
        text-align: center;
        display: flex;
        justify-content: center;
        div {
            display: flex;
            align-items: center;
            justify-content: center;
        }
    }
    .delete-button {
        position: absolute;
        left: -10%;
        top: -10%;
        height: 20%;
        width: 20%;
        background-color: #fff;
        border-radius: 50%;
        background-image: url("close.svg");
        background-size: contain;
        background-repeat: no-repeat;
        background-position: center;
    }
}
</style>
