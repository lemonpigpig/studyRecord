<template>
    <div class="gz-uploader"
         @click="uploaderClicked">
        <input ref="fileInput"
               v-if="inputType===0"
               type="file"
               :multiple="multiple"
               @change="fileInputChanged">
        <div class="bottom-area">
            <span>上传图片</span>
        </div>
    </div>
</template>

<script>
import { readAsDataURL } from '../../utilities/file-reader-promise';

export default {
    name: 'gz-uploader',
    author: '邓斌-Bean',
    title: '上传组件',
    props: {
        multiple: {
            type: Boolean,
            default: true
        },
        inputType: {
            type: Number,
            default: 0
        }
    },
    methods: {
        uploaderClicked() {
            if (this.inputType === 0) {
                this.$refs.fileInput.click();
            } else if (this.multiple) {
                global.gzNative.selectMultiplePhotos().then((result) => {
                    for (let i = 0; i < result.imageDatas.length; i++) {
                        result.imageDatas[i] = 'data:image/jpg;base64,' + result.imageDatas[i].replace(/\n/g, "");
                    }
                    this.$emit('select', result.imageDatas);
                });
            }
            else {
                global.gzNative.selectPhoto().then((result) => {
                    result.imageData = 'data:image/jpg;base64,' + result.imageData.replace(/\n/g, "");
                    this.$emit('select', result.imageData);
                });
            }
        },
        fileInputChanged(event) {
            const selectedFiles = event.target.files;
            const results = [];
            const readers = [];
            for (let i = 0; i < selectedFiles.length; i += 1) {
                readers.push(readAsDataURL(selectedFiles[i]).then((result) => {
                    results.push(result);
                }));
            }
            Promise.all(readers).then(() => {
                this.$emit('select', results);
            });
        }
    }
};
</script>

<style lang="less">
.gz-uploader {
    width: 100%;
    height: 100%;
    background-color: #333;
    background-image: url(camera-add.svg);
    background-repeat: no-repeat;
    background-position: center;
    background-size: 40%;
    position: relative;
    input {
        display: none;
    }
    .bottom-area {
        position: absolute;
        bottom: 0;
        width: 100%;
        height: 20%;
        background-color: rgba(0, 0, 0, 0.5);
        color: #fff;
        text-align: center;
        display: flex;
        justify-content: center;
        span {
            display: flex;
            align-items: center;
            justify-content: center;
        }
    }
}
</style>
