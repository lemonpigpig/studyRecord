import Popover from './popover.vue';


Popover.install = (Vue) => {
    Vue.component(Popover.name, Popover);
};

export default Popover;
