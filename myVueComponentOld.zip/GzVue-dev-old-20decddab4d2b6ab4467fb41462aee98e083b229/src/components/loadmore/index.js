import Loadmore from './loadmore.vue';

Loadmore.install = (Vue) => {
    Vue.component(Loadmore.name, Loadmore);
};

export default Loadmore;
