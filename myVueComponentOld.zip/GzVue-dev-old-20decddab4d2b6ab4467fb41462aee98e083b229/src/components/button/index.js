import GzButton from './button.vue';

GzButton.install = (Vue) => {
    Vue.component(GzButton.name, GzButton);
};

export default GzButton;
