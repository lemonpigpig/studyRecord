<template>
    <div class="gz-rich-text-paragraph">
        <label class="label" for="">{{label}}</label>
        <div class="btns">
            <button @click.stop="removeNode">&times;</button>
        </div>
        <textarea class="content" rows="8" @input="inputHandler" :value="content"></textarea>
    </div>
</template>

<script>
import BasePlugin from './gz-rich-text-base';

export default {
    extends: BasePlugin,
    name: 'gz-rich-text-paragraph',
    props: {
        id: Number,
        content: String
    },
    data() {
        return {
            label: '段落'
        };
    },
    methods: {
        getInitData() {
            return {
                content: ''
            };
        }
    }
};
</script>

<style lang="less">
.gz-rich-text-paragraph {
    box-sizing: border-box;
    position: relative;
    width: 100%;
    margin-bottom: 10px;
    border: 1px solid #aaa;
    border-radius: 6px;

    .label {
        box-sizing: border-box;
        position: absolute;
        width: 90px;
        height: 100%;
        z-index: 1;
        text-align: center;
        padding: 4px;
        background-color: #f8f8f8;
        border-right: 1px solid #e8e8e8;
        border-radius: 6px 0 0 6px;
    }
    .content {
        box-sizing: border-box;
        position: relative;
        width: 100%;
        display: block;
        padding: 8px 8px 8px 98px;
        border-radius: 6px;
        z-index: 0;
        resize: none;
        border: 0;
    }
    .btns {
        width: 30px;
        height: 100%;
        position: absolute;
        z-index: 1;
        right: 0;
        background-color: #f8f8f8;
        border-radius: 0 6px 6px 0;
        border-left: 1px solid #e8e8e8;

        button {
            width: 30px;
            height: 100%;
            display: inline-block;
            border-radius: 6px;
            background-color: transparent;
            border: 0;
        }
    }
}
</style>
