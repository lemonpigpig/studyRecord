<template>
    <div class="gz-rich-text-list">
        <select class="mode" @change="changeMode">
            <option v-for="option in modeOptions" :value="option.value" :selected="option.value === mode">{{option.text}}{{label}}</option>
        </select>
        <div class="triangle"></div>
        <div class="btns">
            <button @click.stop="removeNode">&times;</button>
        </div>
        <div class="input-group" v-for="(row, index) in content">
            <div class="prefix" @click="removeRow(index)">-</div>
            <input class="content" :value="row" @input="changeRow(index, $event)"/>
        </div>
        <div class="input-group add">
            <div class="prefix" @click="addRow">+</div>
            <input class="content" v-model="newRow" @keypress.enter="addRow" placeholder="创建新行"/>
        </div>
    </div>
</template>

<script>
import BasePlugin from './gz-rich-text-base';

export default {
    extends: BasePlugin,
    name: 'gz-rich-text-list',
    props: {
        id: Number,
        mode: String,
        content: Array
    },
    data() {
        return {
            label: '列表',
            modeOptions: [{
                value: 'ol',
                text: '有序'
            }, {
                value: 'ul',
                text: '无序'
            }],
            newRow: ''
        };
    },
    methods: {
        getInitData() {
            return {
                mode: 'ul',
                content: []
            };
        },
        addRow() {
            const newRow = this.newRow;
            this.$set(this, 'newRow', '');
            this.$emit('input', [this.id, [...this.content, newRow]]);
        },
        removeRow(index) {
            this.$emit('input', [this.id, this.content.filter((r, i) => i !== index)]);
        },
        changeRow(index, e) {
            this.$emit('input', [this.id, this.content.map((r, i) => i === index ? e.target.value : r)]);
        },
    }
};
</script>

<style lang="less">
.gz-rich-text-list {
    box-sizing: border-box;
    position: relative;
    width: 100%;
    margin-bottom: 10px;
    border: 1px solid #aaa;
    border-radius: 6px;

    .mode {
        width: 90px;
        height: 100%;
        position: absolute;
        z-index: 1;
        border-radius: 0;
        border-radius: 6px 0 0 6px;
        -webkit-appearance: none;
        border-width: 0 1px 0 0;
        border-style: solid;
        border-color: #e8e8e8;
        background: #f8f8f8;
        padding: 0 8px;
    }
    .triangle {
        width: 0;
        height: 0;
        top: 50%;
        margin-top: -4px;
        left: 75px;
        position: absolute;
        display: block;
        border-style: solid;
        border-width: 5px 4px 0 4px;
        border-color: #666 transparent transparent transparent;
        z-index: 2;
    }
    .input-group {
        padding-left: 90px;
        border-bottom: 1px solid #eee;
        position: relative;

        .prefix {
            position: absolute;
            width: 16px;
            height: 16px;
            top: 50%;
            margin: -9px 4px 0;
            z-index: 1;
            text-align: center;
            background-color: #ff0000;
            color: #fff;
            line-height: 14px;
            border-radius: 50%;
        }
        .content {
            box-sizing: border-box;
            position: relative;
            width: 100%;
            display: block;
            padding: 8px 8px 8px 26px;
            border-radius: 6px;
            z-index: 0;
            border: 0;
        }

        &.add {
            .prefix {
                background-color: #fff;
                color: #666;
            }
        }
    }
    .btns {
        position: absolute;
        width: 30px;
        height: 100%;
        z-index: 1;
        right: 0;
        background-color: #f8f8f8;
        border-radius: 0 6px 6px 0;
        border-left: 1px solid #e8e8e8;

        button {
            width: 30px;
            height: 100%;
            display: block;
            border-radius: 6px;
            background-color: transparent;
            border: 0;
        }
    }
}
</style>
