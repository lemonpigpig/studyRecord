<template>
    <div class="gz-rich-text-image">
        <label class="label">{{label}}</label>
        <div class="btns">
            <button @click.stop="removeNode">&times;</button>
        </div>
        <div class="preview">
            <img :src="imgURL" @click="imgClickHandelr">
            <div class="input-group">
                <input type="text" class="content" @keypress.entry="inputHandler" @blur="inputHandler" :value="content">
            </div>
        </div>
    </div>
</template>

<script>
import BasePlugin from './gz-rich-text-base';
import defaultImage from '../default-bg.svg';

export default {
    extends: BasePlugin,
    name: 'gz-rich-text-image',
    props: {
        id: Number,
        content: String
    },
    data() {
        return {
            label: '图片'
        };
    },
    computed: {
        imgURL() {
            return (this.content && this.content !== '') ? this.content : defaultImage;
        }
    },
    methods: {
        getInitData() {
            return {
                content: ''
            };
        },
        imgClickHandelr(e) {
            this.$emit('img-click', [e, this.id]);
        }
    }
};
</script>

<style lang="less">
.gz-rich-text-image {
    box-sizing: border-box;
    position: relative;
    width: 100%;
    margin-bottom: 10px;
    border: 1px solid #aaa;
    border-radius: 6px;

    .label {
        box-sizing: border-box;
        position: absolute;
        width: 90px;
        height: 100%;
        z-index: 1;
        text-align: center;
        padding: 4px;
        background-color: #f8f8f8;
        border-right: 1px solid #e8e8e8;
        border-radius: 6px 0 0 6px;
    }

    .preview {
        margin: 0 30px 0 90px;
        text-align: center;
        position: relative;

        .input-group {
            position: absolute;
            bottom: 0;
            height: 35px;
            width: 100%;

            .save-btn {
                position: absolute;
                right: 0;
                z-index: 1;
                height: 100%;
                background-color: #fff;
                border: 0;
            }

            .content {
                box-sizing: border-box;
                position: relative;
                width: 100%;
                display: block;
                padding: 8px 8px 8px 8px;
                height: 35px;
                border-radius: 0px;
                z-index: 0;
                border: 0;
                background-color: rgba(255, 255, 255, 0.6);

                &:active, &:focus {
                    background-color: #fff;
                }
            }
        }

        img {
            width: 100%;
            display: block;
            background-color: #d8d8d8;
        }
    }

    .btns {
        position: absolute;
        width: 30px;
        height: 100%;
        z-index: 1;
        right: 0;
        background-color: #f8f8f8;
        border-radius: 0 6px 6px 0;
        border-left: 1px solid #e8e8e8;

        button {
            width: 30px;
            height: 100%;
            display: block;
            border-radius: 6px;
            background-color: transparent;
            border: 0;
        }
    }

}
</style>
