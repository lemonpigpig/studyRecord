<template>
    <div class="gz-rich-text-header">
        <select class="mode" @change="changeMode">
            <option v-for="option in modeOptions" :value="option.value" :selected="option.value === mode">{{option.text}}{{label}}</option>
        </select>
        <div class="triangle"></div>
        <div class="btns">
            <button @click.stop="removeNode">&times;</button>
        </div>
        <input class="content" @input="inputHandler" :value="content" />
    </div>
</template>

<script>
import BasePlugin from './gz-rich-text-base';

export default {
    extends: BasePlugin,
    name: 'gz-rich-text-header',
    props: {
        id: Number,
        mode: String,
        content: String
    },
    data() {
        return {
            label: '标题',
            modeOptions: [{
                value: '1',
                text: '一级'
            }, {
                value: '2',
                text: '二级'
            }, {
                value: '3',
                text: '三级'
            }, {
                value: '4',
                text: '四级'
            }, {
                value: '5',
                text: '五级'
            }]
        };
    },
    methods: {
        getInitData() {
            return {
                mode: '1',
                content: ''
            };
        }
    }
};
</script>

<style lang="less">
.gz-rich-text-header {
    box-sizing: border-box;
    position: relative;
    width: 100%;
    margin-bottom: 10px;
    border: 1px solid #aaa;
    border-radius: 6px;

    .mode {
        width: 90px;
        height: 100%;
        position: absolute;
        z-index: 1;
        border-radius: 6px 0 0 6px;
        -webkit-appearance: none;
        border-width: 0 1px 0 0;
        border-style: solid;
        border-color: #e8e8e8;
        background: #f8f8f8;
        padding: 0 8px;
    }
    .triangle {
        width: 0;
        height: 0;
        top: 50%;
        margin-top: -4px;
        left: 75px;
        position: absolute;
        display: block;
        border-style: solid;
        border-width: 5px 4px 0 4px;
        border-color: #666 transparent transparent transparent;
        z-index: 2;
    }

    .content {
        box-sizing: border-box;
        position: relative;
        width: 100%;
        display: block;
        padding: 8px 8px 8px 98px;
        border-radius: 6px;
        z-index: 0;
        resize: none;
        border: 0;
    }
    .btns {
        position: absolute;
        width: 30px;
        height: 100%;
        z-index: 1;
        right: 0;
        background-color: #f8f8f8;
        border-radius: 0 6px 6px 0;
        border-left: 1px solid #e8e8e8;

        button {
            width: 30px;
            height: 100%;
            display: block;
            border-radius: 6px;
            background-color: transparent;
            border: 0;
        }
    }
}
</style>
