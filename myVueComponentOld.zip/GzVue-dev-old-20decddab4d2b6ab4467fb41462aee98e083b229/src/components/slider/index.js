import GzSlider from './slider.vue';

GzSlider.install = (Vue) => {
    Vue.component(GzSlider.name, GzSlider);
};

export default GzSlider;
