import ZoomPreview from './zoom-preview.vue';


ZoomPreview.install = (Vue) => {
    Vue.component(ZoomPreview.name, ZoomPreview);
};

export default ZoomPreview;
