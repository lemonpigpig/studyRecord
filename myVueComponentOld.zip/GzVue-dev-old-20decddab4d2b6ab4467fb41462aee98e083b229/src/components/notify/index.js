import Vue from 'vue';
import NotifyConstructor from './notify.vue';

const NotifyComponent = Vue.extend(NotifyConstructor);

let instance = null;

const Notify = (opt) => {
    let options = opt;

    if (Vue.prototype.$isServer) return;

    if (typeof (options) === 'undefined') {
        if (!instance) return;
        instance.destroy({}, true);
        instance = null;
        return;
    }

    if (typeof (options) === 'string') {
        options = {
            message: options
        };
    }

    if (instance) {
        instance.destroy({}, true);
    }
    instance = new NotifyComponent({
        data: {
            message: options.message,
            duration: options.duration
        }
    });
    instance.vm = instance.$mount();
    document.body.appendChild(instance.vm.$el); // eslint-disable-line no-undef
    instance.vm.$on('allDone', () => {
        instance = null;
    });
};

Notify.prototype.clear = () => {
    if (!instance) return;
    instance.destroy({}, true);
    instance = null;
};

Notify.install = () => {
    Vue.prototype.$notify = Notify;
};

export default Notify;
