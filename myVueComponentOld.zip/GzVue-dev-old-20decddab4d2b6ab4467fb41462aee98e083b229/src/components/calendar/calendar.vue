<template>
    <div class="gz-calendar">
        <div class="week-name-row">
            <div class="week-name">日</div>
            <div class="week-name">一</div>
            <div class="week-name">二</div>
            <div class="week-name">三</div>
            <div class="week-name">四</div>
            <div class="week-name">五</div>
            <div class="week-name">六</div>
        </div>
        <div class="calendar-area" ref="wrapper">
            <div class="month-area" ref="month"
                 v-for="monthPlusNumber in monthsCount">
                <div class="month-name">
                    {{ getMonthName(monthPlusNumber-1) }}
                </div>
                <div class="month-data">
                    <div class="month-week-row"
                         v-for="weekNumber in getMonthWeeks(monthPlusNumber-1)">
                        <div class="day-cell"
                             :class="{ 'active':isDayCellActive(monthPlusNumber-1,weekNumber-1,dayNumber-1),
                         	           'disabled-active':isDayCellDisabledActive(monthPlusNumber-1,weekNumber-1,dayNumber-1),
                         	           'disabled':!(isDayCellAvailable(monthPlusNumber-1,weekNumber-1,dayNumber-1) && isCanBook(monthPlusNumber-1,weekNumber-1,dayNumber-1)),
                                       'price-data':showPrice,
                                       'stock-data':showStock}"
                             v-for="dayNumber in 7"
                             @click="clickDate(monthPlusNumber-1,weekNumber-1,dayNumber-1)">
                            <div class="is-today" v-if="isToday(monthPlusNumber-1,weekNumber-1,dayNumber-1)">今天</div>
                            <div class="day-number"
                                 :class="{'is-weekend':isWeekend(monthPlusNumber-1,weekNumber-1,dayNumber-1)}">
                                {{ getDayNumberForShow(monthPlusNumber-1,weekNumber-1,dayNumber-1) }}
                            </div>
                            <div class="day-price" v-if="showPrice">
                                {{ getDayPriceForShow(monthPlusNumber-1,weekNumber-1,dayNumber-1) }}
                            </div>
                            <div class="day-stock" v-if="showStock">
                                {{ getDayStockForShow(monthPlusNumber-1,weekNumber-1,dayNumber-1) }}
                            </div>
                            <div class="label-bottom"
                                 v-if="isStartDate(monthPlusNumber-1,weekNumber-1,dayNumber-1)">
                                {{ startDateLabel }}
                            </div>
                            <div class="label-bottom"
                                 v-if="isEndDate(monthPlusNumber-1,weekNumber-1,dayNumber-1)">
                                {{ endDateLabel }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="calendar-btn" v-if="isPopup">
            <div class="confirm-btn" @click="confirmDate">确定</div>
        </div>
    </div>
</template>

<script>
	import moment from 'moment';

	export default {
		name: 'gz-calendar',
		author: '邓斌-Bean',
		title: '日历组件',
		props: {
			singleChoose: {
				type: Boolean,
				default: false
			},
			chooseDateType: {
				type: Number,
				default: 0
			},
			startDateLabel: {
				type: String,
				default: '开始日期'
			},
			endDateLabel: {
				type: String,
				default: '结束日期'
			},
			unavailableDays: {
				type: Array,
				default() {
					return [];
				}
			},
			availableStartDate: {
				type: String,
				default() {
					return moment().format('YYYY-MM-DD');
				}
			},
			availableEndDate: {
				type: String,
				default: null
			},
			availableDaysCount: {
				type: Number,
				default: -1
			},
			initStartDate: {
				type: String,
				default: null
			},
			initEndDate: {
				type: String,
				default: null
			},
			priceData: {
				type: Array,
				default: () => [],
			},
		},
		data() {
			return {
				startDate: '',
				endDate: '',
				selectedMonthPlus: -1,
				selectedWeekIndex: -1,
				selectedDayIndex: -1,
				ignoreInitDate: false
			};
		},
		mounted() {
			const selectMonth = this.chooseDateType === 0 ? this.initStartDate : this.initEndDate;
			const selectMonthNum = moment(selectMonth).year() - moment().year();
			let dirScrollTop = 0;
			let accuMonths = moment(selectMonth).month() + 1 + 12 * selectMonthNum - this.currentMonthNumber;
			for (let i = 0; i < accuMonths; i+=1) {
				dirScrollTop+= this.$refs.month[i].clientHeight;
			}
			this.$refs.wrapper.scrollTop = dirScrollTop;
		},
		computed: {
			currentMonthIndex() {
				return moment().month();
			},
			currentMonthNumber() {
				return moment().month() + 1;
			},
			currentYearNumber() {
				return moment().year();
			},
			monthsCount() {
				const availableEndMoment = this.getAvailableEndMoment();
				if (!availableEndMoment) {
					return 1;
				}

				const endYear = availableEndMoment.year();
				const endMonth = availableEndMoment.month();
				return ((((endYear - this.currentYearNumber) * 12) + endMonth)
					- this.currentMonthIndex) + 1;
			},
			showPrice() {
				return this.priceData.length && this.priceData.some(item => item.price !== undefined || item.adultPrice !== undefined);
			},
			showStock() {
				return this.priceData.length && this.priceData.some(item => item.inventory !== undefined);
			},
			isPopup() {
				return !(this.showPrice && this.showStock);
			},
		},
		methods: {
			clickDate(monthPlus, weekIndex, dayIndex) {
				if (this.isDayCellAvailable(monthPlus, weekIndex, dayIndex) && this.isCanBook(monthPlus, weekIndex, dayIndex)) {
					const year = this.getYearNumber(monthPlus);
					const monthIndex = this.getMonthIndex(monthPlus);
					const dayNumber = this.getDayNumber(monthPlus, weekIndex, dayIndex);
					const date = moment([year, monthIndex, dayNumber]);
					this.$set(this, 'selectedMonthPlus', monthPlus);
					this.$set(this, 'selectedWeekIndex', weekIndex);
					this.$set(this, 'selectedDayIndex', dayIndex);
					this.$set(this, 'ignoreInitDate', true);
					if (!this.isPopup) this.confirmDate();
				}
			},
			confirmDate() {
				if (this.selectedMonthPlus !== -1) {
					const year = this.getYearNumber(this.selectedMonthPlus);
					const monthIndex = this.getMonthIndex(this.selectedMonthPlus);
					const dayNumber = this.getDayNumber(this.selectedMonthPlus, this.selectedWeekIndex, this.selectedDayIndex);
					const date = moment([year, monthIndex, dayNumber]);
					this.$emit('selectDate', date.format('YYYY-MM-DD'));
				} else if (this.chooseDateType === 0) {
					this.$emit('selectDate', this.initStartDate);
				} else {
					this.$emit('selectDate', this.initEndDate);
				}
			},
			getMonthName(monthPlus) {
				return `${this.getYearNumber(monthPlus)}年${this.getMonthNumber(monthPlus)}月`;
			},
			getMonthIndex(monthPlus) {
				return (this.currentMonthIndex + monthPlus) % 12;
			},
			getMonthNumber(monthPlus) {
				return this.getMonthIndex(monthPlus) + 1;
			},
			getYearNumber(index) {
				return this.currentYearNumber + parseInt((this.currentMonthIndex + index) / 12, 10);
			},
			getMonth(monthPlus) {
				const year = this.getYearNumber(monthPlus);
				const monthIndex = this.getMonthIndex(monthPlus);
				return moment([year, monthIndex]);
			},
			getMonthDays(monthPlus) {
				const month = this.getMonth(monthPlus);
				return month.daysInMonth();
			},
			getMonthWeeks(monthPlus) {
				const month = this.getMonth(monthPlus);
				const monthDays = this.getMonthDays(monthPlus);
				if (month.day() === 0 && monthDays === 28) {
					return 4;
				}
				if (monthDays - 28 - (7 - month.day()) > 0) {
					return 6;
				}
				return 5;
			},
			formatPrice(price) {
				return price !== undefined ? `￥${Math.floor(price)}` : '';
			},
			formatStock(stock) {
				if (stock !== undefined) {
					return stock < 5 ? (stock === 0 ? '已订完' : '紧张') : `剩${stock}位`;
				}
				return '';
			},
			getPriceData(monthPlus, weekIndex, dayIndex) {
				const year = this.getYearNumber(monthPlus);
				const month = this.getMonthIndex(monthPlus) + 1;
				const day = this.getDayNumber(monthPlus, weekIndex, dayIndex);
				return this.priceData.length && this.priceData.find(item => item.year === year && item.month === month && item.day === day);
			},
			getDayPriceForShow(monthPlus, weekIndex, dayIndex) {
				if (this.isDayCellAvailable(monthPlus, weekIndex, dayIndex)) {
					const data = this.getPriceData(monthPlus, weekIndex, dayIndex);
					return data ? (data.isCanBook ? this.formatPrice(data.price || data.adultPrice) : '不可订') : '';
				}
				return '';
			},
			getDayStockForShow(monthPlus, weekIndex, dayIndex) {
				if (this.isDayCellAvailable(monthPlus, weekIndex, dayIndex)) {
					const data = this.getPriceData(monthPlus, weekIndex, dayIndex);
					return data ? (data.isCanBook ? this.formatStock(data.inventory) : '') : '';
				}
				return '';
			},
			getDayNumberForShow(monthPlus, weekIndex, dayIndex) {
//				if (this.isToday(monthPlus, weekIndex, dayIndex)) {
//					return '今天';
//				}
				return this.getDayNumber(monthPlus, weekIndex, dayIndex);
			},
			getDayNumber(monthPlus, weekIndex, dayIndex) {
				const month = this.getMonth(monthPlus);
				const dayOfFirstDay = month.day();
				const monthDays = this.getMonthDays(monthPlus);
				const dayNumber = (((weekIndex * 7) + dayIndex) - dayOfFirstDay) + 1;

				if (dayNumber > 0 && dayNumber <= monthDays) {
					return dayNumber;
				}
				return '';
			},
			getDate(monthPlus, weekIndex, dayIndex) {
				const monthIndex = this.getMonthIndex(monthPlus);
				const year = this.getYearNumber(monthPlus);
				const month = this.getMonth(monthPlus);
				const dayOfFirstDay = month.day();
				const dayNumber = (((weekIndex * 7) + dayIndex) - dayOfFirstDay) + 1;
				return moment([year, monthIndex, dayNumber]);
			},
			getAvailableStartMoment() {
				return moment(this.availableStartDate);
			},
			getAvailableEndMoment() {
				const availableStartMoment = this.getAvailableStartMoment();
				let availableEndMoment;

				if (this.availableEndDate) {
					availableEndMoment = moment(this.availableEndDate);
				} else if (this.availableDaysCount >= 0) {
					availableEndMoment = availableStartMoment.clone().add(this.availableDaysCount - 1, 'day');
				}
				return availableEndMoment;
			},
			isDayCellActive(monthPlus, weekIndex, dayIndex) {
				if (monthPlus === this.selectedMonthPlus &&
					weekIndex === this.selectedWeekIndex && dayIndex === this.selectedDayIndex) {
					return true;
				}
				if (!this.ignoreInitDate && this.chooseDateType === 0 && this.initStartDate) {
					const date = this.getDate(monthPlus, weekIndex, dayIndex);
					const initSelected = moment(this.initStartDate);
					if (date.isSame(initSelected, 'day')) {
						return true;
					}
				}
				if (!this.ignoreInitDate && this.chooseDateType === 1 && this.initEndDate) {
					const date = this.getDate(monthPlus, weekIndex, dayIndex);
					const initSelected = moment(this.initEndDate);
					if (date.isSame(initSelected, 'day')) {
						return true;
					}
				}
				return false;
			},
			isDayCellDisabledActive(monthPlus, weekIndex, dayIndex) {
				if (this.chooseDateType === 1 && this.initStartDate) {
					const date = this.getDate(monthPlus, weekIndex, dayIndex);
					const initSelected = moment(this.initStartDate);
					if (date.isSame(initSelected, 'day')) {
						return true;
					}
				}
				return false;
			},
			isStartDate(monthPlus, weekIndex, dayIndex) {
				const date = this.getDate(monthPlus, weekIndex, dayIndex);
				if (this.chooseDateType === 0 && this.isDayCellActive(monthPlus, weekIndex, dayIndex)) {
					return true;
				}
				if (this.chooseDateType === 1 && date.isSame(this.initStartDate, 'day')) {
					return true;
				}
				return false;
			},
			isEndDate(monthPlus, weekIndex, dayIndex) {
				if (this.isDayCellActive(monthPlus, weekIndex, dayIndex) && this.chooseDateType === 1) {
					return true;
				}
				return false;
			},
			isDayCellAvailable(monthPlus, weekIndex, dayIndex) {
				const date = this.getDate(monthPlus, weekIndex, dayIndex);
				const availableStartMoment = this.getAvailableStartMoment();
				const availableEndMoment = this.getAvailableEndMoment();
				if (availableEndMoment && date.isSameOrAfter(availableStartMoment, 'day') && date.isSameOrBefore(availableEndMoment)) {
					return true;
				}
				if (!availableEndMoment && date.isSameOrAfter(availableStartMoment, 'day')) {
					return true;
				}
				return false;
			},
			isCanBook(monthPlus, weekIndex, dayIndex) {
				if (this.showPrice) {
					const data = this.getPriceData(monthPlus, weekIndex, dayIndex);
					if (data && data.isCanBook) {
						const isPriceValid = !!this.getDayPriceForShow(monthPlus, weekIndex, dayIndex);
						const isStockValid = !!this.getDayStockForShow(monthPlus, weekIndex, dayIndex) && data.inventory > 0;
						return this.showStock ? isStockValid && isPriceValid : isPriceValid;
					}
					return false;
				}
				return true;
			},
			isToday(monthPlus, weekIndex, dayIndex) {
				const date = this.getDate(monthPlus, weekIndex, dayIndex);
				if (date.isSame(moment(), 'day')) {
					return true;
				}
				return false;
			},
			isWeekend(monthPlus, weekIndex, dayIndex) {
				const date = this.getDate(monthPlus, weekIndex, dayIndex);
				if (date.isoWeekday() > 5) {
					return true;
				}
				return false;
			}
		}
	};
</script>

<style lang='less'>
    .gz-calendar {
        width: 100%;
        height: 100%;
        position: absolute;
        .week-name-row {
            padding: 20px;
            display: flex;
            justify-content: space-between;
            border-bottom: 1px solid #dddddd;
            .week-name {
                text-align: center;
                width: 30px;
                font-size: 14px;
                padding: 12px 0;
            }
        }
        .calendar-area {
            width: 100%;
            position: absolute;
            top: 120px;
            bottom: 140px;
            overflow-x: hidden;
            overflow-y: scroll;
            -webkit-overflow-scrolling: touch;
            .month-area {
                padding: 20px;
                &:first-child {
                    border-top: none;
                }
                border-top: 1px solid #dddddd;
                .month-name {
                    font-size: 24px;
                    margin-top: 40px;
                    padding: 10px 0;
                    color: #333;
                }
                .month-week-row {
                    display: flex;
                    justify-content: space-between;
                    .day-cell {
                        display: flex;
                        flex-direction: column;
                        justify-content: center;
                        align-items: center;
                        width: 40px;
                        font-size: 14px;
                        line-height: 40px;
                        height: 40px;
                        /*border-radius: 50%;*/
                        margin: 8px 0;
                        color: #333;
                        user-select: none;
                        cursor: pointer;
                        position: relative;
                        &.disabled {
                            color: #b0b0b0;
                            .day-price, .day-stock {
                                color: #b0b0b0;
                            }
                            .is-weekend {
                                color: #fb8c8c;
                            }
                        }
                        &.active {
                            background-color: #ff4847;
                            .day-number, .day-price, .day-stock {
                                color: #fff;
                            }
                            .label-bottom {
                                color: #ff4847;
                            }
                        }
                        &.disabled-active {
                            background-color: #b0b0b0;
                            .day-number {
                                color: #fff;
                            }
                            .label-bottom {
                                color: #b0b0b0;
                            }
                        }
                        .is-today {
                            position: absolute;
                            top: -40%;
                            font-size: 12px;
                            line-height: normal;
                            color: #4a4a4a;
                        }
                        .is-weekend {
                            color: #ff4847;
                        }
                        .label-top {
                            position: absolute;
                            left: 50%;
                            width: 200%;
                            transform: translateX(-50%);
                            top: -16px;
                            color: #4a4a4a;
                            font-size: 12px;
                            line-height: 16px;
                            text-align: center;
                        }
                        .label-bottom {
                            position: absolute;
                            left: 50%;
                            width: 200%;
                            transform: translateX(-50%);
                            bottom: -16px;
                            color: #4a4a4a;
                            font-size: 12px;
                            line-height: 16px;
                            text-align: center;
                        }
                        .day-price {
                            min-height: 16.5px;
                            font-size: 12px;
                            color: #666666;
                        }
                        .day-stock {
                            min-height: 14px;
                            font-size: 10px;
                            color: #666666;
                        }
                        &.price-data {
                            height: 50px;
                            width: 50px;
                            line-height: normal;
                            /*border-radius: 0;*/
                            .is-today {
                                top: -50%;
                            }
                            &.stock-data {
                                margin: 0;
                                height: 60px;
                                width: 60px;
                                .is-today {
                                    top: -35%;
                                }
                            }
                        }
                    }
                }
            }
        }
        .calendar-btn {
            width: 100%;
            height: 140px;
            position: absolute;
            bottom: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #ffffff;
            border-top: solid 1px #dddddd;
            .confirm-btn {
                width: 690px;
                height: 92px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 32px;
                color: #ffffff;
                border-radius: 10px;
                background-color: #ff4847;
            }
        }
    }
</style>
