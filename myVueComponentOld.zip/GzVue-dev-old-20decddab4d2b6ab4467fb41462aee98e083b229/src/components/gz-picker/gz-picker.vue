<!--
  *slots(Array)
    [
      {
        values(Array): 备选项
        defaultIndex(Number): 初始选中值 默认0
        textAlign('left' 'center' 'right'): 该 slot 的对齐方式
        className(String): 该 slot 的特殊 CSS
        flex(Number): 该 slot CSS 的 flex 值 默认1
      },
      {
        divider(Boolean): 该 slot 是否是分割符
        content(String): 分割符文本
      }
    ]
  *visible-item-count(Number) → slot 中可见备选项的个数	会影响组件的高
  *change(Function) → 当被选中的值发生变化时触发该方法
    (picker,values)=>{
      picker → 当前 picker 的 vue 实例
        picker 实例中的方法
        getValues() → 获取所有 slot 目前被选中的值(分割符除外)
        setSlotValue(index, value) → 设置给定 slot 被选中的值，该值必须存在于该 slot 的备选值数组中
        getSlotValues(index) → 该 index 下 slot 的备选值数组
        setSlotValues(index, values) → 设定给定 slot 的备选值数组
      values → 所有 slot 被选中的值组成的数组
    }
-->
<template>
    <div
        class="picker"
        :class="{ 'picker-3d': rotateEffect }"
    >
        <div
            v-if="showToolbar"
            class="picker-toolbar"
            :style="{ height: itemHeight > 60 ? computedItemHeight + 'px' : '' }"
        >
            <slot>
                <div class="gz-picker-btn">
                    <span
                        @click="cancle"
                        v-text="cancelText"
                    ></span>
                    <span
                        @click="confirm"
                        v-text="confirmText"
                    ></span>
                </div>
            </slot>
        </div>
        <div class="picker-items">
            <picker-slot
                v-for="(slot, index) in slots"
                v-model="values[slot.valueIndex]"
                :key="index"
                :valueKey="valueKey"
                :values="slot.values || []"
                :text-align="slot.textAlign || 'center'"
                :visible-item-count="visibleItemCount"
                :class-name="slot.className"
                :flex="slot.flex"
                :rotate-effect="rotateEffect"
                :divider="slot.divider"
                :content="slot.content"
                :itemHeight="computedItemHeight"
                :default-index="slot.defaultIndex"
            ></picker-slot>
            <div
                class="picker-center-highlight"
                :style="{ height: computedItemHeight + 'px', marginTop: -computedItemHeight/4 +'px' }"
            ></div>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'gz-picker',
        componentName: 'picker',
        props: {
            slots: {
                type: Array
            },
            showToolbar: {
                type: Boolean,
                default: false
            },
            visibleItemCount: {
                type: Number,
                default: 5
            },
            valueKey: String,
            rotateEffect: {
                type: Boolean,
                default: false
            },
            itemHeight: {
                type: Number,
                default: 36
            },
            value: null,
            cancelText: {
                type: String,
                default: '取消'
            },
            confirmText: {
                type: String,
                default: '确定'
            },
            col: {
                type: Number,
                default: 1
            }
        },
        data() {
            return {
                currentValue: null,
                show: true
            };
        },
        watch: {
            value(val) {
                this.currentValue = val;
            }
        },
        components: {
            PickerSlot: require('./picker-slot.vue') // eslint-disable-line global-require
        },
        created() {
            this.$on('slotValueChange', this.slotValueChange);
            const slots = this.slots || [];
            this.values = [];
            const values = this.values;
            let valueIndexCount = 0;
            slots.forEach((slotA) => {
                const slot = slotA;
                if (!slot.divider) {
                    slot.valueIndex = valueIndexCount;
                    values[slot.valueIndex] = (slot.values || [])[slot.defaultIndex || 0];
                    valueIndexCount += 1;
                }
            });
        },

        mounted() {
            this.currentValue = this.value;
            this.currentValue ? this.setSlotsByValues(this.currentValue): null;
        },
        methods: {
            hideMask() {
                this.show = false;
            },
            onChange(picker) {
                const values = picker.$children.filter(child =>
                child.currentValue !== undefined).map(child => child.currentValue);
                this.currentValue = this.getValue(values);
                this.handleValueChange();
            },
            getValue(values) {
                let value;
                if(this.col=== 1){
                    value = values.join('');
                }else if(this.col === 2){
                    value = values.join('-');
                }
                return value;
            },
            setSlotsByValues(values) {
                const setSlotValue = this.setSlotValue;
                if (this.col === 1) {
                    setSlotValue(0, values.split(/-|\/|\./)[0]);
                } else if(this.col === 2) {
                    setSlotValue(0, values.split(/-|\/|\./)[0]);
                    setSlotValue(1, values.split(/-|\/|\./)[1]);
                }
                [].forEach.call(this.$children, child => child.doOnValueChange());
            },
            confirm() {
                this.$emit('confirm', this.currentValue);
            },
            cancle() {
                this.$emit('cancel', this.currentValue);
            },
            handleValueChange() {
                this.$emit('input', this.currentValue);
            },
            slotValueChange() {
                this.onChange(this);
                this.$emit('change', this, this.values);
            },
            onChange(picker) {
                const values = picker.$children.filter(child =>
                child.currentValue !== undefined).map(child => child.currentValue);
                this.currentValue = this.getValue(values);
                this.handleValueChange();
            },
            getSlot(slotIndex) {
                const slots = this.slots || [];
                let count = 0;
                let target;
                const children = this.$children.filter(child => child.$options.name === 'picker-slot');

                slots.forEach((slot, index) => {
                    if (!slot.divider) {
                        if (slotIndex === count) {
                            target = children[index];
                        }
                        count += 1;
                    }
                });

                return target;
            },
            getSlotValue(index) {
                const slot = this.getSlot(index);
                if (slot) {
                    return slot.value;
                }
                return null;
            },
            setSlotValue(index, value) {
                const slot = this.getSlot(index);
                if (slot) {
                    slot.currentValue = value;
                }
            },
            getSlotValues(index) {
                const slot = this.getSlot(index);
                if (slot) {
                    return slot.mutatingValues;
                }
                return null;
            },
            setSlotValues(index, values) {
                const slot = this.getSlot(index);
                if (slot) {
                    slot.mutatingValues = values;
                }
            },
            getValues() {
                return this.values;
            },
            setValues(valuesA) {
                const slotCount = this.slotCount;
                const values = valuesA || [];
                if (slotCount !== values.length) {
                    throw new Error('values length is not equal slot count.');
                }
                values.forEach((value, index) => {
                    this.setSlotValue(index, value);
                });
            }
        },

        computed: {
            values() {
                const slots = this.slots || [];
                const values = [];
                slots.forEach((slot) => {
                    if (!slot.divider) values.push(slot.value);
                });

                return values;
            },
            slotCount() {
                const slots = this.slots || [];
                let result = 0;
                slots.forEach((slot) => {
                    if (!slot.divider) {
                        result += 1;
                    }
                });
                return result;
            },
            computedItemHeight() {
//            console.log(document && document.querySelector('html').dataset.dpr === '1');
                if (global.document && global.document.querySelector('html').dataset.dpr === '1') {
                    return this.itemHeight / 2;
                }
                return this.itemHeight;
            }
        }
    };
</script>
<style lang="less">
    .picker {
        overflow: hidden;
        .picker-toolbar {
            height: 60px;
            border-bottom: 1rpx solid #e7e7e7;
            .gz-picker-btn {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0 20px;
                span {
                    width: 120px;
                    color: #000000;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    font-size: 32px;
                    &:last-child {
                        color: #ff4544;
                    }
                }
            }
        }
        .picker-items {
            position: relative;
            display: flex;
            justify-content: center;
            padding: 0;
            text-align: right;
            font-size: 24dpx;
            .picker-center-highlight {
                height: 72px;
                width: 100%;
                position: absolute;
                top: 50%;
                margin-top: -18px;
                box-sizing: border-box;
                pointer-events: none;
                transform: translateY(-25%);
                border-bottom: 1rpx solid #ddd;
                border-top: 1rpx solid #ddd;
            }
            .picker-center-highlight:before,
            .picker-center-highlight:after {
                content: '';
                position: absolute;
                height: 1rpx;
                width: 100%;
                background-color: #eaeaea;
                display: block;
                z-index: 15;
                transform: scaleY(0.5);
            }
            .picker-center-highlight:before {
                left: 0;
                top: 0;
                bottom: auto;
                right: auto;
            }
            .picker-center-highlight:after {
                left: 0;
                bottom: 0;
                right: auto;
                top: auto;
            }
        }
    }
</style>
