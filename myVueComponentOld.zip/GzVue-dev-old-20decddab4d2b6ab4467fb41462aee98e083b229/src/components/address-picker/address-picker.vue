<template>
    <div class="gz-area-select">
        <gz-mask
            :show="show"
            @click="cancle"
            class="publish-mask"
        ></gz-mask>
        <transition name="slide-bottom">
            <gz-picker
                v-show="show"
                :slots="areaSlots"
                :showToolbar="showToolbar"
                :itemHeight="itemHeight"
                @change="changeArea"
                ref="picker"
                class="gz-area-panel"
            >
                <div class="gz-area-btn">
                    <span
                        v-text="cancelText"
                        @click="cancle"
                    ></span>
                    <span
                        v-text="confirmText"
                        @click="confirm"
                    ></span>
                </div>
            </gz-picker>
        </transition>
    </div>
</template>

<script>
    import { isEmpty } from 'lodash';
    import { mapGetters, mapActions } from 'vuex';

    export default {
        name: 'gz-address-select',
        data() {
            return {
                loadFlag: false,
                regionList: [],
                provinceId: '',
                regionId: '',
                areaSlots: [{
                    flex: 1,
                    values: [],
                    textAlign: 'center'
                }, {
                    divider: true,
                    content: '-'
                }, {
                    flex: 1,
                    values: [],
                    textAlign: 'center'
                }, {
                    divider: true,
                    content: '-'
                }, {
                    flex: 1,
                    values: [],
                    textAlign: 'center'
                }]
            };
        },
        props: {
            cancelText: {
                type: String,
                default: '取消'
            },
            confirmText: {
                type: String,
                default: '确定'
            },
            show: {
                type: Boolean,
                default: false,
            },
            toggleShowFn: {
                type: Function,
                default: () => {}
            },
            currentSelect: {},
            getAreaInfo: {
                type: Function,
                default: () => {}
            },
            showToolbar: {
                type: Boolean,
                default: true
            },
            itemHeight: {
                type: Number,
                default: 36,
            },
            noLimitOption: {
                type: Boolean,
                default: false,
            },
        },
        watch: {
            show(val) {
                if (val) this.initRegion();
            },
        },
        methods: {
            ...mapActions([
                'getRegionVersion',
                'getRegionMain',
            ]),
            initRegion() {
//                debugger;
                const currentSelect = !isEmpty(this.currentSelect) ? this.currentSelect : {
                    province: '云南省',
                    city: '昆明市',
                    region: '五华区',
                };
                this.$set(this.areaSlots[0], 'values', this.regionList.map(item => item.name));
                const province = this.regionList.find(item => item.name === currentSelect.province) || {};
                this.$set(this.areaSlots[2], 'values', (province.subRegionList || []).map(item => item.name));
                const city = (province.subRegionList || []).find(item => item.name === currentSelect.city) || {};
                this.$set(this.areaSlots[4], 'values', (city.subRegionList || []).map(item => item.name));

                const setSlotValue = this.$refs.picker.setSlotValue;
                setSlotValue(0, currentSelect.province);
                setSlotValue(1, currentSelect.city);
                setSlotValue(2, currentSelect.region);
            },
            setRegionList() {
                const regionList = JSON.parse(global.localStorage.getItem('regionList'));
                if (this.noLimitOption) {
                    regionList.unshift({
                        code: null,
                        name: '不限',
                        subRegionList: [],
                    })
                    regionList.forEach(i => {
                        const item = i;
                        item.subRegionList.unshift({
                            code: null,
                            name: '不限',
                            subRegionList: [],
                        })
                        item.subRegionList.forEach(j => {
                            const sItem = j;
                            sItem.subRegionList.unshift({
                                code: null,
                                name: '不限',
                            })
                        })
                    })
                }
                this.$set(this, 'regionList', regionList);
                this.initRegion();
            },
            changeArea(picker, values) {
//                debugger;
                const province = this.regionList.find(item => item.name === values[0]) || {};
                picker.setSlotValues(1, (province.subRegionList || []).map(item => item.name));
                const city = (province.subRegionList || []).find(item => item.name === values[1]) || {};
                picker.setSlotValues(2, (city.subRegionList || []).map(item => item.name));
                const region = (city.subRegionList || []).find(item => item.name === values[2]) || {};
                this.selectInfo = {
                    province: province.name,
                    provinceId: province.code,
                    city: city.name || '',
                    cityId: city.code || '',
                    region: region.name || '',
                    regionId: region.code || '',
                };
            },
            confirm() {
                this.getAreaInfo(this.selectInfo);
                this.toggleShowFn(false);
            },
            cancle() {
                this.toggleShowFn(false);
            }
        },
        mounted() {
            if (global.localStorage.getItem('regionList')) {
                this.getRegionVersion().then((version) => {
                    if (version > JSON.parse(global.localStorage.getItem('regionVersion'))) {
                        this.getRegionMain().then((data) => {
                            global.localStorage.setItem('regionVersion', JSON.stringify(version));
                            global.localStorage.setItem('regionList', JSON.stringify(data));
                            this.setRegionList();
                        })
                    } else {
                        this.setRegionList();
                    }
                });
            } else {
                this.getRegionVersion().then((version) => {
                    global.localStorage.setItem('regionVersion', JSON.stringify(version));
                });
                this.getRegionMain().then((data) => {
                    global.localStorage.setItem('regionList', JSON.stringify(data));
                    this.setRegionList();
                });
            }
        },
    };
</script>

<style lang="less">
    .gz-area-select {
        .gz-area-panel {
            height: auto;
            width: 100%;
            position: absolute;
            bottom: 0;
            padding: 0 0 20px;
            z-index: 1000;
            background-color: white;
            .gz-area-btn {
                height: inherit;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 20px;
                span {
                    width: 120px;
                    color: #000000;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    font-size: 32dpx;
                    &:last-child {
                        color: #ff4544;
                    }
                }
            }
        }
    }
</style>
