import GzAddressPicker from './address-picker.vue';

GzAddressPicker.install = (Vue) => {
    Vue.component(GzAddressPicker.name, GzAddressPicker);
};

export default GzAddressPicker;
