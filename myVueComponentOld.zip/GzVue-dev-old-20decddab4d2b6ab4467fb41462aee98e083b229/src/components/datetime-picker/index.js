import GzDatetimePicker from './datetime-picker.vue';

GzDatetimePicker.install = (Vue) => {
    Vue.component(GzDatetimePicker.name, GzDatetimePicker);
};

export default GzDatetimePicker;
