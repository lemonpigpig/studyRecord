<template>
    <div
        @click="click"
        class="gz-mask"
        :class="{'show':!isHidden||show}"
    >
        <slot></slot>
    </div>
</template>

<script>
const freezeVp = function (e) {
    e.preventDefault();
};

export default {
    name: 'gz-mask',
    props: {
        isHidden: {
            type: Boolean,
            default: true
        },
        show: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            originBodyOverflow: ''
        };
    },
    methods: {
        click() {
            this.$emit('click');
        },
        setOverflowHidden(value) {
            if (window && document) {
                const html = document.querySelector('html');
                if (value) {
                    this.$set(this, 'originBodyOverflow', window.getComputedStyle(html, null).overflow);
                    html.style.overflow = 'hidden';
                    document.addEventListener('touchmove', freezeVp, false);
                } else {
                    html.style.overflow = this.originBodyOverflow;
                    document.removeEventListener('touchmove', freezeVp, false);
                }
            }
        }
    },
    watch: {
        show(value) {
            this.setOverflowHidden(value);
        },
        isHidden(value) {
            this.setOverflowHidden(!value);
        }
    },
    mounted() {
        if (this.show || !this.isHidden) {
            this.setOverflowHidden(true);
        }
    },
    destroyed() {
        this.setOverflowHidden(false);
    }
};
</script>

<style lang='less'>
.gz-mask {
    position: fixed;
    top: 0;
    left: 0;
    height: 100%;
    width: 100%;
    background-color: rgba(0,0,0,0.6);
    visibility: hidden;
    opacity: 0;
    transition: opacity 0.3s ease-in, visibility 0.3s ease-in;
    z-index: 999;
    &.show {
        opacity: 1;
        visibility: visible;
    }
}
</style>
