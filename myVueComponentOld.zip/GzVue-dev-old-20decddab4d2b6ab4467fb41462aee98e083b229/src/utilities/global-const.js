const PREFIX = 'gz-';
export {
    PREFIX
};
