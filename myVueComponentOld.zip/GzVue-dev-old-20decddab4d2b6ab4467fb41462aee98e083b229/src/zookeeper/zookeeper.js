const ZooKeeper = require('zookeeper');  // eslint-disable-line global-require
const fs = require('fs');

const isEqual = require('./tools');

let configPath = '../../../../config';
process.argv.forEach((val, index) => {
    if (index === 2) {
        configPath = val;
    }
});

const config = require(`${configPath}/env.${(process.env.NODE_ENV ? process.env.NODE_ENV : 'development')}.json`); // eslint-disable-line global-require

const path = `/central_config/${config.zookeeper.env}/${config.appInfo.group}/${config.appInfo.name}/${config.appInfo.version}/application`;

/*
 ZOO_OPEN_ACL_UNSAFE: {perms: 31, scheme: 'world', auth: 'anyone'},
 ZOO_READ_ACL_UNSAFE: {perms: 1, scheme: 'world', auth: 'anyone'},
 ZOO_CREATOR_ALL_ACL: {perms: 31, scheme: 'auth', auth: ''},
 ZOO_CREATED_EVENT: 1,
 ZOO_DELETED_EVENT: 2,
 ZOO_CHANGED_EVENT: 3,
 ZOO_CHILD_EVENT: 4,
 ZOO_SESSION_EVENT: -1,
 ZOO_NOTWATCHING_EVENT: -2,
 ZOO_PERM_READ: 1,
 ZOO_PERM_WRITE: 2,
 ZOO_PERM_CREATE: 4,
 ZOO_PERM_DELETE: 8,
 ZOO_PERM_ADMIN: 16,
 ZOO_PERM_ALL: 31,
 ZOOKEEPER_WRITE: 1,
 ZOOKEEPER_READ: 2,
 ZOO_EPHEMERAL: 1,
 ZOO_SEQUENCE: 2,
 ZOO_EXPIRED_SESSION_STATE: -112,
 ZOO_AUTH_FAILED_STATE: -113,
 ZOO_CONNECTING_STATE: 1,
 ZOO_ASSOCIATING_STATE: 2,
 ZOO_CONNECTED_STATE: 3,
 ZOO_LOG_LEVEL_ERROR: 1,
 ZOO_LOG_LEVEL_WARN: 2,
 ZOO_LOG_LEVEL_INFO: 3,
 ZOO_LOG_LEVEL_DEBUG: 4,
 ZOK: 0,
 ZSYSTEMERROR: -1,
 ZRUNTIMEINCONSISTENCY: -2,
 ZDATAINCONSISTENCY: -3,
 ZCONNECTIONLOSS: -4,
 ZMARSHALLINGERROR: -5,
 ZUNIMPLEMENTED: -6,
 ZOPERATIONTIMEOUT: -7,
 ZBADARGUMENTS: -8,
 ZINVALIDSTATE: -9,
 ZAPIERROR: -100,
 ZNONODE: -101,
 ZNOAUTH: -102,
 ZBADVERSION: -103,
 ZNOCHILDRENFOREPHEMERALS: -108,
 ZNODEEXISTS: -110,
 ZNOTEMPTY: -111,
 ZSESSIONEXPIRED: -112,
 ZINVALIDCALLBACK: -113,
 ZINVALIDACL: -114,
 ZAUTHFAILED: -115,
 ZCLOSING: -116,
 ZNOTHING: -117,
 ZSESSIONMOVED: -118
 */

let zk;
let oldConfig = {};

try {
    oldConfig = require(`${configPath}/config-center.json`).config;  // eslint-disable-line global-require
} catch (e) {
    fs.writeFileSync('./config/config-center.json', '{}'.toString('utf8'), 'UTF-8');
}

/**
 * 注册节点监听
 */
const registerService = () => {
    zk.aw_get(path,
        (type, state, node) => {
            switch (type) {
                case ZooKeeper.ZSYSTEMERROR:
                    console.error('zk aw_get: ZSYSTEMERROR');
                    break;
                case ZooKeeper.ZOO_CONNECTED_STATE:
                    console.log(`zk aw_get: node[${node}]`);
                    registerService();
                    break;
                default:
                    break;
            }
        },
        (rc, error, stat, data) => {
            if (rc !== 0) {
                switch (rc) {
                    case ZooKeeper.ZOPERATIONTIMEOUT:
                        console.error('zk get error: ZOPERATIONTIMEOUT');
                        break;
                    default:
                        console.error(`zk get error: API Responses[${rc}]`);
                        zk.close();
                        break;
                }
                return;
            }
            const newConfig = JSON.parse(data.toString('utf8')).config;

            if (!isEqual(oldConfig, newConfig)) {
                fs.writeFileSync('./config/config-center.json', data.toString('utf8'), 'UTF-8');
                // child_process.exec('pm2 reload all', (execError, stdout) => {
                //     if (execError) {
                //         console.error(`zk pm2 reload error: ${execError}`);
                //         return;
                //     }
                //     console.log(`zk pm2 reload stdout: ${stdout}`);
                // });
                console.log('zk aw_get: has change, restart');
                oldConfig = newConfig;
            } else {
                console.log('zk aw_get: ZOK');
            }
        });
};

/**
 * 初始化 ZK client
 */
const newZK = () => {
    zk = new ZooKeeper();
    zk.init({
        connect: config.zookeeper.servers,
        timeout: config.zookeeper.sessionTimeout,
        debug_level: ZooKeeper.ZOO_LOG_LEVEL_ERROR,
        host_order_deterministic: false
    });

    zk.on('connect', (rc) => {
        console.log(`zk connect: state[${rc.state}], session[${rc.client_id}].`);
    });

    zk.on('close', (rc, state) => {
        console.log(`zk close: state[${state}, ${rc.state}], session[${rc.client_id}].`);
        newZK();
        registerService();
    });
};

newZK();
registerService();
