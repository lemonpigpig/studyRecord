<script>
import wx from 'wx'
import '@/style/weui/weui.css'
import '@/style/app.css'

export default {
  created () {
    // 调用API从本地缓存中获取数据
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    console.log('app created and cache logs by setStorageSync')
  }
}
</script>

<style lang="scss">
    /* this rule will be remove */
    @import '@/style/button.scss';
    @import '@/style/tag.scss';
    @import '@/style/icon.scss';

    * {
        transition: width 2s;
        -moz-transition: width 2s;
        -webkit-transition: width 2s;
        -o-transition: width 2s;
    }
    .wrapper{
        border-top: 1px solid #dedede;
        background: #F5F5F9;
    }
    button {
        // position: static;
    }
</style>
