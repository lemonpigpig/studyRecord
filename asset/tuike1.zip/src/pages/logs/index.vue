<template>
  <div>
    <ul class="container log-list">
      {{test}}
      <li v-for="(log, index) in logs" :class="{ red: aa }" :key="index" class="log-item">
        <card :text="(index + 1) + ' . ' + log"></card>
      </li>
    </ul>
  </div>
</template>

<script>
import wx from 'wx'
import { formatTime } from '@/utils/index'
import card from '@/components/card'
import { mapState } from 'vuex'

export default {
  components: {
    card
  },
  computed: {
    ...mapState({
      'test': state => state.log.test
    })
  },
  data () {
    return {
      logs: []
    }
  },

  created () {
    const logs = (wx.getStorageSync('logs') || [])
    this.logs = logs.map(log => formatTime(new Date(log)))
  }
}
</script>

<style>
.log-list {
  display: flex;
  flex-direction: column;
  padding: 40rpx;
}

.log-item {
  margin: 10rpx;
}
</style>
