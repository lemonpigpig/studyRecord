<template>
    <div>
        <!-- 将要测试的组件可以放在这里 -->
        <a href="/pages/comp/index" class="counter">去往基础组件示例页面</a>
        <a href="/pages/vuex/index" class="counter">去往Vuex示例页面</a>
        <a href="/pages/account/editPasw" class="counter">editPasw</a>
        <a href="/pages/account/validate" class="counter">validate</a>
        <a href="/pages/account/coupon" class="counter">coupon</a>
        <a href="/pages/account/withdrawForm" class="counter">withdrawForm</a>
        <a href="/pages/account/index" class="counter">index</a>
        
        <button @click="openModal">show modal</button>
        <boqii-modal :show="showModal" @closeModal="showModal=false"></boqii-modal>
        <a href="/pages/order/refund" class="counter">申请退款</a>
    </div>
</template>

<script>
    import BoqiiModal from '@/components/modal.vue'
    export default {
        data() {
            return {
                showModal: false
            }
        },
        components: {
            BoqiiModal
        },
        methods: {
            openModal() {
                this.showModal = true
            }
        }
    }
</script>