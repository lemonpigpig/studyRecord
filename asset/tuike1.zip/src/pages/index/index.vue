<template>
  <div class="container" @click="clickHandle('test click', $event)">
  
    <div class="userinfo" @click="bindViewTap">
      <img class="userinfo-avatar" v-if="userInfo.avatarUrl" :src="userInfo.avatarUrl" background-size="cover" />
      <div class="userinfo-nickname">
        <card :text="userInfo.nickName"></card>
      </div>
    </div>
  
    <div class="usermotto">
      <div class="user-motto">
        <card :text="motto"></card>
      </div>
    </div>
  
    <form class="form-container">
      <input type="text" class="form-control" v-model="motto" placeholder="v-model" />
      <input type="text" class="form-control" v-model.lazy="motto" placeholder="v-model.lazy" />
    </form>
    <mpvue-button type="primary" btnMsg="自定义文字" plain></mpvue-button>
  
    <a href="/pages/comp/index" class="counter">去往基础组件示例页面</a>
    <a href="/pages/vuex/index" class="counter">去往Vuex示例页面</a>
    <a href="/pages/account/editPasw" class="counter">editPasw</a>
    <a href="/pages/account/validate" class="counter">validate</a>
    <a href="/pages/account/coupon" class="counter">coupon</a>
    <a href="/pages/account/withdrawForm" class="counter">withdrawForm</a>
    <button @click="showmodal">show modal</button>
  
  </div>
</template>

<script>
  import wx from 'wx'
  import card from '@/components/card'
  import mpvueButton from '@/components/button/button'
  import BoqiiModal from '@/components/modal.vue'
  
  export default {
    data() {
      return {
        motto: 'Hello World',
        userInfo: {}
      }
    },
  
    components: {
      card,
      mpvueButton,
      BoqiiModal
    },
  
    methods: {
      bindViewTap() {
        const url = '/pages/logs/index'
        // wx.navigateTo({ url })
        this.$router.push(url)
      },
      getUserInfo() {
        // 调用登录接口
        wx.login({
          success: () => {
            wx.getUserInfo({
              success: (res) => {
                this.userInfo = res.userInfo
              }
            })
          }
        })
      },
      clickHandle(msg, ev) {
        console.log('clickHandle:', msg, ev)
      },
      showmodal() {
        this.toggleModal(true)
      }
    },
  
    created() {
      // 调用应用实例的方法获取全局数据
      this.getUserInfo()
    }
  }
</script>

<style scoped>
  .userinfo {
    display: flex;
    flex-direction: column;
    align-items: center;
  }
  
  .userinfo-avatar {
    width: 128rpx;
    height: 128rpx;
    margin: 20rpx;
    border-radius: 50%;
  }
  
  .userinfo-nickname {
    color: #aaa;
  }
  
  .usermotto {
    margin-top: 150px;
  }
  
  .form-control {
    display: block;
    padding: 0 12px;
    margin-bottom: 5px;
    border: 1px solid #ccc;
  }
  
  .counter {
    display: inline-block;
    margin: 10px auto;
    padding: 5px 10px;
    color: blue;
    border: 1px solid blue;
  }
</style>
