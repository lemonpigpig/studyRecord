<template>
  <div class="counter-warp">
    <p>
      <button @click="getMoviesHandler('lastest')">获取最新电影--come on</button>
		<button @click="getItem">获取最新单个电影</button>
    </p>
	<div v-show="movie.loading">正在请求中</div>
    <ul v-show="!movie.loading">
		<li v-for="item in movie" :key="key">{{item.title}}</li>
	</ul>
  </div>
</template>


<script>
	import { mapState, mapMutations, mapActions } from 'vuex';
	export default {
		created() {

		},
		computed: {
			...mapState([
				// 映射 this.count 为 store.state.count
				"movies",
				"movie",
			])
		},
		methods: {
			...mapActions([
				"getMovies",
				"getMovieItem"
			]),
			getItem() {
				// 下面是简化版
        // this.$store.dispatch('getMovieItem')
        // this.getMovieItem();
				this.getMovieItem({
					name: 'yangfeittnc',
					age: 12
				})
			},
			getMoviesHandler(lastest) {
				// 简化版是 this.getMovies().then(...)
				this.$store.dispatch('getMovies', {
					name: 'yangfei',
					age: 12
				}).then(data => console.log('请求结束?'))
			}
		}
	}
</script>

<style>
.counter-warp {
  text-align: center;
  margin-top: 100px;
}
.home {
  display: inline-block;
  margin: 100px auto;
  padding: 5px 10px;
  color: blue;
  border: 1px solid blue;
}

</style>
