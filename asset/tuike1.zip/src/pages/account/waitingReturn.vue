<template>
    <div class="account-total_profit">
        <div>
            <profit-header :type="3" :money="234">
            </profit-header>
        </div>
        <content-p :currentTab="pageList"></content-p>
    </div>
</template>

<script>
    import wx from "wx";
    //把框架做成了滚动并且头部固定的形式
    import Content from "@/components/account/content.vue"
    import ProfitHeader from "@/components/account/profitHeader.vue"
    
    let types = {
        1: "帮你赚了",
        2: "退换货",
        3: "xxx"
    };
    
    export default {
        data() {
            return {
                winWidth: 0,
                winHeight: 0,
                pageList: [{
                        avatar: "http://img-new.boqiicdn.com/Data/Shop/1/193/19304/shoppicpath11517810141_y.jpg?imageView2/2/w/320/h/320/q/100/interlace/0",
                        name: "hahah",
                        time: "2018-08-12",
                        type: types[1]
                    },
                    {
                        avatar: "http://img-new.boqiicdn.com/Data/Shop/1/193/19304/shoppicpath11517810141_y.jpg?imageView2/2/w/320/h/320/q/100/interlace/0",
                        name: "hahah2",
                        time: "2018-08-12",
                        type: types[2]
                    }
                ],
                contentHeight: 0
            };
        },
        mounted() {
            console.log("this.$root.$mp.appOptions:", this.$root.$mp.appOptions);
        },
        computed: {
            contentHeight() {
                // console.log('winHeight:', this.winHeight)
                return this.winHeight - 62 + "px";
            }
        },
        components: {
            ContentP: Content,
            ProfitHeader
        },
        async onLoad() {
            // 获取系统消息
            wx.getSystemInfo({
                success: res => {
                    this.winWidth = res.windowWidth;
                    this.winHeight = res.windowHeight;
                    this.contentHeight = this.winHeight - 120 + "px";
                }
            });
        }
    };
</script>

<style lang="scss" scoped>
    .account-total_profit {
        height: 100%;
        .swiper-box {
            display: block;
            width: 100%;
            overflow: hidden;
            .swiper-item {
                height: 100%;
                text-align: center;
            }
        }
    }
</style>
