<template>
    <div class="boqii-validte_pasw">
        <div class="weui-cell weui-cell_input weui-cell_vcode">
            <!-- <div class="weui-cell__hd">
                            <div class="weui-label">手机号</div>
                        </div> -->
            <div class="weui-cell__bd">
                <input class="weui-input" placeholder="请输入手机号" />
            </div>
            <div class="weui-cell__ft">
                <div class="weui-vcode-btn">获取验证码</div>
            </div>
        </div>
        <div class="weui-cells weui-cells_after-title">
            <div class="weui-cell weui-cell_input">
                <div class="weui-cell__bd font-clor_type1">
                    <input class="weui-input" placeholder="请输入验证码" v-model="password" />
                </div>
               
            </div>
        </div>
        <div class="edit-pasw_btn">
            <div class="btn-block">
                <button class="boqii-btn primary" :disabled="disabled">确定</button>
            </div>
        </div>
    
    </div>
</template>

<script>
    export default {
        data() {
            return {
                icon: '隐藏',
                show: false,
                type: 'password',
                password: ''
            };
        },
        methods: {
            changeStatus() {
                this.show = !this.show
                this.icon = this.show ? '显示' : '隐藏'
                this.type = this.show ? 'text' : 'password'
            }
        },
        computed: {
            disabled() {
                return this.password.length === 0;
            }
        }
    };
</script>

<style lang="scss" scoped>
    .boqii-validte_pasw {
        .weui-cells:after, .weui-cells:before {
            left: 30px;
            right: 30px;
        }
        .weui-cell {
            padding-left: 32px;
            padding-right: 35px;
        }
        // .weui-cell:first-child:after {
        //     display: block;
        // }
        .edit-pasw_btn {
            position: fixed;
            bottom: 20px;
            width: 100%;
        }
        .active {
            opacity: 1;
        }
        .disable {
            opacity: .5;
        }
        .weui-vcode-btn {
            color: #F55B50;
            font-size: 15px;
            line-height: 19px;
            height: 19px;
            padding-right: 0;
        }
    }
</style>

