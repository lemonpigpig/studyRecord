<template>
    <div class="boqii-account_coupon">
        <div class="coupon_tab"></div>
        <div class="coupon_rule">每笔订单最多可用3个红包</div>
        <div class="copuon_list">
            <checkbox-group @change="checkboxChange">
                <label class="coupon_box" v-for="(item, index) in couponList" :key="index">
                    <checkbox class="weui-check" :value="item.id" :checked="item.checked"/>
                    <div class="weui-cell__hd weui-check__hd_in-checkbox">
                        <icon class="weui-icon-checkbox_circle" type="circle" size="23" v-if="!item.checked"></icon>
                        <icon class="weui-icon-checkbox_success" type="success" size="23" v-if="item.checked"></icon>
                    </div>
                    <div class="weui-cell__bd coupon_item">
                        <div class="coupon_title">{{item.title}}</div>
                        <div class="coupon_code">{{item.code}}</div>
                        <div class="coupon_time">{{item.time}}</div>
                        <div class="coupon_condition">{{item.condition}}</div>
                    </div>
                </label>
            </checkbox-group>
        </div>
        <div class="coupon_btn">
            <div class="btn-block">
                <button class="boqii-btn primary" v-bind:class="{disable: disabled}">确定</button>
            </div>
        </div>
    </div>
</template>

<script>
    import checkbox from '@/components/checkbox.vue'
    
    export default {
        data() {
            return {
                lovingVue: true,
                selectedList: [],
                couponList: [{
                    id: 1,
                    title: 'lalala',
                    code: '123ewww',
                    time: '2018-09-12-2019-08-12',
                    condition: 'xxxxxxxx1222',
                    money: '¥4.5',
                    checked: true
                }, {
                    id: 2,
                    title: 'lalala12',
                    code: '123ewww',
                    time: '2018-09-12-2019-08-12',
                    condition: 'xxxxxxxx1222',
                    money: '¥5.5',
                    checked: false
                }]
            }
        },
        components: {
            boqiicheckbox: checkbox
        },
        methods: {
            checkboxChange(e) {
                var checkboxItems = this.couponList, values = e.mp.detail.value;
                console.log('checkbox发生change事件，携带value值为：' + values,values instanceof Array);
                for (var i = 0, lenI = checkboxItems.length; i < lenI; ++i) {
                    checkboxItems[i].checked = false;
                    for (var j = 0, lenJ = values.length; j < lenJ; ++j) {
                        if (checkboxItems[i].id == values[j]) {
                            checkboxItems[i].checked = true;
                            break;
                        }
                    }
                }
                this.couponList = checkboxItems;
            },
        }
    }
</script>

<style lang="scss" scoped>
    .boqii-account_coupon {
        .weui-check__hd_in-checkbox {
            position: absolute;
            top: 44px;
            left: 10px;
            z-index: 999;
        }
        .coupon_rule {
            background: #FFEBEB;
            width: 100%;
            height: 30px;
            line-height: 30px;
            font-size: 13px;
            color: #F55B50;
            padding-left: 10px;
        }
        .copuon_list {
            padding: 0px 12px 20px 12px;
            box-sizing: border-box;
            .coupon_item {
                width: 100%;
                height: 110px;
                background: #F55B50;
                border-radius: 4px;
                margin-top: 10px;
                padding-left:40px;
                color: #FFF2D1;
                font-size: 10px;

                background: #E44D43;
                box-shadow: -1px 1px 1px 0 #DD4338;
                .coupon_title {
                    font-size: 15px;
                    padding-top: 12px;
                    line-height: 21px;
                }
                .coupon_code,.coupon_time,.coupon_condition  {
                    line-height: 14px;
                }
                .coupon_code {
                    margin-top: 14px;
                }
                .coupon_condition {
                    margin-top: 10px;
                }
            }
            .coupon_box {
                position: relative;
            }
        }
        .coupon_btn {
            position: fixed;
            width: 100%;
            bottom: 124px;
        }
    }
</style>
