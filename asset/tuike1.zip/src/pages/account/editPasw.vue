<template>
    <div class="boqii-edit_pasw">
        <div class="weui-cells weui-cells_after-title">
            <div class="weui-cell weui-cell_input">
                <!-- <div class="weui-cell__hd">
                    <div class="weui-label">卡号</div>
                </div> -->
                <div class="weui-cell__bd font-clor_type1">
                    <input class="weui-input" placeholder="请设置支付密码" v-if="!show" v-model="password" type="password"/>
                    <input class="weui-input" placeholder="请设置支付密码" v-if="show" v-model="password"/>
                </div>
                <div class="weui-cell__ft" @click="changeStatus">
                    <!-- <icon type="warn" size="23" color="#E64340"></icon> -->
                    <span>{{icon}}</span>
                </div>
            </div>
        </div>
        <div class="edit-pasw_btn">
            <div class="btn-block">
                <button class="boqii-btn primary" v-bind:class="{disable: disabled}">确定</button>
            </div>
        </div>
         
    </div>
</template>

<script>
    export default {
        data() {
            return {
                icon: '隐藏',
                show: false,
                type: 'password',
                password: ''
            };
        },
        methods: {
            changeStatus() {
                this.show = !this.show
                this.icon = this.show ? '显示' : '隐藏'
                this.type = this.show ? 'text' : 'password'
            }
        },
        computed: {
            disabled() {
                return this.password.length === 0;
            }
        }
    };
</script>

<style lang="scss" scoped>
    .boqii-edit_pasw {
        .weui-cells:before {
            display: none;
        }
        .weui-cells:after {
            left: 30px;
            right: 30px;
        }
        .weui-cell {
            padding-left: 32px;
            padding-right: 35px;
        }
        .edit-pasw_btn {
            position: fixed;
            bottom: 20px;
            width: 100%;
        }
        .active {
            opacity: 1;
        }
        .disable {
            opacity: .5;
        }
    }
</style>

