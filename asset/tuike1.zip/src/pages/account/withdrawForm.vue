<template>
    <div class="boqii_withdraw">
        <div class="boqii_rule">
            提现规则：100元起提，每月限提1次，每次最高3000元；
        </div>
        <div class="box_10"></div>
        <div class="boqii_tip font_level_1 font-clor_type1">
            提现金额(不得超过每日提现上线)
        </div>
        <div class="weui-cells weui-cells_after-title money_input">
            <div class="weui-cell weui-cell_input">
                <div class="weui-cell__hd">
                    <div class="weui-label">¥</div>
                </div>
                <div class="weui-cell__bd font-clor_type1">
                    <input class="weui-input" placeholder=" " v-model.lazy="money" focus/>
                </div>
            </div>
        </div>
        <div class="can_get font-clor_type2 font_level_1">
            <span>可提现金额:</span><span>500{{unit}}</span>
        </div>
        <div class="withdraw_form">
            <div class="weui-cells weui-cells_after-title" v-for="(item, index) in inputList" :key="index" :class="item.clazz">
                <div class="weui-cell weui-cell_input">
                    <div class="weui-cell__hd">
                        <div class="weui-label">{{item.label}}</div>
                    </div>
                     <div class="weui-cell__hd" v-if="item.id!==3 && item.id!==4">
                        <input class="weui-input second_input" :placeholder="item.placeholder" v-model="item.inputValue"/>
                    </div>
                    <div class="weui-cell__hd" v-else>
                        <span>{{item.inputValue}}</span>元
                    </div>
                </div>
            </div>
        </div>
        <div class="withdraw_btn boqii_fixed">
            <div class="btn-block">
                <button class="boqii-btn primary" @click="withdraw" :disabled="disabled">提现到支付宝</button>
            </div>
        </div>
        <boqii-modal :show="showModal" @closeModal="showModal=false">
            <div slot="header">
                <div class="withdraw-modal_title">
                    请输入提现密码
                </div>
            </div>
            <div slot="body">
                <div class="text_center pay_detail">
                    <div>提现至支付宝账号:</div>
                    <div>niumu123456793784667839</div>
                    <div class="modal_money">
                        ¥500
                    </div>
                    <div class="modal_desp">
                        请输入波奇宠物app余额支付密码
                    </div>
                    <div class="modal_input margin_center">
                        <input type="password" focus/>
                    </div>
                </div>
            </div>
            <div slot="footer">
                <div class="modal_footer primary action-btn boqii-btn text_center margin_center" id="boqii_close">确认提现到支付宝</div>
            </div>
        </boqii-modal>
    </div>
</template>

<script>
    import BoqiiModal from '@/components/modal.vue'

    export default {
        data() {
            return {
                money: "",
                unit: "元",
                disabled: false,
                showModal: false,
                inputList: [{
                    id: 1,
                    type: "input",
                    label: "支付宝账号",
                    inputValue: "",
                    placeholder: "支付宝账户绑定的手机号",
                    clazz: "boqii_phone"
                }, {
                    id: 2,
                    type: "input",
                    label: "身份证号",
                    inputValue: "",
                    placeholder: "支付宝实名认证身份证号",
                    clazz: "boqii_idcard"
                }, {
                    id: 3,
                    type: "input",
                    label: "应纳税额",
                    inputValue: "244",
                    placeholder: "",
                    clazz: "boqii_tax"
                }, {
                    id: 4,
                    type: "input",
                    label: "实际到账",
                    inputValue: "12345",
                    placeholder: "",
                    clazz: "boqii-actual_money"
                }]
            };
        },
        components: {
            BoqiiModal
        },
        methods: {
            withdraw() {
                this.showModal = true
            }
        }
    };
</script>

<style lang="scss" scoped>
    .boqii_withdraw {
        .boqii_tip {
            padding: 8px 0px 22px 15px;
        }
        .weui-cells:before {
            display: none;
        }
        .money_input {
            &.weui-cells:after {
                left: 15px;
            }
            .weui-label {
                width: 35px;
            }
        }
        .can_get {
            padding: 6px 0px 8px 15px;
        }
        .withdraw_form {
            .boqii_tax,
            .boqii-actual_money {
                .second_input {
                    // width: 34px;
                }
                .weui-cell__hd {
                    flex: 0 0 auto;
                }
            }
            .boqii_tax {
                .second_input {
                    // width: 34px;
                }
            }
        }
        .withdraw_btn {
            bottom: 12px;
        }
        .withdraw-modal_title {
            border-bottom: 1px solid #E5E5E5;
            padding-top: 14px;
            padding-bottom: 12px;
        }
        .pay_detail {
            margin-top: 10px;
            font-size: 13px;
            color: #2A2A2A;
            .modal_money {
                font-size: 30px;
                color: #444444;
                line-height: 42px;
            }
            .modal_desp {
                font-size: 11px;
                color: #999999;
            }
            .modal_input {
                margin-top: 8px;
                border: 1px solid#E0E0E0;
                width: 214px;
                height: 34px;
            }
        }
        .modal_footer {
            width: 214px;
            font-size: 17px;
            box-sizing: border-box;
            margin-top: 24px;
            margin-bottom: 20px;
        }
    }
</style>