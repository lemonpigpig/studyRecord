<template>
    <div class="account_balance">
        <div class="withdraw_rule font_color_strong">
            体现规则：100元起提，每月限提1次，每月最高3000元；仅限每月5号体现
        </div>
        <profit-header :type="5" :money="11455.33">
        </profit-header>
        <div class="box_10"></div>
        <div class="withdraw_alipay">
            <div class="alipay_icon">
                <img src="/static/images/alipay.png" alt="" class="weui-media-box__thumb">
            </div>
            <div class="font-clor_type1">
                提现到支付宝
            </div>
        </div>
        <div class="box_10"></div>
        <div class="log_title">
            <div class="weui-cell weui-cell_access font-clor_type1">
                账户余额流转记录
            </div>
            <div class="weui-cell weui-border_1px left-border_12px"></div>
        </div>
        <div class="log_list">
            <div class="">
                <div class="placeholder_order placeholder-box_size158 margin_center">
                    <img src="/static/images/placeholder_order.png" class="weui-media-box__thumb">
                </div>
                <div class="font-no_info"> 
                    暂无流转记录
                </div>
            </div>
    
            <content-p :currentTab="logList" :showImg="false"></content-p>
        </div>
    </div>
</template>

<script>
    import wx from "wx"
    import ProfitHeader from "@/components/account/profitHeader.vue"
    import Content from "@/components/account/content.vue"
    
    let statusMap = {
        1: '审核',
        2: '到账成功',
        3: '调整成功'
    }
    export default {
        data() {
            return {
                logList: [{
                    name: '支付宝提现',
                    time: '2018-01-23',
                    money: '-89',
                    type: 1
                }, {
                    name: '支付宝提现',
                    time: '2018-01-23',
                    money: '-89',
                    type: 2
                }]
            };
        },
        computed: {},
        components: {
            ProfitHeader,
            ContentP: Content
        }
    };
</script>

<style lang="scss" scoped>
    .account_balance {
        .withdraw_rule {
            padding: 10px 12px 10px 12px;
            font-size: 13px;
            text-align: left;
            background: #FFF3EF;
        }
        .withdraw_alipay {
            .alipay_icon {
                width: 30px;
                height: 30px;
                padding: 10px 12px 10px 12px;
            }
            &>div {
                display: inline-block;
                vertical-align: middle;
            }
        }
        .log_title {
            position: relative;
            font-size: 15px;
        }
        .log_list {
            padding-top: 15px;
        }
        .placeholder_order {
            margin-top: 30px;
            margin-bottom: 14px;
        }
    }
</style>
