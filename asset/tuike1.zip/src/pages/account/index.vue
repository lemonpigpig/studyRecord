<template>
  <div class="account_index">
  
    <div class="account_list">
      <div class="weui-panel weui-panel_access">
        <div class="weui-panel__bd">
          <navigator url="" class="weui-media-box weui-media-box_appmsg" hover-class="weui-cell_active">
            <div class="weui-media-box__hd weui-media-box__hd_in-appmsg">
              <image class="weui-media-box__thumb" :src="icon60" />
            </div>
            <div class="weui-media-box__bd weui-media-box__bd_in-appmsg">
              <div class="weui-media-box__title">标题一</div>
              <div class="weui-media-box__desc">由各种物质组成的巨型球状天体，叫做星球。星球有一定的形状，有自己的运行轨道。</div>
            </div>
          </navigator>
        </div>
        <div class="account_cotent">
          <!-- 如果不是推客 -->
          <div class="tuike_bar">
            <image src="/static/images/account_tuike_bar.png" class="img-size_auto"/>
          </div>
          <!-- 如果是则显示收益详情 -->
  
          <div class="weui-flex text_center mb15">
            <div class="weui-flex__item" v-for="(item, index) in profitDetail" :key="index">
              <div class="placeholder" @click="jumpHander(item)">
                <div class="font_level_3 font-clor_type1">{{item.value}}</div>
                <div class="font_level_2 font-clor_type3">{{item.name}}</div>
              </div>
            </div>
          </div>
        </div>
  
        <div class="weui-flex text_center font_level_2 mb15">
          <div class="weui-flex__item" v-for="(item, index) in accountList" :key="index">
            <div class="placeholder">
              <div class="box-size_40 margin_center">
                <image :src="item.icon" class="img-size_auto"/>
              </div>
              <div class="font-clor_type1">{{item.name}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="box_10"></div>
    <div class="account_order">
      <navigator url="">
        <div class="weui-panel__ft order_more">
          <div class="weui-cell weui-cell_access weui-cell_link">
            <div class="weui-cell__bd">我的订单</div>
            <div class="weui-cell__ft weui-cell__ft_in-access font-clor_type3 font_level_1">更多</div>
          </div>
          <div class="weui-cell border_top"></div>
        </div>
      </navigator>
      <div class="weui-flex text_center font_level_2 mb15">
        <div class="weui-flex__item" v-for="(item, index) in orderList" :key="index">
          <a class="placeholder mt26" :href="item.link">
            <image :src="item.icon" class="app-media-box__hd_in-26" />
            <div>{{item.name}}</div>
          </a>
        </div>
      </div>
    </div>
    <div class="box_10"></div>
    <div class="menu_list">
      <div class="weui-cell weui-cell_link" v-for="(item, index) in menueList" :key="index" @click="jumpHander(item)">
        <div class="weui-cell__hd">
          <image :src="item.icon" class="small_icon" />
        </div>
        <div class="weui-cell__bd ml16">{{item.name}}</div>
      </div>
      <div class="weui-cell border_top"></div>
    </div>
    <boqii-modal></boqii-modal>
  </div>
</template>

<script>
    import boqiiModal from '@/components/modal.vue'

    export default {
        components: {
            boqiiModal
        },
        computed: {},
        data() {
            return {
                accountList: [{
                    name: '优惠券',
                    icon: '/static/images/tuiguangma.png'
                }, {
                    name: '红包',
                    icon: '/static/images/tuiguangma.png'
                }, {
                    name: '排行榜',
                    icon: '/static/images/tuiguangma.png'
                }, {
                    name: '推广码',
                    icon: '/static/images/tuiguangma.png'
                }],
                orderList: [{
                    name: '待支付',
                    icon: '',
                    link: '/pages/order/list?status=1'
                }, {
                    name: '待收货',
                    icon: '',
                    link: '/pages/order/list?status=2'
                }, {
                    name: '待评价',
                    icon: '/static/images/order_daipingjia.png',
                    link: '/pages/order/list?status=3'
                }, {
                    name: '退款/售后',
                    icon: '',
                    link: '/pages/order/list?status=4'
                }],
                menueList: [{
                    name: '推客协议',
                    icon: '/static/images/account_address.png',
                    link: '/pages/account/totalProfit'
                }, {
                    name: '收货地址',
                    icon: '/static/images/account_address.png'
                }, {
                    name: '切换账号',
                    icon: '/static/images/account_change.png'
                }],
                profitDetail: [{
                    name: '总收益',
                    value: '¥15.0',
                    link: '/pages/account/totalProfit'
                }, {
                    name: '收益余额',
                    value: '¥15.0'
                }, {
                    name: '待返现',
                    value: '¥15.0',
                    link: '/pages/account/waitingReturn'
                }, {
                    name: '好友',
                    value: 15,
                    link: '/pages/account/myFriends'
                }]
            }
        },
        methods: {
            jumpHander(item) {
                let link = item && item.link ? item.link : ''
                if (link) this.$router.push(link)
            }
        }
    }
</script>

<style lang="scss" scoped>
    .account_index {
        background: #fff;
        .box_10 {
            width: 100%;
            height: 10px;
            background: #F5F5F9;
        }
        .weui-cell_link:first-child:before {
            display: none;
        }
        .order_more {
            .weui-cell_link {
                color: #444;
            }
            .weui-cell:before {
                left: 15px;
                right: 15px;
            }
        }
        .border_top {
            padding: 0px;
            margin: 0px;
            font-size: 0px;
        }
        .menu_list {
            .weui-cell_link {
                font-size: 15px;
                color: #444;
            }
            .small_icon {
                margin-right: 5px;
                vertical-align: middle;
                width: 20px;
                height: 20px;
                box-sizing: content-box;
            }
            .weui-cell:before {
                left: 15px;
            }
        }
        .account_order {
            margin-top: 12px;
            .order_item {
                width: 100%;
                height: 10px;
                background: #F5F5F9;
            }
        }
        .account_cotent {
            .tuike_bar {
                text-align: center;
                width: 336px;
                height: 35px;
                margin: 0px auto 12px auto;
            }
        }
    }
</style>