<template>
    <div>
        <GoodsItem >
            <template slot="goodsItemOther">
                <div class="goods-price">￥168</div>
                <div class="goods-item-price-action">
                    <div>
                        <p >预计返现¥32</p>
                        <p>
                            <span>评价 8838</span>
                            <span>已售 7883</span>
                        </p>
                    </div>
                    <div>
                        <button class="primary boqii-btn">去抢购</button>
                    </div>
                </div>
            </template>
        </GoodsItem>
        
        <div class="btn-block">
            <button class="primary boqii-btn">确认换购</button>
        </div>
        <button class="primary inline radius boqii-btn">分享</button>
        <button class="primary inline radius boqii-btn">立即使用</button>
        <span class="inline action-btn boqii-btn">申请售后</span>
        <span class="primary inline action-btn boqii-btn">申请售后</span>
        <span class="tag">神奇卡9.5折</span>
        <span class="tag magic">神奇卡9.5折</span>
        <span class="icon global-icon"></span>
        <span class="icon magic-icon"></span>
        <span class="icon black-magic-icon"></span>
        <span class="icon tip-icon"></span>
        <span class="icon kefu-icon"></span>
        <span class="icon kefu-color-icon"></span>
        <OrderGoodsItem />
        <CartGoodsItem />
    </div>
</template>

<script>
	import wx from 'wx'
    import GoodsItem from '@/components/goods-item.vue';
    import OrderGoodsItem from '@/components/order-goods-item.vue';
    import CartGoodsItem from '@/components/cart-goods-item.vue';

	export default {
		data() {
			return {
				name: "两行Orijen渴望 全犬粮六种鱼 2.27kg 贵宾泰迪犬专用粮商品名称展示"
			}
		},
		components: {
            GoodsItem,
            OrderGoodsItem,
            CartGoodsItem,
		}
	}
</script>
<style lang="scss">
    @import '@/style/mixin.scss';
    
	.goods-price{
		color: #F44633;
		font-size: 30rpx;
	}
	.goods-item-price-action{
		@include space-bewteen;
		font-size: 20rpx;
		color: #999;
    }
    .tag.magic{
        @include tag(#0FC4BB);
    }
    
</style>
