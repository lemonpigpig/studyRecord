<template>
    <div class="wrapper detail-page">
       <div class="goods-detail-info">
           <p class="goods-name">
               <span class="icon global-icon"></span>
               <span>牛油果Avoderm 幼犬鸡肉糙米助长配方狗粮26磅11.8kg香港直购【保质期至2018年12月3日】</span> 
           </p>
           <p class="goods-subtitle">
               品牌特惠 最高优惠350 抢购GO
           </p>
           <p class="goods-price">
               <span class="icon magic-icon"></span>
               <span class="goods-price">￥199</span>
               <span class="goods-origin-price">¥268</span>
               <span class="goods-unit">6.8元/斤</span>
           </p>
           <div class="share-fanxian">
               <p>不支持使用优惠券、波奇豆</p>
               <p>
                   <span class="icon redbag-icon"></span>分享返现
               </p>
           </div>
           <p class="goods-soldout">
               已售13489
           </p>
           <div class="tui-cell">
               <span class="icon magic-icon"></span>
               <span>下单再享9.5折，预计省 ¥18.8</span>
           </div>
           <div class="tui-cell">
               <span class="icon zhuan-icon"></span>
               <span>1726名推客通过该商品总共收益¥90000</span>
           </div>
           <div class="tui-cell">
               <span class="icon tui-icon"></span>
               <span>分享商品邀请好友购买，预计返现¥90</span>
               <span class="arrow arrow-right "></span>
           </div>
           <div class="goods-detail-service">
                <p class="tax-fee">
                    税费：<span class="free-tax">19:00元</span>
                </p>
                <p>
                    服务：本商品由香港2号仓发货
                </p>
                <div class="goods-detail-sale">
                    <p>
                        促销：
                            <span class="icon magic-icon"></span>
                            <span class="goods-detail-tag">神奇卡折上折</span>
                            <span class="goods-detail-discount">神奇卡会员78折</span>
                    </p>
                    <p>
                        <span class="icon more-icon"></span>
                    </p>
                </div>
            </div>
       </div>
       <div class="weui-cells">
            <a class="weui-cell weui-cell_access" href="javascript:;">
                <div class="weui-cell__bd">
                    <p class="boqii-text">授权文件</p>
                </div>
                <div class="weui-cell__ft">
                </div>
            </a>
        </div>

        <div class="global-service">
            <div class="global-service-title">
                <div>
                    <image class="flag" src="https://h5.boqiicdn.com/flag_usa.png" />
                    <span class="global-country"> 加拿大</span> 
                    <image class="flag" src="https://h5.boqiicdn.com/flag_usa.png" />
                    <span class="global-country"> 香港2号仓</span>
                </div>
                <div>
                    <span class="global-service-text">服务说明 </span><span class="icon tip-icon"></span>
                </div>
            </div>
            <div class="global-service-content">
                满99免运费，不满99元统一收取50元运费（不限地区、不限
                重量）下单后商品将从海外直接邮寄到您的手中。
            </div>
        </div>
        <div class="goods-detail-footer">
            <div class="goods-detail-footer-left">
                <span>
                    <i class="icon home-icon"></i>
                    首页
                </span>
                <span>
                    <i class="icon kefu-icon"></i>
                    客服
                </span>
            </div>
            <div class="goods-detail-footer-right">
                <span class="buy-now-button">立即购买</span>
                <span class="cart-button">加入购物车</span>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                imgUrls: [
                    'http://img02.tooopen.com/images/20150928/tooopen_sy_143912755726.jpg',
                    'http://img06.tooopen.com/images/20160818/tooopen_sy_175866434296.jpg',
                    'http://img06.tooopen.com/images/20160818/tooopen_sy_175833047715.jpg'
                ],
                indicatorDots: false,
                autoplay: false,
                interval: 5000,
                duration: 1000
            }
        }
    }
</script>
<style lang="scss">
    @import '@/style/mixin.scss';
    .detail-page{
        padding-bottom: 60px;
    }
    .buy-now-button{
        color: #F55B50;
        border: 2rpx solid #F55B50;
        margin-right: 20rpx;
    }
    .cart-button{
        color: #fff;
        background: #F55B50;
        border: 2rpx solid #F55B50;
    }
    .goods-detail-footer-left{
        span{
            display: inline-block;
            width: 44rpx;
            color: #666;
            font-size: 20rpx;
            font-weight: lighter;
            &:first-child{
                margin-right: 20rpx;
            }
        }
    }
    .goods-detail-footer-right{
        width: 70%;
        span{
            border-radius: 4rpx;
            font-size: 30rpx;
            padding: 18rpx 46rpx;
        }
    }
    .goods-detail-footer{
        display: flex;
        justify-content: space-between;
        border-top: 1px solid #dedede;
        background: #fff;
        position: fixed;
        left: 0;
        right: 0;
        bottom: 0;
        padding: 20rpx 34rpx 10rpx 34rpx;
    }
    .global-service-content{
        color: #999;
        font-size: 26rpx;
        font-weight: lighter;
        margin-top: 10px;
    }
    .global-service-text{
        color: #F55B50;
        font-size: 26rpx; 
    }
    .global-country {
        margin-right: 10rpx;
    }
    .global-service{
        padding: 25rpx 28rpx;
        background: #fff;
    }
    .flag{
        width: 28rpx;
        height: 28rpx;
        vertical-align: middle;
    }
    .global-service-title{
        display: flex;
        justify-content: space-between;
        .global-country{
            color: #444;
            font-size: 26rpx; 
            font-weight: lighter;
        }      
    }
    .arrow-right {
        @include arrow(right);
    }
    .boqii-text{
        color: #999;
        font-size: 26rpx;
    }

    .goods-detail-service{
        font-size: 26rpx;
        color: #999999;
        .goods-detail-sale{
            display: flex;
            justify-content: space-between;
        }
        p, .goods-detail-sale{
            margin-top: 15rpx;
        }
    }
    .free-tax{
        text-decoration: line-through;
    }
    .goods-detail-tag{
        color: #F44633;
        border: 1px solid #F44633;
        border-radius: 4rpx;
        font-size: 26rpx;
        padding: 4rpx 8rpx;
        margin-right: 10rpx;
    }
    .goods-detail-discount{
        font-size: 26rpx;
        color: #F55B50;
    }
    .goods-detail-info{
        background: #fff;
        padding: 30rpx;
        .goods-name{
            font-size: 32rpx;
            color: #444;
        }
        .goods-subtitle{
            font-size: 26rpx;
            color: #F55B50;   
            padding-top: 10rpx;
        }
        .goods-price{
            color: #F55B50;
            font-size: 40rpx;
            // margin-left: 12rpx;
            margin-right: 12rpx;
        }
        .goods-origin-price{
            color: #999;
            font-size: 26rpx;
            text-decoration: line-through;
        }
        .goods-unit{
            color: #666;
            font-size: 26rpx;
            margin-left: 12rpx;
        }
        .share-fanxian{
            @include space-bewteen;
            color: #999;
            font-size: 26rpx;
        }
        .goods-soldout{
            color: #999;
            font-size: 26rpx;
        }
        .magic-icon{
            transform: translateY(-5rpx);
        }
        .tui-cell{
            position: relative;
            background: #F5F5F9;
            border-radius: 8rpx;
            padding: 22rpx;
            color: #444;
            font-size: 26rpx;
            margin-top: 14rpx;
        }
        .redbag-icon{
            transform: translateY(-2.5rpx);
        }
    }   
</style>
