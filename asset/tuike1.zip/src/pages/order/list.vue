<template>
    <div class="order_list">
        <div v-for="(item, index) in orderList" :key="index">
             <div class="order_number_outer">
                <div class="font-clor_type2 font_level_1 order_number">
                    退货申请单号：{{item.orderNum}}
                </div>
            </div>
            <div v-for="(item, oindex) in item.list" :key="oindex">
                <OrderGoodsItem :list="item"/>
                <div><a href="/pages/order/detail">详情</a></div>
            </div>
            
            <div class="order_count">
                <div>共{{item.totalCount}}件商品 合计</div>
                <div class="order_total">￥{{item.totalMoney}}</div>
            </div>
        </div>
    </div>
</template>

<script>
    import wx from 'wx'
    import OrderGoodsItem from '@/components/order-goods-item.vue';
    export default {
        components: {
            OrderGoodsItem
        },
        data() {
            return {
                orderList: []
            }
        },
        methods: {
            getList() {
                wx.showLoading()
                setTimeout(() => {
                        wx.hideLoading()
                        this.orderList = [{
                            list: [{
                                name: 'NOW成年犬粮小型犬 5L 无谷犬粮无谷犬粮',
                                count: 2,
                                specific: '5L',
                                price: 100,
                                img: 'http://img-new.boqiicdn.com/Data/Shop/0/28/2849/shoppicpath11525232526_y.jpg?imageView2/2/w/375/h/375/q/100/interlace/0'
                            }],
                            orderNum: '983',
                            totalMoney: 200,
                            totalCount: 2

                        }, {
                            list: [{
                                name: 'ddddddNOW成年犬粮小型犬 5L 无谷犬粮无谷犬粮',
                                count: 2,
                                specific: '5L',
                                price: 100,
                                img: 'http://img-new.boqiicdn.com/Data/Shop/0/28/2849/shoppicpath11525232526_y.jpg?imageView2/2/w/375/h/375/q/100/interlace/0'
                            }, {
                                name: 'ddddddNOW成年犬粮小型犬 5L 无谷犬粮无谷犬粮',
                                count: 4,
                                specific: '6L',
                                price: 800,
                                img: 'http://img-new.boqiicdn.com/Data/Shop/0/28/2849/shoppicpath11525232526_y.jpg?imageView2/2/w/375/h/375/q/100/interlace/0'
                            }],
                            orderNum: '984',
                            totalMoney: 200,
                            totalCount: 2
                        }]
                    },
                    1000)
            }
        },
        onLoad() {
            let {
                status
            } = this.$route.query
            status = status ? Number(status) : -1
            let title = ''
            if (status === 1) {
                title = '待支付'
            } else if (status === 2) {
                title = '待收货'
            } else if (status === 3) {
                title = '待评价'
            } else if (status === 4) {
                title = '退款/售后'
                this.getList(status)
            }
            wx.setNavigationBarTitle({
                title: title
            })
            console.log('title:', title, 'status:', typeof status)
        }
    };
</script>

<style lang="scss" scoped>
    .order_list {
        .order_number_outer {
            padding-left: 15px;
            margin-bottom: 10px;
            .order_number {
                border-bottom: 1px solid #DEDEDE;
            }
        }
        .order_count {
            height: 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-sizing: border-box;
            padding: 14px;
            font-size: 15px;
            .order_total {
                color: #F55B50;
            }
        }
    }
</style>