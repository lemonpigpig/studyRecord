<template>
    <div class="order_detail">
        <div class="order_status">
            <div class="order_progress">
                <div class="order_progress_title">
                    审核结果倒计时
                </div>
                <div class="order_progress_timer">
                    <span>
                        47
                    </span>
                    <span>
                        :
                    </span>
                    <span>
                        59
                    </span>
                    <span>
                        :
                    </span>
                    <span>
                        59
                    </span>
                </div>
                <div class="status_help">!</div>
            </div>
            <div class="order_progress_desp font_level_1 font-clor_type3">
                <span>
                    如果48小时内客服没有响应，将自动审核通过
                </span>
            </div>
        </div>
        <div class="box_10"></div>
    </div>
</template>

<script>
    import wx from 'wx'
    import OrderGoodsItem from '@/components/order-goods-item.vue';
    export default {
        components: {
            OrderGoodsItem
        },
        data() {
            return {
                orderList: []
            }
        },
        methods: {
            getList() {
                // wx.showLoading()
            }
        },
        onLoad() {}
    };
</script>

<style lang="scss" scoped>
    .order_detail {
        .order_status {
            text-align: center;
            padding: 28px 0 28px 0;
            .order_progress {
                font-size: 0px;
                &>div {
                    display: inline-block;
                    vertical-align: middle;
                }
                .order_progress_title {
                    color: #F55B50;
                    font-size: 17px;
                    line-height: 24px;
                }
                .order_progress_timer {
                    color: #fff;
                    margin-left: 6px;
                    &>span {
                        display: inline-block;
                        vertical-align: middle;
                    }
                    &>span:nth-child(2n+1) {
                        font-size: 11px;
                        width: 20px;
                        height: 20px;
                        background-image: linear-gradient(-180deg, #FF895A 0%, #F55B50 93%);
                        border-radius: 4px;
                        line-height: 20px;
                    }
                    &>span:nth-child(2n) {
                        font-size: 15px;
                        color: #F55B50;
                        padding: 0 3px 0 3px;
                    }
                }
                .status_help {
                    width: 14px;
                    height: 14px;
                    text-align: center;
                    font-size: 13px;
                    color: #F55B50;
                    border: 1px solid #F55B50;
                    border-radius: 14px;
                    line-height: 14px;
                    margin-left: 11px;
                }
            }
            .order_progress_desp {
                margin-top: 9px;
            }
        }
    }
</style>