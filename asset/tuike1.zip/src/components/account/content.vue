<template>
    <div class="content">
        <scroll-view scroll-y style="height:100%;" @scroll="scrollFn" @scrolltolower="toLow" @scrolltoupper="test">
            <a href="#" class="feed-li" v-for="(item,index) in currentTab" :key="index">
                <div class="feed-content">
                    <img :src="item.avatar" alt="用户头像" style="width:72rpx;height:72rpx" v-if="showImg">
                    <div class="feed-right">
                        <div class="feed-right-top">
                            <div class="avatar-name">
                                {{item.name}}
                            </div>
                            <div class="count">
                                 {{item.type}}
                            </div>
                        </div>
                        <div class="feed-right-bottom">
                            <div class="feed-time">
                                {{item.time}}
                            </div>
                            <div class="feed-pass">
                                +99.9
                            </div>
                        </div>
                    </div>
                </div>
                <div class="feed-title">
                    <p class="font_color_strong">*转账失败的金额已返回您的账户</p>
                </div>
            </a>
        </scroll-view>
    
    </div>
</template>

<script>
    // import request from '@/utils/request'
    // import avatar from '@/components/avatar'
    
    export default {
        data() {
            return {
                articleList: [],
                page: 1
            }
        },
        props: {
            showImg: {
                type: Boolean,
                default: true
            },
            currentTab: {
                default: []
            } 
        },
        methods: {
            test() {
                console.log('test')
            },
            async getList(page = 1) {
                wx.showLoading({
                    title: '加载中'
                })
                // let res = await request.get('topics', {
                //     tab: this.currentTab.type,
                //     page,
                //     limit: 20,
                // })
                // if (res.success) {
                //     this.articleList = this.articleList.concat(res.data);
                // }
                wx.hideLoading()
            },
            scrollFn(e) {
                // console.log(e)
            },
            async getA() {
                return 'a'
            },
            toLow(e) {
                // 这里就是滚动到底部了
                this.page++;
                this.getList(this.page)
            }
        },
        computed: {
            list() {
                return this.articleList
                // return this.articleList.map(item => {
                //     delete item.content
                //     return Object.assign(item, {
                //         createTime: this.formatTime(item.create_at),
                //         lastReplyTime: this.fromNow(item.last_reply_at)
                //     })
                // })
            }
        },
        components: {
            // avatar
        },
        async created() {
            this.getList()
        }
    }
</script>

<style lang="scss" scoped>
    .content {
        height: 100%;
        .feed-li {
            padding: 0px 15px 20px 15px;
            // border-bottom: 1px solid #f2f2f2;
            .feed-title {
                display: flex;
                align-items: center;
                min-width: 0;
                p {
                    margin: 0 0 0 8px;
                    font-size: 12px;
                    line-height: 24px;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    overflow: hidden;
                    flex: 1;
                    min-width: 0;
                }
            }
            .feed-content {
                display: flex;
                position: relative;
                font-size: 13px;
                margin-top: 8px;
                .feed-right {
                    flex: 1;
                    min-width: 0;
                    margin-left: 8px;
                    .feed-right-top {
                        display: flex;
                        justify-content: space-between;
                        .author-name {}
                        .count {
                            span {
                                color: red;
                            }
                        }
                    }
                    .feed-right-bottom {
                        margin-top: 4px;
                        display: flex;
                        justify-content: space-between;
                        .feed-time {
                            font-size: 12px;
                            color: #666;
                        }
                    }
                }
            }
        }
    }
</style>
