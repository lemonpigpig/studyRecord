<template>
    <div class="profit_header">
        <div class="profit_title">
            {{title}}
            <span v-if="show">?</span>
        </div>
        <div class="weui-panel__ft">
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__bd count" v-if="money">{{money}}</div>
                <div class="weui-cell__ft weui-cell__ft_in-access" v-if="type === 1">
                    <a href="/pages/account/myBalance">收益账户</a>
                </div>
                <div class="weui-cell__ft weui-cell__ft_in-access" v-if="type === 5">
                    <a href="/pages/account/editPasw">绑定/修改密码</a>
                </div>
                <slot name="more_descp"></slot>
                <slot name="more_descp1"></slot>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        // 1总收益 2 收益余额 3待返现 4好友 5账户余额
        props: {
            type: {
                type: Number,
                default: 1
            },
            money: {
                required: false
            }
        },
        computed: {
            show() {
                if (this.type) {
                    return [1, 2, 3].indexOf(this.type) > -1
                }
                return false
            },
            title() {
                if (this.type === 1) {
                    return '总收益'
                } else if (this.type === 2) {
                    return '收益余额'
                } else if (this.type === 3) {
                    return '待返现'
                } else if (this.type === 4) {
                    return '我的好友'
                } else if (this.type === 5) {
                    return '账户余额'
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
    .profit_header {
        background: #f55b50;
        width: 374px;
        height: 110px;
        color: #fff;
        font-size: 13px;
        .profit_title {
            font-size: 15px;
            text-align: left;
            padding: 15px 18px 5px 15px;
        }
        .weui-cell_access {
            .weui-cell__ft:after {
                border-color: #fff;
            }
        }
        .weui-cell:first-child:before {
            display: none;
        }
        .weui-cell__ft_in-access {
            color: inherit;
        }
        .weui-panel__ft {
            height: 49px;
            box-sizing: content-box;
        }
        .count {
            font-size: 35px;
            line-height: 48px;
        }
    }
</style>