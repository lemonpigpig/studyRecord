<template>
    <div class="order-goods-item">
        <div class="order-goods-poster-container">
            <image 
                class="order-goods-poster" 
                mode="aspectFit" 
                :src="list.img" 
            />
        </div>
        <div class="order-goods-info">
            <div>
                <p class="order-goods-name"> <span class="icon global-icon"></span>{{list.name}}</p>
                <p class="order-goods-price">￥{{list.price}}</p>
            </div>
            <div>
                <p class="order-goods-spec">规格：{{list.specific}}</p>
                <p class="order-goods-num">x {{list.count}}</p>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        props: {
            list: {
                type: Object,
                default: {}
            }
        },
        create() {

        }
    }
</script>
<style lang="scss">
    @import '@/style/mixin.scss';
    .order-goods-item {
        display: flex;
        padding: 0 30rpx 32rpx 30rpx;
        .order-goods-poster-container {
            margin-right: 36rpx;
            width: 144rpx;
            height: 164rpx;
            border: 1px solid #DEDEDE;
        }
        .order-goods-poster {
            width: 144rpx;
            height: 164rpx;
        }
        .order-goods-info {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            >div {
                @include space-bewteen;
            }
        }
        .order-goods-name {
            font-size: 28rpx;
            color: #444;
            width: 80%;
        }
        .order-goods-price {
            font-size: 26rpx;
            color: #444;
        }
        .order-goods-spec,
        .order-goods-num {
            font-size: 26rpx;
            color: #999;
        }
    }
</style>