<template>
    <div>
        fff1 <input type="checkbox" v-bind:checked="checked" @regionchange="test">
    </div>
   
</template>

<script>
    // $emit('change-my', $event.target.checked)
    export default {
        model: {
            prop: 'checked',
            event: 'change'
        },
        props: {
            checked: Boolean
        },
        methods: {
            test() {
                console.log(123)
            }
        }
    }
</script>
