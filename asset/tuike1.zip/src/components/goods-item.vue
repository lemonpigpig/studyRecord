<template>
    <div>
        <div class="goods-item">
            <div class="goods-item-poster">
                <div class="goods-item-poster-inner">
                    <image mode="aspectFit" class="goods-item-poster-img" src="http://img-new.boqiicdn.com/Data/Shop/0/4/485/shoppicpath11522401816_y.jpg?imageView2/2/w/375/h/375/q/100/interlace/0" />
                    <image mode="aspectFit" class="goods-item-soldout" src="https://h5.boqiicdn.com/sold_out_bgs.png" />
                </div>
            </div>
            <div class="goods-item-info">
                <p class="goods-item-name"><span class="icon global-icon"></span>两行Orijen渴望 全犬粮六种鱼 2.27kg 贵宾泰迪犬专用粮商品名称展示</p>
                <slot name="goodsItemOther"></slot>
            </div>
        </div>
        <div class="goods-item">
            <div class="goods-item-poster">
                <div class="goods-item-poster-inner">
                    <image mode="aspectFit" class="goods-item-poster-img" src="http://img-new.boqiicdn.com/Data/Shop/0/4/485/shoppicpath11522401816_y.jpg?imageView2/2/w/375/h/375/q/100/interlace/0" />
                </div>
            </div>
            <div class="goods-item-info">
                <p class="goods-item-name">两行Orijen渴望 全犬粮六种鱼 2.27kg 贵宾泰迪犬专用粮商品名称展示</p>
                <slot name="goodsItemOther"></slot>
            </div>
        </div>
    </div>
</template>

<script>
	export default {
		// props: ['goodsname'],
		create() {

		},
	}
</script>

<style lang="scss">
	@import '@/style/mixin.scss';

	.goods-item{
		display: flex;
        padding: 26rpx 34rpx 30rpx 34rpx;
        border-bottom: 0.5rpx solid #DEDEDE;
        &:last-child{
            border-bottom: none;
        }
        .goods-item-poster{
            margin-right: 40rpx;
        }
		image.goods-item-poster-img{
			width: 180rpx;
			height: 180rpx;
            margin-right: 54rpx;
        }
    }
    .goods-item-poster-inner{
        position: relative;
        width: 180rpx;
        height: 180rpx;
        .goods-item-soldout{
            position: absolute;
            left: 0;
            top: 0;
             width: 180rpx;
        height: 180rpx;
        }
    }
	.goods-item-name{
		font-size: 28rpx;
		color: #444;
		@include two-column(2);
	}
</style>
