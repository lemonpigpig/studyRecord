<template>
    <div class="boqii_modal" v-if="show" @click="close($event)">
        <div class="boqii_mask" id="boqii_mask"></div>
        <div class="boqii-modal_content">
            <div class="text_center">
                <slot name="header">
                    <div class="boqii_title text_center">什么是待返现收益？</div>
                </slot>
            </div>
    
            <slot name="body"></slot>
            <slot name="footer">
                <div class="boqii_btn" id="boqii_close">知道了</div>
            </slot>
        </div>
    
    </div>
</template>


<script>
    // import {
    //     mapState,
    //     mapMutations
    // } from 'vuex';

    export default {
        name: 'boqiiModal',
        props: {
            show: {
                type: Boolean,
                default: false
            }
        },
        data() {
            return {}
        },
        computed: {
            // ...mapState([
            //     "showModal"
            // ])
        },
        methods: {
            // ...mapMutations([
            //     "toggle_modal_mution"
            // ]),
            close(event) {
                let {
                    target
                } = event
                let id = target.id
                console.log('id:', id)
                if (id === 'boqii_mask' || id === 'boqii_close') {
                    // this.toggle_modal_mution(false)
                    // this.showModal = false
                    this.$emit('closeModal', false)
                }
            }
        }
    }
</script>

<style lang="scss" scoped>
    .boqii_modal {
        .boqii_mask {
            position: fixed;
            top: 0px;
            left: 0px;
            bottom: 0px;
            right: 0px;
            width: 100%;
            height: 100%;
            background: #000;
            opacity: .5;
            z-index: 998;
        }
        .boqii-modal_content {
            width: 280px;
            border-radius: 4px;
            position: absolute;
            transform: translate(-50%, -50%);
            background: #fff;
            top: 50%;
            left: 50%;
            z-index: 999;
        }
        .boqii_title {
            font-size: 18px;
            color: #444444;
        }
    }
</style>