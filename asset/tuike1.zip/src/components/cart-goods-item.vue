<template>
     <div class="cart-goods-item">
        <div class="cart-goods-poster-container">
            <image 
                class="cart-goods-poster" 
                mode="aspectFit" 
                src="http://img-new.boqiicdn.com/Data/Shop/0/28/2849/shoppicpath11525232526_y.jpg?imageView2/2/w/375/h/375/q/100/interlace/0" 
            />
            <image 
                class="cart-goods-soldout"
                mode="aspectFit"
                src="https://h5.boqiicdn.com/cart-soldout.png"
            />
        </div>
        <div class="cart-goods-info">
            <div>
                <p class="cart-goods-name">NOW成年犬粮小型犬 5L 无谷犬粮无谷犬粮</p>
                <p class="cart-goods-notice">商品售罄</p>
            </div>
        </div>
    </div>
</template>
<script>
    export default {

    }
</script>
<style lang="scss">
    .cart-goods-item{
        display: flex;
        padding: 0 30rpx 32rpx 30rpx;
        .cart-goods-poster-container{
            width: 166rpx;
            height: 166rpx;
            border: 1px solid #dedede;
            margin-right: 20rpx;
            position: relative;
        }
        .cart-goods-poster{
            width: 166rpx;
            height: 166rpx;
        }
        .cart-goods-soldout{
            position: absolute;
            left: 50%;
            top: 50%;
            width: 100rpx;
            height: 100rpx;
            transform: translate3d(-50%, -50%, 0);
        }
        .cart-goods-name{
            font-size: 26rpx;
            color: #444;
        }
        .cart-goods-notice{
            font-size: 24rpx;
            color: #999;
        }
    }
</style>
