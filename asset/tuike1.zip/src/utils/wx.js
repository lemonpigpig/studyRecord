/* eslint-disable */
export default wx
