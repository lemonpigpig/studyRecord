export default {
	showModal1: state => state.showModal
}
