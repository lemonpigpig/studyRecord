import Vue from 'vue'

export default {
	fetchmovies (state, data) {
		return state.movies = data;
	},
	fetchmovie_mution (state, data) {
		return state.movie = data;
	},
	// toggle_modal_mution (state, data) {
	// 	Vue.set(state, 'showModal', data)
	// }
}
