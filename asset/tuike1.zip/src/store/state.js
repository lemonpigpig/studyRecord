export default {
	movies: {},
	movie: {},
	// showModal: false
}
