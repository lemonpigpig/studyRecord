import { getAllMovies, getMovie } from "../action"

export const addOn = ({ commit }) => {
	commit('increment')
}

export const getMovies = ({ commit }, params={}) => {
	return getAllMovies(params)
}

// 第一个参数 是 store
export const getMovieItem = ({ commit }, params = {}) => {

	return getMovie(params)
}
