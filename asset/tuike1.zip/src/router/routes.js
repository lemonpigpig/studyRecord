module.exports = [{
        path: '/pages/demo',
        name: 'Demo',
        config: {
            navigationBarTitleText: 'demo页面',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/comp/index',
        name: 'Comp',
        config: {
            navigationBarTitleText: '组件页',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/goodsdetail/index',
        name: 'Detail',
        config: {
            navigationBarTitleText: '详情页',
            enablePullDownRefresh: true
        }
    },

    {
        path: '/pages/index/index',
        name: 'Index',
        config: {
            navigationBarTitleText: '首页',
            enablePullDownRefresh: true
        }
    },

    {
        path: '/pages/vuex/index',
        name: 'Vuex',
        config: {
            navigationBarTitleText: 'vuex 测试页'
        }
    },
    {
        path: '/pages/logs/index',
        name: 'Logs',
        config: {
            navigationBarTitleText: '日志'
        }
    },
    {
        path: '/pages/account/index',
        name: 'Account',
        config: {
            navigationBarTitleText: '个人中心',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/account/totalProfit',
        name: 'TotalProfit',
        config: {
            navigationBarTitleText: '总收益',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/account/waitingReturn',
        name: 'WaitingReturn',
        config: {
            navigationBarTitleText: '待返现',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/account/myFriends',
        name: 'MyFriends',
        config: {
            navigationBarTitleText: '我的好友',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/account/myBalance',
        name: 'MyBalance',
        config: {
            navigationBarTitleText: '我的余额',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/account/editPasw',
        name: 'EditPasw',
        config: {
            navigationBarTitleText: '设置支付密码',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/account/validate',
        name: 'Validate',
        config: {
            navigationBarTitleText: '安全验证',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/account/coupon',
        name: 'Coupon',
        config: {
            navigationBarTitleText: '我的红包',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/account/withdrawForm',
        name: 'WithdrawForm',
        config: {
            navigationBarTitleText: '提现到支付宝',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/order/list',
        name: 'OrderList',
        config: {
            navigationBarTitleText: '',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/order/detail',
        name: 'OrderDetail',
        config: {
            navigationBarTitleText: '退款详情',
            enablePullDownRefresh: true
        }
    },
    {
        path: '/pages/order/refund',
        name: 'Refund',
        config: {
            navigationBarTitleText: '申请退款',
            enablePullDownRefresh: true,
            background: '#F5F5F9'
        }
    }
]