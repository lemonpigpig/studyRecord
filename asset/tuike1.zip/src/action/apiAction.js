import store from '@/store';

import wx from 'wx'
import Fly from 'flyio'

const fly = new Fly()

fly.interceptors.request.use((request) => {
	wx.showNavigationBarLoading()
	return request
})

fly.interceptors.response.use(
	(response, promise) => {
		wx.hideNavigationBarLoading()
		return promise.resolve(response.data)
	},
	(err, promise) => {
		wx.hideNavigationBarLoading()
		wx.showToast({
			title: err.message,
			icon: 'none'
		})
		return promise.resolve()
	}
)

export default function(apiConfig = {}) {
	return function(params = {}){
		// 加载前的状态
		store.commit(apiConfig.state, {
			loading: true
    	});

	fly.request("https://www.v2ex.com/api/topics/latest.json",{hh:5},{
		method: apiConfig.method,
		timeout: 5000 //超时设置为5s
	 })
	.then(data=>{
		console.log("获取的数据")
		console.log(data)
		store.commit(apiConfig.state, Object.assign(data, {loading: false}));
        return Promise.resolve(data);
	})
	.catch((e) => console.log("error", e))

	}
}
