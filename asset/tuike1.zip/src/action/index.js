
import apiAction from './apiAction';

export const getAllMovies = apiAction({
	method: 'GET',
	url: 'movie/in_theaters',
	state: 'fetchmovies',
});

export const getMovie = apiAction({
	method: 'GET',
	url: 'book/1220562',
	state: 'fetchmovie_mution',
});
