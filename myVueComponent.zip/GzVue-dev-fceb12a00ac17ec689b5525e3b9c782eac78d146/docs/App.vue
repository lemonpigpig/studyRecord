<template lang="pug">
    #app
        transition(name="slide" mode="out-in")
            router-view(@view="meta")
</template>
<script>
    import { mapGetters, mapActions } from 'vuex';

    export default {
        methods: {
            ...mapActions([
                'updateTitle',
                'updateDescription',
                'updateKeywords',
            ]),
            meta(obj) {
                this.updateTitle(obj.title);
            }
        }
    };
</script>
<style lang="stylus">
    @import "./stylus/_theme-sky";
    @import "../src/stylus/main";
    @import "./stylus/doc";
</style>
