<template lang="pug">
    div
        .fn-clear
            h3.code__title.fn-left {{title}}
            .code__toggle.fn-right(@click='showCode = !showCode') code
        doc-code(lang="html" v-show="showCode" ":code"="content")
        .fn-clear(v-if="iframeWidth")
            span.iframe__btn(@click="setWidth(320)" ":class"="{ 'iframe__btn--active': iframeWidth == '320px' }") Mobile S - 320px
            span.iframe__btn(@click="setWidth(375)" ":class"="{ 'iframe__btn--active': iframeWidth == '375px' }") Mobile M - 375px
            span.iframe__btn(@click="setWidth(425)" ":class"="{ 'iframe__btn--active': iframeWidth == '425px' }") Mobile L - 425px
            span.iframe__btn(@click="setWidth(768)" ":class"="{ 'iframe__btn--active': iframeWidth == '768px' }") Tablet - 768px
            span.iframe__btn(@click="setWidth(1024)" ":class"="{ 'iframe__btn--active': iframeWidth == '1024px' }") Laptop - 1024px
            span.iframe__btn(@click="setWidth()" ":class"="{ 'iframe__btn--active': iframeWidth == '100%' }") Auto - 100%
            span.iframe__btn(@click="openNewTab()" v-if="src") Open New Tab
        template(v-if="file")
            div(":style"="{ width: iframeWidth }")
                div(":ref"="'example' + _uid")
        template(v-else)
            iframe.iframe__wrapper(":src"="'/' + src" frameborder="0" ":style"="{ width: iframeWidth }")
</template>
<script>
    import Vue from 'vue';

    export default {
        data() {
            return {
                showCode: false,
                template: null,
                content: null,
                iframeWidth: false
            };
        },
        props: {
            title: String,
            file: String,
            src: String,
            width: String,
            data: {
                type: Object,
                default() {
                    return {
                        example: true
                    };
                }
            }
        },
        mounted() {
            if (this.width) {
                if (this.width === '100%') {
                    this.iframeWidth = this.width;
                } else {
                    this.iframeWidth = `${this.width}px`;
                }
            }

            if (this.file) {
                this.request(`/example/${this.file}`, this.boot);
            } else {
                this.request(`/example/${this.src}.vue`, this.renderCode);
            }
        },
        methods: {
            setWidth(width) {
                if (width) {
                    this.iframeWidth = `${width}px`;
                } else {
                    this.iframeWidth = '100%';
                }
            },
            renderCode(res) {
                this.content = res.replace(/</g, '&lt;').replace(/>/g, '&gt;');
            },
            boot(res) {
                this.template = res;
                this.renderCode(res);
                const render = Vue.compile(this.template);
                const vm = this;

                new Vue({
                    data() {
                        return vm.data;
                    },
                    render: render.render,
                    staticRenderFns: render.staticRenderFns
                }).$mount(this.$refs[`example${vm._uid}`]);
            },
            request(file, cb) {
                const xmlhttp = new XMLHttpRequest();
                const vm = this;
                const timeout = setTimeout(() => (this.loading = true), 500);
                xmlhttp.open('GET', `${file}`, true);

                xmlhttp.onreadystatechange = () => {
                    if (xmlhttp.status === 200 && xmlhttp.readyState === 4) {
                        clearTimeout(timeout);
                        vm.loading = false;
                        cb(xmlhttp.responseText);
                    }
                };
                xmlhttp.send();
            },
            openNewTab() {
                window.open(`/${this.src}`);
            }
        }
    };
</script>
