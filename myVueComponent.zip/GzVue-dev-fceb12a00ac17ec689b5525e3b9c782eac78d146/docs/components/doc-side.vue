<template lang="pug">
    aside.doc__side
        .doc__banner
            router-link(to="/quick-start")
                img(src="/public/img/banner.png")
                h1 GZ
                    span.ft-green &nbsp;Vue
        doc-nav
</template>
