<template lang="pug">
  div.section__api
    table(v-for="(value, key) in parameters")
      caption
        strong {{ key }}
      thead
        tr
          th(v-for="title in titles") {{ title }}
      tbody
        tr(v-for="item in value")
          td(v-for="(text, index) in item")
            span(v-if="index === 0") <code>{{ text }}</code>
            span(v-else) {{ text }}
</template>
<script>
  export default {
    props: {
      titles: {
        type: Array,
        default: () => []
      },

      parameters: {
        type: Object,
        default: () => {}
      },
    }
  }
</script>
<style lang="stylus">
</style>