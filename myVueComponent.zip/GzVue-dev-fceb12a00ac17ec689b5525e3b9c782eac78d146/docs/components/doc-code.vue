<template lang="pug">
  .code__panel
    template(v-if="!copied")
      .code__copy(@click="copyCode") copy
    template(v-else)
      .code__copy--copied copied
    textarea(
      ref="copyTextarea"
      v-if="copyContent"
    ) {{copyContent}}
    pre
      template(v-if="code")
        code(ref="code" v-highlight="lang" v-html="code")
      template(v-else)
        code(ref="code" v-highlight="lang")
          slot
</template>
<script>
  import Vue from 'vue';

  export default {
    data () {
      return {
        copyContent: null,
        copied: false
      }
    },
    props: {
      lang: String,
      code: String
    },
    methods: {
      copyCode () {
        this.copyContent = this.$refs.code.innerText

        this.$nextTick(() => {
          this.$refs.copyTextarea.select()
          document.execCommand('copy')
          this.copyContent = null
          this.copied = true
          setTimeout(() => this.copied = false, 2000)
        })
      },
    }
  }
</script>