<template lang="pug">
  // auto gen
  ul
    li.nav__group(@click="toggleComponent")
      .nav__title Components
    ul(v-if="toggleComponents")
      li.nav__li
        router-link(to="/components/calendar") calendar
      li.nav__li
        router-link(to="/components/datetime-picker") datetime-picker
      li.nav__li
        router-link(to="/components/gallery") gallery
      li.nav__li
        router-link(to="/components/icons") icons
      li.nav__li
        router-link(to="/components/lazyload") lazyload
      li.nav__li
        router-link(to="/components/loadmore") loadmore
      li.nav__li
        router-link(to="/components/notify") notify
      li.nav__li
        router-link(to="/components/picker") picker
      li.nav__li
        router-link(to="/components/popover") popover
      li.nav__li
        router-link(to="/components/rich-text") rich-text
      li.nav__li
        router-link(to="/components/rich-text-pro") rich-text-pro
      li.nav__li
        router-link(to="/components/rich-text-viewer") rich-text-viewer
      li.nav__li
        router-link(to="/components/scroller") scroller
      li.nav__li
        router-link(to="/components/slider") slider
      li.nav__li
        router-link(to="/components/toast") toast
      li.nav__li
        router-link(to="/components/uploader") uploader
      li.nav__li
        router-link(to="/components/zoom-preview") zoom-preview
    li.nav__group(@click="toggleDirective")
      .nav__title Directives
    ul(v-if="toggleDirectives")
      li.nav__li
        router-link(to="/directives/dpr") dpr
      li.nav__li
        router-link(to="/directives/external-link") external-link
      li.nav__li
        router-link(to="/directives/loading") loading
</template>
<script>
    export default {
        data() {
            return {
                toggleComponents: false,
                toggleDirectives: false
            };
        },
        mounted() {
            if (this.$route.path.indexOf('/components/') > -1) {
                this.toggleComponents = true;
            }
            if (this.$route.path.indexOf('/directives/') > -1) {
                this.toggleDirectives = true;
            }
        },
        methods: {
            toggleComponent() {
                this.toggleComponents = !this.toggleComponents;
                this.toggleDirectives = !this.toggleComponents;
            },
            toggleDirective() {
                this.toggleDirectives = !this.toggleDirectives;
                this.toggleComponents = !this.toggleDirectives;
            }
        }
    }
</script>