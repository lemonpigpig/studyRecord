export const ZVUETITLE = 'zvue/TITLE';
export const ZVUEDESCRIPTION = 'zvue/DESCRIPTION';
export const ZVUEKEYWORDS = 'zvue/KEYWORDS';