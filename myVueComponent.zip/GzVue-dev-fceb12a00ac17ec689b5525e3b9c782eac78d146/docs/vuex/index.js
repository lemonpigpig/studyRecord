import Vue from 'vue';
import Vuex from 'vuex';

import domStore from './dom/store';

Vue.use(Vuex);

export default new Vuex.Store({
    modules: {
        dom: domStore
    },
    strict: process.env.NODE_ENV !== 'production',
});
