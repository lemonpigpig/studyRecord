<template lang="pug">
    doc-view(":api"="api")
        h3.section__h3 使用前请在 html body 中引入该 js
        doc-code &lt;script src="http://10.66.30.40:1024/public/img/gz-vue/icons/icons-symbol.js"&gt;&lt;/script&gt;
        doc-example(file="components/icons/1" title="基本用法")
</template>

<script>
    import api from './api';

    export default {
        data() {
            return {
                api: api
            };
        }
    };
</script>
