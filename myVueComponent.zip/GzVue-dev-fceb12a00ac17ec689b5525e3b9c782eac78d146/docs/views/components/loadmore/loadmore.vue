<template lang="pug">

	doc-view(":api"="api")
		doc-example(src="components/loadmore/1" title="上拉加载下拉刷新" width="320")
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            api: api
        }
    },
    methods: {

    }
}
</script>
