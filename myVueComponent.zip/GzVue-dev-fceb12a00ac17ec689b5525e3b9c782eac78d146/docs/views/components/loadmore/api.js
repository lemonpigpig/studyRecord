export default {
    title: 'Loadingmore',
    description: '加载更多组件包括上滑加载，下拉更新',
    author: '贺贤娟-lemon',
    props: {
        'loadermore': [
            [
                'autoFill',
                'Boolean',
                'true',
                '自动执行上滑加载第一页的数据'
            ],
            [
                'loadBottomFuc',
                'Function',
                '-',
                '上滑加载更多的处理函数，数据请求完毕后要掉用一下setBottomLoaded函数重置一下上滑状态'
            ],
            [
                'loadTopFuc',
                'Function',
                '-',
                '下拉刷新处理函数，数据请求完毕后要调用一下setTopLoaded函数重置一下下拉状态'
            ]
        ]
    },
    functional: {
        'loadmore': [
            [
                'setBottomLoaded',
                '上滑加载完成后重置load的状态'
            ],
            [
                'setTopLoaded',
                '下拉刷新加载完成后重置load的状态'
            ],
            [
                'setAllLoaded',
                '设置页面不可滑动'
            ],
            [
              'setNoResult',
              '显示没有更多'
            ]
        ]
    }
}
