<template>
    <div>
        <gz-loadmore :load-bottom-fuc="loadingBottomHandler" :load-top-fuc="loadingTopHandler" ref="gzLoadmore" :autoFill="false">
            <div class="lists">
               你自己的分页模版
            </div>
        </gz-loadmore>
    </div>
</template>

<script>
export default {
    data() {
        return {

        }
    },
    methods:{
      loadingBottomHandler (){
        alert('上滑加载更多!');
      },
      loadingTopHandler (){
        alert('下拉刷新!');
      }
    }
}
</script>


