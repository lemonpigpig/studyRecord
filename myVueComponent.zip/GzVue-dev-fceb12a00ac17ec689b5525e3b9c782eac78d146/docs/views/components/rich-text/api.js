export default {
    title: 'RichText',
    author: '张锐-Ken',
    description: '富文本编辑组件',
    props: {
        'RichText': [
            [
                'allowTags',
                'Array<String>',
                "['paragraph', 'image', 'header', 'list']",
                '组件允许使用的插件',
            ],
            [
                'nodeClass',
                'Object',
                '-',
                '不同类型插件的自定义class, 举例: { paragraph: ["class-a", "class-b"], image: ["class-img"] }',
            ],
            [
                'defaultContents',
                'Array<Object>',
                "-",
                '组件的初始数据',
            ],
        ]
    },
    events: {
        'RichText': [
            [
                'input',
                'contents:Array',
                '用户的任何操作都会触发input事件',
            ],
            [
                'img-click',
                'e: 点击事件Event, \n id: contents 中的数据块标识, \n setContent(id, imgUrl): 设置当前 img 元素 content 的回调方法',
                '点击图片标签中的图片触发事件',
            ]
        ]
    },
};
