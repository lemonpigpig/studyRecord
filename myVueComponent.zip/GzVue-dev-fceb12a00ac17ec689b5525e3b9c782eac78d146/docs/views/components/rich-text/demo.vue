<template lang="html">
    <div class="gz-rich-text-demo">
        <gz-rich-text
            @img-click="imgClickHandler"
            v-model="contents">
        </gz-rich-text>
        <pre><code>{{contentsString}}</code></pre>
    </div>
</template>

<script>
export default {
    computed: {
        contentsString() {
            return JSON.stringify(this.contents, null, 2);
        },
    },
    data() {
        return {
            contents: null,
        };
    },
    methods: {
        imgClickHandler([e, id, setContent]) {
            setContent(id, 'https://www.google.com.hk/logos/doodles/2017/marie-harels-256th-birthday-5737545781477376-s.png');
        },
    },
};
</script>

<style lang="css">
</style>
