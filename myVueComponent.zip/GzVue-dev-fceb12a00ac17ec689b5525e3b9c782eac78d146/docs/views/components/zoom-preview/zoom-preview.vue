<template lang="pug">
    doc-view(":api"="api")
        doc-example(file="components/zoom-preview/1" title="基本用法")
</template>

<script>
    import api from './api';

    export default {
        data() {
            return {
                api: api
            };
        }
    };
</script>
