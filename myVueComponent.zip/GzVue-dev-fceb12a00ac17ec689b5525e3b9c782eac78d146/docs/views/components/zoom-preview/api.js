export default {
    author: '李丽媛-Vanessa',
    title: 'Zoom Preview',
    props: {
        'zoom-preview': [
            [
                'src',
                'string',
                '/public/img/gz-vue/zoom-preview-default.png',
                '缩略图地址'
            ],
            [
                'previewSrc',
                'string',
                '/public/img/gz-vue/zoom-preview-src.png',
                '预览图地址'
            ],
            [
                'height',
                'number',
                '400',
                '展现高度'
            ],
            [
                'width',
                'number',
                '400',
                '展现宽度'
            ]
        ]
    }
}
