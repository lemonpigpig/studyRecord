<template lang="pug">
doc-view(:api="api")
    doc-example(src="components/rich-text-viewer/demo1",title="富文本展示组件")
    doc-example(src="components/rich-text-viewer/demo",title="富文本Pro展示组件")
</template>

<script>
import api from './api';

export default {
    data() {
        return  {
            api: api,
            example1data: {
            },
            example2data: {
            },
        }
    }
}
</script>
<style lang="stylus">
.border-green
    border-color: green !important

.border-red
    border-color: red !important

.border-blue
    border-color: blue !important

.bg-green
    background-color: RGBA(0, 193, 139, .7) !important

.bg-red
    background-color: RGBA(246, 65, 10, .7) !important

.bg-blue
    background-color: RGBA(0, 112, 156, 1.00) !important

make-cols(columns)
    for column in 1..columns
        .gz-rich-text-col.col-{column}
            width: (100/columns)*column + '%'

.gz-rich-text-pro .gz-rich-text-grid .gz-rich-text-row
    make-cols(10)
</style>
