<template>
    <gz-rich-text-viewer :contents="contents" :nodeClass="nodeClass"></gz-rich-text-viewer>
</template>
<script>
export default {
    data() {
        return {
            nodeClass: {
                img: 'gz-img',
                h1: 'gz-h1',
                h2: 'gz-h2',
                h3: 'gz-h3',
                h4: 'gz-h4',
                h5: 'gz-h5',
                ul: 'gz-ul',
                ol: 'gz-ol',
            },
            contents: [{
                content: "header 1",
                id: 0,
                mode: "1",
                type: "header",
            },
            {
                content: "header 2",
                id: 1,
                mode: "2",
                type: "header",
            },
            {
                content: "header 3",
                id: 2,
                mode: "3",
                type: "header",
            },
            {
                content: "header 4",
                id: 3,
                mode: "4",
                type: "header",
            },
            {
                content: "header 5",
                id: 4,
                mode: "5",
                type: "header",
            },
            {
                content: [
                    "ordered list 1",
                    "ordered list 2",
                    "ordered list 3",
                    "ordered list 4",
                ],
                id: 5,
                mode: "ol",
                type: "list",
            },

            {
                content: [
                    "unordered list 1",
                    "unordered list 2",
                    "unordered list 3",
                ],
                id: 6,
                mode: "ul",
                type: "list",
            },
            {
                content: "https://cn.vuejs.org/images/logo.png",
                id: 7,
                type: "image",
            },
            {
                content: `一大段文字\n\n<>#$%&@#$!@!%\n\n @#$!@#!\n\n包含各种特殊字符\n\nalert('abc')`,
                id: 8,
                type: "paragraph",
            }]
        };
    },
};
</script>
