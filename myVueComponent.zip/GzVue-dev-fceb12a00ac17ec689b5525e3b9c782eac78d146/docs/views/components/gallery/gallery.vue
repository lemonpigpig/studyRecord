<template lang="pug">
    doc-view(":api"="api")
        doc-example(file="components/gallery/1" ":data"="example1data" title="基本用法")
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            example1data: {
                galleryOptions: {
                    columns: 2, // 高度
                },
                galleryItems: [{
                    imageUrl: 'http://t.cn/RJY58oV',
                }, {
                    imageUrl: 'http://t.cn/RJQ8FOt',
                }, {
                    imageUrl: 'http://t.cn/RJQRAkZ',
                }, {
                    imageUrl: 'http://t.cn/RJQRGZg',
                }, {
                    imageUrl: 'http://t.cn/RJQRIwW',
                }],
            },
            api: api
        }
    }
}
</script>