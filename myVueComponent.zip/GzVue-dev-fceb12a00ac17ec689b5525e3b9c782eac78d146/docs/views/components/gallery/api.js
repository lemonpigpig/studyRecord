export default {
    author: '邓斌-Bean',
    title: 'Gallery',
    description: '相册组件',
    props: {
        'galleryOptions': [
            [
                'columns',
                'number',
                '2',
                '瀑布流列数（目前没做成可配置，只能是2列，未来再更新）'
            ],
        ],
        'galleryItems': [
            [
                'imageUrl',
                'object',
                '-',
                '图片地址'
            ]
        ]
    }
}