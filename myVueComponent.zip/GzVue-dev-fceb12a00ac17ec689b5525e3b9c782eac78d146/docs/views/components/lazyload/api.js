export default {
    title: 'LOADING',
    description: '加载组件',
    author: '贺贤娟-lemon',
    props: {
        'gz-lazyload': [
            [
                'preLoad',
                'Number',
                '1.3',
                '预加载高度'
            ],
            [
                'error',
                'String',
                'data-src',
                '懒加载失败后图片显示读取的字段'
            ],
            [
                'attempt',
                'Number',
                '3',
                '与加载图片的数量'
            ],
            [
                'listenEvents',
                'Array',
                "['scroll', 'wheel', 'mousewheel', 'resize', 'animationend', 'transitionend', 'touchmove']",
                '监听的事件'
            ],
            [
                'adapter',
                'Oject',
                "{}",
                '设置需要自动更新的元素属性'
            ],
            [
                'filter',
                'Oject',
                "{}",
                '图片过滤器'
            ],
            [
                'lazyComponent',
                'Boolean',
                "false",
                '是否懒加载组件'
            ],

        ]
    },
    slots: {
        'gz-loading': [
            [
                'title',
                '<div class="loding-txt" v-text="title" v-if="title"></div>'
            ]
        ]
    }
}
