<template>
<div>
    <div @click="showPicker()">click show  picker and set default value by value</div>
    <gz-picker :slots="slots" :showToolbar="true" :itemHeight="138" v-model="value" @confirm="confirm" ref="picker" v-if="show"></gz-picker>
</div>
</template>
<script>
export default {
    data() {
        return {
            slots: [{
               values: ['白菜','萝卜','西红柿'],
               className: 'slot1',
               textAlign: 'center'
            }],
            value: '萝卜',
            show: false
        }
    },
    methods: {
        showPicker() {
            this.show = true;
        },
        confirm(val) {
            alert('您选中的值为:'+ val);
            this.$refs.picker.hideMask();
            this.show = false;
           console.log(val);
        },
        cancel(value) {
            this.$refs.picker.hideMask();
            this.show = false;
            alert('cancel');
        },
         showPicker (){
            this.show = true;
         }
    }
}
</script>

