<template>
<div>
    <div @click="showPicker()">click show  picker and set default value by value</div>
    <gz-picker :slots="slots" :showToolbar="true" v-model="value" :col="2" :itemHeight="138"
                @cancel="cancel" @confirm="confirm" ref="picker" v-if="show"></gz-picker>
</div>
</template>
<script>
export default {
    data() {
        return {
            slots: [{
                flex: 1,
                values: ['1', '2', '3', '4', '5', '6'],
                className: 'slot1',
                textAlign: 'right'
            }, {
                divider: true,
                content: '-',
                className: 'slot2'
            }, {
                flex: 1,
                values: ['1', '2', '3', '4', '5', '6'],
                className: 'slot3',
                textAlign: 'left'
            }],
            value: '2-1',
            show: false
        }
    },
    methods: {
        showPicker() {
            this.show = true;
        },
        confirm(value) {
            alert(value);
            this.$refs.picker.hideMask();
            this.show = false;

        },
        cancel(value) {
            alert(value);
            this.$refs.picker.hideMask();
            this.show = false;
        },
        showPicker (){
            this.show = true;
        }
    }
}
</script>
