export default {
  title: 'DATETIME-PICKER',
  description: '日期选择控件',
  author: '贺贤娟-lemon',
  props: {
    'gz-datetime-picker': [
      [
        'value',
        'Date / String',
        '-',
        '绑定值'
      ],
      [
        'type',
        'String',
        'datetime',
        '组件的类型,可选值("datetime", "date", "time")'
      ],
      [
        'cancelText',
        'String',
        '取消',
        '取消按钮文本'
      ],
      [
        'confirmText',
        'String',
        '确定',
        '确定按钮文本'
      ],
      [
        'startDate',
        'Date',
        '十年前的 1 月 1 日',
        '日期的最小可选值'
      ],
      [
        'endDate',
        'Date',
        '十年后的 12 月 31 日',
        '日期的最大可选值'
      ],
      [
        'startHour',
        'Number',
        '0',
        '小时的最小可选值	'
      ],
      [
        'endHour',
        'Number',
        '23',
        '小时的最大可选值	'
      ],
      [
        'yearFormat',
        'String',
        '{value}',
        '年份模板	'
      ],
      [
        'monthFormat',
        'String',
        '{value}',
        '月份模板	'
      ],
      [
        'dateFormat',
        'String',
        '{value}',
        '日期模板		'
      ],
      [
        'hourFormat',
        'String',
        '{value}',
        '小时模板		'
      ],
      [
        'minuteFormat',
        'String',
        '{value}',
        '分钟模板'
      ],
      [
        'showToolbar',
        'Boolean',
        'true',
        '是否显示工具栏'
      ],
    ]
  },
  slots:{
    'picker-slot':[
      [
        'values',
        'Array',
        '-',
        '备选项'
      ],
      [
        'defaultIndex',
        'Number',
        '0',
        '初始选中值'
      ],
      [
        'textAlign',
        'String',
        'center',
        '该 slot 的对齐方式,可选择(center,left,right)'
      ],
      [
        'className',
        'String',
        '-',
        '该 slot 的特殊 CSS'
      ],
      [
        'flex',
        'Number',
        '1',
        '该 slot CSS 的 flex 值'
      ],
      [
        'divider',
        'Boolean',
        'false',
        '该 slot 是否是分割符'
      ],
      [
        'content',
        'String',
        '-',
        '分割符文本'
      ],
      [
        'visible-item-count',
        'Number',
        '7',
        'slot 中可见备选项的个数	会影响组件的高'
      ]
    ]

  },
  functional: {
    'gz-datetime-picker': [
      [
        'confirm',
        '点击确定时的处理函数'
      ],
      [
        'cancel',
        '点击取消时的处理函数'
      ]
    ],
    'picker-slot':[
      [
        'change',
        '当被选中的值发生变化时触发该方法'
      ]

    ]
  }
}
