<template>
    <div>
        <div @click="showPicker()">click show datetime picker and set default value by value</div>
        <gz-datetime-picker
              ref="picker"
              type="date"
              v-model="value"
              year-format="{value} 年"
              month-format="{value} 月"
              date-format="{value} 日"
              :visibleItemCount = "7"
              @confirm="handleChange"
              @cancel="cancel" v-if="show">
        </gz-datetime-picker>
    </div>


</template>

<script>
import moment from 'moment';

export default {
    data() {
        return {
            value: '2020-11-02',
            show: false
        }
    },
    methods:{
      showPicker (){
        this.show = true;
      },
      handleChange (date){
        const datetime = moment(date).format('YYYY-MM-DD');
        this.$refs.picker.hideMask();
        this.show = false;
        alert('seleted datetime:' + datetime);

      },
      cancel (value){
        this.$refs.picker.hideMask();
        this.show = false;
        alert('cancel');
      }
    }
}
</script>
