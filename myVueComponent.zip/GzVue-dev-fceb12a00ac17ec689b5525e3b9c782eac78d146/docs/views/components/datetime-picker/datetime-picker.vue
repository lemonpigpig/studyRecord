<template lang="pug">
  doc-view(":api"="api")
    doc-example(src="components/datetime-picker/1" width="400")
</template>

<script>
import api from './api';

export default {
  data() {
    return  {
      example1data: {
        show: false,
      },
      api: api
    }
  }
}
</script>
