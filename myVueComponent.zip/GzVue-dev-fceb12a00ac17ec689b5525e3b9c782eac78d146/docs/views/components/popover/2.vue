<template>
    <div>
        <div @click="show($event)">
            <gz-icon size="large" icon="unordered-list" class-name="btn"></gz-icon>
        </div>
        <gz-popover :isShow="showPopover" @close="close">
            <ul style="top: 3rem">
                <li @click="showHeart"><gz-icon icon="heart"></gz-icon>Heart</li>
                <li>
                    <gz-icon icon="date"></gz-icon>
                    <router-link to="/components/calendar">calendar</router-link>
                </li>
            </ul>
        </gz-popover>
    </div>
</template>

<script>
    export default {
        data() {
            return {
                showPopover: false
            };
        },
        methods: {
            show(event) {
                this.showPopover = true;
                console.log(event);
            },
            close() {
                this.showPopover = false;
            },
            showHeart() {
                alert('♥️♥️♥️♥️♥️♥️');
            }
        }
    };
</script>
<style lang="stylus" scoped>
    .btn
        cursor: pointer;
        padding: 6px 12px;
        float: right;
</style>
