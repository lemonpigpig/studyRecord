export default {
    author: '李丽媛-Vanessa',
    title: 'Popover - 气泡',
    description: '在点击者某个区域后，浮出一个气泡菜单',
    props: {
        'popover': [
            [
                'isShow',
                'boolean',
                'false',
                '气泡是否显示'
            ],
            [
                'theme',
                'string',
                'white',
                '主题：black | white'
            ]
        ]
    },
    slots: {
        'popover': [
            [
                'default',
                'Default Vue slot'
            ]
        ]
    },
    events: {
        'popover': [
            [
                'close',
                '关闭气泡'
            ]
        ]
    }
}
