<template lang="pug">
    doc-view(":api"="api")
        doc-example(file="components/scroller/1" ":data"="example1data" title="base")
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            example1data: {
                scrollerOptions: {
                    direction: 'horizontal', // 方向，默认'horizontal'横向，'vertical'为纵向
                    height: '250px',
                    width: '100%',
                },
                products: [{
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }, {
                    url: 'http://www.gznb.com/',
                    background: 'http://t.cn/RJY58oV',
                }],
            },
            api: api
        }
    }
}
</script>
