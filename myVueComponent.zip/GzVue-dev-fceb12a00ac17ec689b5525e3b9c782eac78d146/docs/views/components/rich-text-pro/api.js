export default {
    title: 'RichTextPro',
    author: '张锐-Ken',
    description: '富文本编辑组件(更强功能的版本)',
    props: {
        'RichText': [
            [
                'allowTags',
                'Array<String>',
                "['paragraph', 'image', 'header', 'list']",
                '组件允许使用的插件',
            ],
            [
                'tagNames',
                'Object',
                '-',
                '组件中插件的显示名称, 举例: { paragraph: "段落", image: "图片", header: "标题", list: "列表" }',
            ],
            [
                'defaultGridData',
                'Object',
                "{ gridData: null, gridColumn: 12 }",
                '组件的初始数据, 至少包含 gridData(Array) 与 gridColumn(Number)',
            ],
            [
                'allowClasses',
                'Array<Object>',
                '-',
                '组件中允许自由选择的class, 举例: [{ tag: "class-1", displayName: "第一种样式" }]'
            ]
        ]
    },
    events: {
        'RichText': [
            [
                'input',
                'contents:Object',
                '用户的任何操作都会触发input事件',
            ],
            [
                'img-click',
                'e: 点击事件Event, \n id: contents 中的数据块标识, \n setContent(id, imgUrl): 设置当前 img 元素 content 的回调方法',
                '点击图片标签中的图片触发事件',
            ]
        ]
    },
};
