<template lang="html">
    <div class="gz-rich-text-pro-demo">
        <gz-rich-text-pro
            @img-click="imgClickHandler"
            @grid-column-change="gridColumnChangeHandler"
            :allowClasses="allowClasses"
            :defaultGridData="contents"
            :imgLinkTypes="imgLinkTypes"
            v-model="contents">
        </gz-rich-text-pro>
        <pre><code>{{contentsString}}</code></pre>
    </div>
</template>
<script>
export default {
    computed: {
        contentsString() {
            return JSON.stringify(this.contents, null, 2);
        },
    },
    data() {
        return {
            contents: {
                gridData: null,
                gridColumn: 10
            },
            imgLinkTypes: [{
                value: 'URL',
                name: 'URL'
            }, {
                value: 'someID',
                name: '什么ID'
            }],
            allowClasses: [{
                tag: 'border-green',
                displayName: '绿色边框'
            }, {
                tag: 'border-red',
                displayName: '红色边框'
            }, {
                tag: 'border-blue',
                displayName: '蓝色边框'
            }, {
                tag: 'bg-green',
                displayName: '绿色背景'
            }, {
                tag: 'bg-red',
                displayName: '红色背景'
            }, {
                tag: 'bg-blue',
                displayName: '蓝色背景'
            }]
        };
    },
    methods: {
        imgClickHandler([e, id, setContent]) {
            setContent(id, 'https://www.google.com.hk/logos/doodles/2017/marie-harels-256th-birthday-5737545781477376-s.png');
        },
        gridColumnChangeHandler([value, confirm]) {
            console.log(value, confirm);
            confirm(value);
        }
    },
};
</script>

<style lang="stylus">
.border-green
    border-color: green !important

.border-red
    border-color: red !important

.border-blue
    border-color: blue !important

.bg-green
    background-color: RGBA(0, 193, 139, .7) !important

.bg-red
    background-color: RGBA(246, 65, 10, .7) !important

.bg-blue
    background-color: RGBA(0, 112, 156, 1.00) !important

</style>
