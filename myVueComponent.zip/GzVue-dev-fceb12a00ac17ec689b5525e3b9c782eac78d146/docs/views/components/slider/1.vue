<template>
    <div>
        <gz-slider :options="sliderOptions"
                   :items="sliderItems"
                   @customClick="customClick"></gz-slider>
    </div>
</template>

<script>
export default {
    data() {
        return {
            sliderOptions: {
                height: '400px', // 高度
                width: '100%', // 宽度
                showPreNextButton: false, // 是否显示上一页、下一页
                showPagination: true, // 是否显示下方页码
                autoplay: 2500, // 自动播放间隔，false为不自动播放
                direction: 'horizontal', // 方向，默认'horizontal'横向，'vertical'为纵向
                lazyLoading: true,
            },
            sliderItems: [{
                url: 'http://www.gznb.com/',
                background: 'http://t.cn/RJY58oV',
                customClickData: {
                    name: 'test'
                },
            }, {
                url: 'http://www.gznb.com/',
                background: 'http://t.cn/RJQ8FOt',
            }, {
                url: 'http://www.gznb.com/',
                background: 'http://t.cn/RJQRAkZ',
            }, {
                url: 'http://www.gznb.com/',
                background: 'http://t.cn/RJQRGZg',
            }, {
                url: 'http://www.gznb.com/',
                background: 'http://t.cn/RJQRIwW',
            }],
        }
    },
    methods: {
        customClick(data) {
            console.log(data);
        }
    }
}
</script>
