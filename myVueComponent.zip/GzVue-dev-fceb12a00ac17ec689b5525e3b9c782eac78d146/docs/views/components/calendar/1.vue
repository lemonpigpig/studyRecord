<template>
    <gz-calendar
        :chooseDateType="chooseDateType"
        :availableStartDate="availableStartDate"
        :availableDaysCount="availableDaysCount"
        :initStartDate="initStartDate"
        :initEndDate="initEndDate"
        :startDateLabel="startDateLabel"
        :endDateLabel="endDateLabel"
    ></gz-calendar>
</template>

<script>
import moment from 'moment';

export default {
    data() {
        return {
            chooseDateType: 0,
            availableStartDate: moment().add(5, 'day').format('YYYY-MM-DD'),
            availableDaysCount: 15,
            initStartDate: moment().add(5, 'day').format('YYYY-MM-DD'),
            initEndDate: moment().add(11, 'day').format('YYYY-MM-DD'),
            startDateLabel: '取车',
            endDateLabel: '还车'
        }
    }
}
</script>