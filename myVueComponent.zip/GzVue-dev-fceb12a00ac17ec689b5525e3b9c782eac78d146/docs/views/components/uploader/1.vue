<template>
    <div class="uploader-area">
        <div class="uploader-wrapper"
             v-for="picture in pictures"
             v-if="!picture.deleted">
            <gz-uploader-progress :index="picture.index"
                                  :dataURL="picture.dataURL"
                                  :isPrimary="picture.index===primaryIndex"
                                  :serverUrl="picture.serverUrl"
                                  @done="uploadDone"
                                  @error="uploadError"
                                  @abort="uploadAbort"
                                  @delete="deletePicture"
                                  @setPrimary="setPrimary"></gz-uploader-progress>
        </div>
        <div class="uploader-wrapper">
            <gz-uploader :multiple="true"
                         :inputType="0"
                         @select="fileSelected"></gz-uploader>
        </div>
    </div>
</template>

<script>
import GzUploaderProgress from '../../../../src/components/uploader/uploader-progress.vue';

export default {
    components: {
        [GzUploaderProgress.name]: GzUploaderProgress,
    },
    data() {
        return {
            pictures: [],
            primaryIndex: 0,
        }
    },
    methods: {
        fileSelected(files) {
            let currentLength = this.pictures.length;
            for (var i = 0; i < files.length; i++) {
                this.pictures.push({
                    index: i + currentLength,
                    dataURL: files[i],
                    serverUrl: 'http://10.66.1.113:8888/b2b/eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJidWNrZXQiOiJiMmIiLCJleHAiOjE0OTQzMDAyMDR9.MEzfFO73P4TIfo86IrjDLXf80h9aY0fwsklS_9pzGoUUu8j_rHo4W8VMgFOm_xQH2n9u5Yxuk2SmfRWZDKk-eQ',
                });
            }
        },
        uploadDone(data) {
            this.pictures[data.index].url = data.url;
            console.log(this.pictures);
        },
        uploadError(data) {
            console.log('upload error', data);
        },
        uploadAbort(data) {
            console.log('upload abort', data);
        },
        setPrimary(index) {
            this.$set(this, 'primaryIndex', index);
        },
        deletePicture(index) {
            this.pictures[index].deleted = true;
            this.$set(this.pictures, index, this.pictures[index]);
        },
    },
};
</script>

<style lang="less">
.uploader-area {
    display: flex;
    flex-wrap: wrap;
}

.uploader-wrapper {
    width: 100px;
    height: 100px;
    padding: 10px;
}
</style>
