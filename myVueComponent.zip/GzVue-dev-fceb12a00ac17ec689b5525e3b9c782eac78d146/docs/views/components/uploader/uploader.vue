<template lang="pug">
    doc-view(":api"="api")
        doc-example(src="components/uploader/1" width="320" title="demo")
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            api: api
        };
    },
};
</script>
