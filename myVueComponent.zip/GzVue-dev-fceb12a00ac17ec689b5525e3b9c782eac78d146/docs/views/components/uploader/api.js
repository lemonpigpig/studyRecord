export default {
    author: '邓斌-Bean',
    title: 'Uploader',
    description: '上传组件',
    props: {
        'gz-uploader': [
            [
                'inputType',
                'number',
                '0',
                '0: input file上传; 1: app上传'
            ],
        ]
    },
}
