<template lang="pug">
    .form
        .container(v-loading.mask.two="isLoading" loading-text="拼命加载中")
        button(@click='loaded') 关闭加载
</template>

<script>
    export default {
        data() {
            return {
                isLoading: true
            };
        },
        methods: {
            loaded() {
                this.isLoading = false;
            }
        }
    };
</script>
<style lang="stylus" scoped>
    @import "../../../stylus/_theme-sky";

    .form
        padding 10px

        .container
            height: 300px;
            background-color: aliceblue;
            margin-bottom: 10px;

        button
            cursor: pointer;
            color: #fff;
            border-radius: 3px;
            padding: 6px 12px;
            background-color: $theme.primary.base;
            width: 100%;
            line-height: 20px;
            white-space: nowrap;
            border: 0;
            margin-bottom: 10px;
</style>
