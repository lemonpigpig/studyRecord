export default {
    title: 'v-loaoding',
    description: '加载数据时显示的动画效果',
    author: '李丽媛-Vanessa',
    props: {
        'modifiers': [
            [
                'mask',
                'boolean',
                'false',
                '遮罩是否有背景色'
            ],
            [
                'fullscreen',
                'boolean',
                'false',
                'loading 是否为全屏范围'
            ],
            [
                'two',
                'boolean',
                'false',
                '加载动画为 2 个点'
            ],
            [
                'three',
                'boolean',
                'false',
                '加载动画为 3 个点'
            ]
        ],
        'value': [
            [
                '',
                'boolean',
                'false',
                '加载是否显示'
            ]
        ],
        'attribute': [
            [
                'loading-text',
                'string',
                '',
                '加载文本'
            ]
        ]
    }
}
