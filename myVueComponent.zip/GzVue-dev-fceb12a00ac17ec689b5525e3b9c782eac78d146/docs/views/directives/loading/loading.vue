<template lang="pug">
    doc-view(":api"="api")
        doc-example(src="directives/loading/1" title="默认" width="320")
        doc-example(src="directives/loading/2" title="含背景色" width="320")
        doc-example(src="directives/loading/3" title="全屏无文字加载" width="320")
</template>

<script>
import api from './api';

export default {
    data() {
        return {
            api: api,
            isLoading: true
        };
    }
};
</script>
