<template lang="pug">
  doc-black
    doc-header Quick Start
      span(slot="desc") 带你上路，带你飞
    section.section__body
      h2.section__title 新手向导
      h3.section__h3 yarn add
      doc-code(":code"="version" lang="bash")
      h3.section__h3 import
      h4 app.js
      br
      doc-code.
        // 引入组件
        import GzVue from 'gz-vue';
        // 使用插件
        Vue.use(GzVue);
      h4 webpack
      br
      doc-code.
        entry: {
          vendor: [
            'gz-vue/dist/style[2rem].css',    // 使用了 px2rem 的项目需引入 style2rem.css，否则引入 style.css 即可
          ]
    section.section__body
      h2.section__title 相关指南
      .gz-content.section__content
        ul
          li
            a(href="http://10.66.2.13/FrontEndTeam/Standard/blob/master/%E7%AE%80%E5%8C%96%E7%89%88git-flow%E5%92%8Cgit-rebase.md" target="_blank") git-flow
          li
            a(href="http://10.66.2.13/FrontEndTeam/Standard/blob/master/RESTful-API%E8%A7%84%E8%8C%83.md" target="_blank") RESTful-API 规范
          li
            a(href="http://10.66.2.13/FrontEndTeam/Standard/blob/master/vue-components-guide.md" target="_blank") Vue 项目 CodeReview 指南
          li
            a(href="http://10.66.2.13/FrontEndTeam/GzVue/tree/vanessa-doc/public/specification/theme.md" target="_blank") Theme 指南
          li
            a(href="http://10.66.2.13/FrontEndTeam/GzVue/tree/vanessa-doc/public/specification/css.md" target="_blank") CSS 指南
          li
            a(href="http://10.66.2.13/FrontEndTeam/GzVue/tree/vanessa-doc/public/specification/interaction-design.md" target="_blank") 交互概要
          li
            a(href="http://10.66.2.13/FrontEndTeam/GzVue/tree/vanessa-doc/public/specification/config-center.md" target="_blank") 配置中心
    section.section__body
      h2.section__title 联系我们
      .gz-content.section__content
        ul
          li 如果你在使用中遇到了困难，我们会及时给予支持
          li 如果你在使用中遇到了 bug，我们会第一时间进行解决
          li 如果你发现组件中没有你想要的，请邮件我们。尽快采取答复与支持
          li 如果你有更好的解决方式，请告知我们。一经采纳将"载入史册"
          li 如果你想提供组件，请联系我们。真诚期待你的加入
        div.fn-right
          p Email: liliyuan@gznb.com
          p 微信 & Tel: 188687156220
          p QQ: 84588990
    section.section__body
      h2.section__title 基本使用
      .gz-content.section__content
      h3.section__h3 更新
      doc-code yarn
      h3.section__h3 校验
      doc-code todo
      h3.section__h3 测试
      doc-code todo
      h3.section__h3 运行
      doc-code npm run dev
      h3.section__h3 自动生成 Doc
      doc-code npm run gen:doc
      h3.section__h3 发布
      .gz-content.section__content
        ol
          li 修改&nbsp;
            code package.json
            | &nbsp;中的版本号&nbsp;
            code x.x.x
            |，遵循
            a(href="https://github.com/mojombo/semver/blob/master/semver.md" target="_blank") Semantic Versioning 2.0.0
          li
            code npm run build
          li 提交&nbsp;
            code release
            | &nbsp;分支
          li 根据版本号从&nbsp;
            code release
            | &nbsp;分支打一个 tag
    section.section__body
      h2.section__title 创建 Doc & Example
      .gz-content.section__content
        ol
          li 到&nbsp;
            code ./docs/views/components
            | &nbsp;或&nbsp;
            code ./docs/views/directives
            | &nbsp;目录下根据组件名称&nbsp;
            code xx[-xx]
            | &nbsp;创建目录及对应的&nbsp;
            code xx[-xx].vue
            | ,&nbsp;
            code api.js
            | ,&nbsp;
            code x.html
            | &nbsp;或&nbsp;
            code x.vue
            | &nbsp;文件
          li xx[-xx].vue
            doc-code(lang="html").
              &lt;template lang="pug"&gt;
                doc-view(":api"="api")
                // 只需要 render template 和数据处理时可使用 html 引入方式。如下 alert.html 示例
                doc-example(file="components/alert/2" ":data"="exampleData" title="title")
                // 需要使用 script 或 iframe 隔离时可使用 vue 引入方式。如下 calendar.vue 示例
                // width 可设置 example 宽度，设置后将出现宽度选择按钮
                doc-example(src="components/alert/1"" width="320" title="base")
              &lt;/template&gt;
              &lt;script&gt;
                import api from './api';

                export default {
                  data() {
                    return  {
                      exampleData: {
                        alert: false,
                      },
                      api: api
                    }
                  }
                }
              &lt;/script&gt;
          li api.js
            doc-code.
              export default {
                author: '李丽媛-Vanessa; 中文名-英文名',
                title: '组件名称',
                description: '组件描述.',
                props: {
                  '组件／子组件名称（可写多个）': [
                    [
                      '参数',
                      '类型',
                      '默认值（无使用减号代替）',
                      '描述'
                    ],
                  ]
                },
                slots: {
                  '组件／子组件名称（可写多个）': [
                    [
                      '名称',
                      '描述'
                    ]
                  ]
                },
                events: {
                  '组件／子组件名称（可写多个）': [
                    [
                      '名称',
                      '参数',
                      '描述'
                    ]
                  ]
                },
                functional: {
                  '组件／子组件名称（可写多个）': [
                    [
                      '名称',
                      '类名'
                    ]
                  ]
                }
              }
          li x.html/vue [Demo & Code]
            doc-code.
              // alert.html
              &lt;div&gt;
                &lt;gz-alert :show="alert" leftButtonText="取消" rightButtonText="确定"
                          @leftButtonClick="alert = false" @rightButtonClick="alert = false"&gt;
                  &lt;h2&gt;确认删除该地址？&lt;/h2&gt;
                &lt;/gz-alert&gt;
                &lt;button @click="alert = true"&gt;Show Alert&lt;/button&gt;
              &lt;/div&gt;
            doc-code.
              // calendar.vue
              &lt;template&gt;
                  &lt;gz-calendar&gt;
                      ":chooseDateType"="chooseDateType"
                      ":availableStartDate"="availableStartDate"
                      ":availableDaysCount"="availableDaysCount"
                      ":initStartDate"="initStartDate"
                      ":initEndDate"="initEndDate"
                      ":startDateLabel"="startDateLabel"
                      ":endDateLabel"="endDateLabel"&gt;&lt;/gz-calendar&gt;
              &lt;/template&gt;
              &lt;script&gt;
                  import moment from 'moment';

                  export default {
                      data() {
                          return {
                              chooseDateType: 0,
                              availableStartDate: moment().add(5, 'day').format('YYYY-MM-DD'),
                              availableDaysCount: 15,
                              initStartDate: moment().add(5, 'day').format('YYYY-MM-DD'),
                              initEndDate: moment().add(11, 'day').format('YYYY-MM-DD'),
                              startDateLabel: '取车',
                              endDateLabel: '还车'
                          }
                      }
                  }
              &lt;/script&gt;
        p
          code 注
          | &nbsp;后期我们会自动化生成对应的目录和文件，目前还请大家多多见谅
</template>
<script>
    import packageInfo from '../../package.json';

    export default {
        data() {
            return  {
                version: 'yarn add git+http://10.66.2.13/FrontEndTeam/GzVue.git#dev'
            }
        },
        mounted() {
            this.version = `yarn add git+http://10.66.2.13/FrontEndTeam/GzVue.git#${packageInfo.version}`;
        }
    }
</script>
