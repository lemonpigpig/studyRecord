import Directives from './directives';
import Components from './components';
import Notify from './components/notify';
import Toast from './components/toast';
import setDPR from './utilities/dpr';

require('./stylus/main.styl'); // eslint-disable-line global-require

function plugin(_vue, options) {
    const Vue = _vue;

    // add gzvue options
    if (typeof options !== 'undefined') {
        /*
         * auto dpr
         */
        if (typeof window !== 'undefined' && options.autoDpr) {
            window.addEventListener('load', () => {
                const imgs = document.querySelectorAll('img');
                for (let i = 0; i < imgs.length; i += 1) {
                    setDPR(imgs[i]);
                }
            });
        }
    }

    // register directives
    Object.keys(Directives).forEach((key) => {
        Vue.directive(key.replace(/^[A-Z]/, k => k.toLowerCase()), Directives[key]);
    });

    // register components
    Object.keys(Components).forEach((key) => {
        Vue.use(Components[key]);
    });

    Vue.prototype.$notify = Notify;
    Vue.prototype.$toast = Toast;
}

if (typeof window !== 'undefined' && window.Vue) {
    window.Vue.use(plugin);
}

export default plugin;
