import Vue from 'vue';
import url from 'url';

if (!Vue.prototype.$isServer) {
    require('../../utilities/gz-native.js');   // eslint-disable-line global-require
}

export default {
    inserted: (el) => {
        const jumpUrl = el.dataset.url;
        el.addEventListener('click', () => {
            if (jumpUrl) {
                const host = jumpUrl ? url.parse(jumpUrl).host : '';
                if (host) {
                    global.gzNative.openUrl({
                        url: jumpUrl
                    });
                    // console.log(jumpUrl, '调用gz-native');
                }
            }
        });
    },
    bind() {
        // console.log('bind');
    },
    componentUpdated() {
        // console.log('componentUpdated');
    }
};
