import setDPR from '../../utilities/dpr';

export default {
    bind(el) {
        setDPR(el);
    }
};
