import ExternalLink from './external-link/external-link';
import Dpr from './dpr/dpr';
import Loading from './loading/loading';

export default {
    ExternalLink,
    Dpr,
    Loading
};
