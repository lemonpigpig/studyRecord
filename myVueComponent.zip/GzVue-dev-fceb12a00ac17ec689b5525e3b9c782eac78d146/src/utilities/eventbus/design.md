

目的：
- 解决是事件名重复
- 优化事件名 （{id}_gz，{id}_v_gz）
- 追踪事件绑定

方法
- register（event_name, is_vuex）

- on

- off

- once

- print("")
