
## 调用方法

    //image: HTMLDocument
    //quality: 质量
    //size_ratio: 图像的比例
    //output_type: 默认为image／png，值为content type
    compress(image, quality, size_ratio, output_type)
