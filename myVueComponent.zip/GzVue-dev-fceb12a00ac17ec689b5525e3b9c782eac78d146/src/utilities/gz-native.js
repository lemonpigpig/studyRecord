(function (global) {
    var callbacks = {};
    var events = {};

    var index = 0;
    global.gzNative = {
        __nativeCall: function (id, error, param) {
            var callback = callbacks[id];
            delete callbacks[id];
            if (typeof callback === 'function') {
                callback(error, param);
            }
        },
        __callNative: function (name, param, callback) {
            if (typeof callback === 'function') {
                index++;
                callbacks[index] = callback;
            }

            var newParam = JSON.stringify({
                name: name,
                callbackId: typeof callback === 'function' ? index : -1,
                param: param
            });

            if (global.__gzAndroid) {
                global.__gzAndroid.postMessage(newParam)

            } else if (global.webkit) {
                window.webkit.messageHandlers.gziOS.postMessage(newParam);
            }
        },
        __onEvent: function (name, handler) {
            if (name && handler && typeof handler == 'function') {
                var list = events[name] || (events[name] = []);
                list.push(handler);
            }
        },
        __clearEvent: function (name) {
            if (name) {
                delete events[name]
            }
        },
        __fireEvent: function (name, event) {
            var list = events[name];
            if (list) {
                list.forEach(function (func) {
                    func(event)
                });
            }
        },
        on: function (name, handler) {
            gzNative.__onEvent(name, handler)
        },
        off: function (name) {
            gzNative.__clearEvent(name);
        }
    };

    function addApis() {
        Array.prototype.slice.apply(arguments).forEach(function (method) {
            global.gzNative[method] = function (callParam) {
                return new Promise(function (res, rej) {
                    global.gzNative.__callNative(method, callParam, function (error, result) {
                        if (error !== null) {
                            rej({
                                error: error,
                                result: result
                            });
                        } else {
                            res(result);
                        }
                    });
                });
            };
        });
    }

    addApis('wechatPay', 'aliPay', 'getGeolocation', 'openLocationSetting', 'selectPhoto', 'selectMultiplePhotos', 'openUrl', 'appVersion', 'socialShare',
        'logEnterPage', 'logExitPage', 'logSignIn', 'logSignOut', 'logEvent'
    );
})(window);
