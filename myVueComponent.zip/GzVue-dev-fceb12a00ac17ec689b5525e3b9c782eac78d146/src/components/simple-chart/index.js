import GzSimpleChart from './component.vue';

GzSimpleChart.install = (Vue) => {
    Vue.component(GzSimpleChart.name, GzSimpleChart);
};

export default GzSimpleChart;
