import GzRichTextPro from './core';

GzRichTextPro.install = (Vue) => {
    Vue.component(GzRichTextPro.name, GzRichTextPro);
};

export default GzRichTextPro;
