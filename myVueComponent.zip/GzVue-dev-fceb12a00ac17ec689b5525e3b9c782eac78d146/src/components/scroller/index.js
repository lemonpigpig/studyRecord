import GzScroller from './scroller.vue';

GzScroller.install = (Vue) => {
    Vue.component(GzScroller.name, GzScroller);
};

export default GzScroller;
