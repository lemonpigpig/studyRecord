import GzMask from './mask.vue';

GzMask.install = (Vue) => {
    Vue.component(GzMask.name, GzMask);
};

export default GzMask;
