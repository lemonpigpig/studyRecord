import GzPicker from './picker.vue';

GzPicker.install = (Vue) => {
    Vue.component(GzPicker.name, GzPicker);
};

export default GzPicker;
