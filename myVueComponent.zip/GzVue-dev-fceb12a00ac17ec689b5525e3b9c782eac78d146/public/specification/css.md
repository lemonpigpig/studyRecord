# GZ Vue

**仅**针对组件样式进行约定。

## 目录结构

```
src/stylus/
|- components/
|  |- _alert.styl
|  |- _icon.styl
|  |- ...
|- base/
|  |- _global-reset.styl    
|  |- _content.styl   
|  |- _theme[-name].styl
|  |- _tools.styl
|  |- _variables.styl
|- mixin.styl
|  |- _retina.styl
|  |- ...
|- main.styl
```

## 说明

* 组件样式和 .vue 文件进行分离
* components 使用 BEM
* components 带上前缀 `gz-`
* icon 封装为组件
* base/_global-reset.styl 重置浏览器默认样式
* base/_content.styl 文章排版, class 为 `gz-content`
* base/_theme[-name].styl, base/_variables.styl 参见 [主题设计](theme.md)
* base/tools.styl 存放工具类型样式，前缀 `fn-`。如：ellipsis, clear, hidden, left, right... 
* mixin 存放 mixin
* main.styl 用于 import 

## 规约

* 通用样式禁止使用 `!import`

# 项目

## 目录结构

由于组件和项目的特殊性，需要进行区分。不强行使用 BEM。

```
stylus/
|- layout/
|  |- _layout.styl
|- module/
|  |- header.styl
|  |- ...
|- reset/
|- application.styl
```

## 说明

* layout 使用前缀 `.l-`
* modules 中存放可重复使用，模块化的元素
* modules 建议采用 OOCSS：分离结构与主题，分离容器与内容
* reset 用于重置组件样式
* 样式仅在唯一的 .vue 中进行使用时，可以使用 `<style type="styl" scoped>` 单独写到 .vue 文件中
* application.styl 用于 import 样式

# 规范

## 格式化

* 文件使用无 BOM 的 UTF-8 编码
* 当一个 rule 包含多个 selector 时，每个选择器声明必须独占一行
* `>`, `+`, `~` 选择器的两边各保留一个空格
* 每一个属性定义做为一行

## 通用

* 选择器的嵌套层级应不大于 3 级，位置靠后的限定条件应尽可能精确
* 当数值为 0 - 1 之间的小数时，省略整数部分的 0
* 长度为 0 时须省略单位
* 颜色值可以缩写时，必须使用缩写形式
* 颜色值中的英文字符采用小写
* font-weight 属性必须使用数值方式描述
* 使用 transition 时应指定 transition-property
* Media Query 不得单独编排，必须与相关的规则一起定义
* Media Query 如果有多个逗号分隔的条件时，应将每个条件放在单独一行中
* 禁止使用 Expression
* 除非需要，否则不要在 id 或 class 前加元素名
* class 选择器中使用连字符
* 用注释把 CSS 分成各个部分
* 属性选择器中的值必须用单引号包围
* URI 的值不需要引号
* font-family 属性中的字体族名称应使用字体的英文 Family Name，其中如有空格，须放置在引号中

## z-index 范围

* 头部 100 ～ 199
* 浮层 200 ～ 299
* 弹出层 300 ～ 399

`注` 如使用 js 进行全局计算 z-index 时需避免用户手自定义的层被遮住

