const fs = require('fs');
const path = require('path');

// about gen side nav
const genSubSideNav = (dir) => {
    let template = '';
    const files = fs.readdirSync(dir);

    files.forEach((file) => {
        const type = dir.replace('./docs/views/', '');
        template += `      li.nav__li
        router-link(to="/${type}/${file}") ${file}
`;
        console.info(`gen nav: ${type}/${file}`);
    });
    return template;
};

const genSideNav = () => {
    // gen nav
    const components = genSubSideNav('./docs/views/components');
    let template = `<template lang="pug">
  // auto gen
  ul
    li.nav__group(@click="toggleComponent")
      .nav__title Components
    ul(v-if="toggleComponents")
`;


    template += components + `    li.nav__group(@click="toggleDirective")
      .nav__title Directives
    ul(v-if="toggleDirectives")
`;

    const directives = genSubSideNav('./docs/views/directives');

    template += `${directives}</template>
<script>
    export default {
        data() {
            return {
                toggleComponents: false,
                toggleDirectives: false
            };
        },
        mounted() {
            if (this.$route.path.indexOf('/components/') > -1) {
                this.toggleComponents = true;
            }
            if (this.$route.path.indexOf('/directives/') > -1) {
                this.toggleDirectives = true;
            }
        },
        methods: {
            toggleComponent() {
                this.toggleComponents = !this.toggleComponents;
                this.toggleDirectives = !this.toggleComponents;
            },
            toggleDirective() {
                this.toggleDirectives = !this.toggleDirectives;
                this.toggleComponents = !this.toggleDirectives;
            }
        }
    }
</script>`;
    return template;
};

// about gen router
let routerComponents = '';
let routerDirectives = '';
const genRouterDemo = (rootA) => {
    let res = '';
    const root = rootA;
    const files = fs.readdirSync(root);

    files.forEach((file) => {
        const pathURL = `${root}/${file}`;
        const stat = fs.lstatSync(pathURL);

        if (!stat.isDirectory()) {
            const pathInfo = path.parse(pathURL);
            if (pathInfo.ext === '.vue' && pathInfo.base !== 'QuickStart.vue' && pathInfo.base !== 'SubRouter.vue') {
                let routerPath = pathInfo.dir.replace('./docs/views', '');
                const pathSplits = path.dirname(pathURL).split('/');

                // gen demo
                if (pathInfo.name !== pathSplits[pathSplits.length - 1]) {
                    routerPath += `/${pathInfo.name}`;
                    res += `    { path: '${routerPath}', component: require('${pathURL.replace('./docs', '..')}') },
`;
                } else if (routerPath.indexOf('/directives') === 0) {
                    routerDirectives += `    { path: '${routerPath.replace('/directives/', '')}', component: require('${pathURL.replace('./docs', '..')}') },
`;
                } else if (routerPath.indexOf('/components') === 0) {
                    routerComponents += `    { path: '${routerPath.replace('/components/', '')}', component: require('${pathURL.replace('./docs', '..')}') },
`;
                } else {
                    console.info('generate router: this path can not generate router');
                }

                console.info(`generate router:  ${routerPath}`);
            }
        } else {
            res = res.concat(genRouterDemo(pathURL));
        }
    });
    return res;
};

// init
(() => {
    // gen side nav
    fs.writeFileSync('./docs/components/doc-nav.vue', genSideNav(), 'UTF-8');

    // gen router
    const res = genRouterDemo('./docs/views');
    fs.writeFileSync('./docs/router/auto-gen.js', `const demo = [
${res}];
const components = [
${routerComponents}];
const directives = [
${routerDirectives}];
export default {
    demo,
    components,
    directives
};`, 'UTF-8');
})();
