## 波奇七牛CDN上传工具

#### 第一步，在项目根目录配置一个配置文件 cdn.conf.json
```json
/*
*   src_dir: 本地需要上传的静态资源目录  （必选）
*   key_prefix: 七牛服务器的项目目录 （必选）
*   bucket: 七牛的命名空件，（非必选，默认 h5-images ）
*   cdn.conf.json
*   {
*      "src_dir" : "/cdn-images/",  
*      "key_prefix": "anniversary/static/images/",
*      "bucket": "" 
*   }
*/
```

#### 第二步，在package.json 中 加入一个script
"scripts": {
  "cdn": "node ./node_modules/boqii-cdn"
}

#### 第三步，npm run cdn
