const { exec } = require('shelljs')
const fs = require('fs')
const path = require('path')
const colors = require('colors');
colors.setTheme({
  prompt: 'red',
  info: 'green',
  data: 'blue',
  help: 'cyan',
  warn: 'yellow',
  debug: 'magenta',
  error: 'red'
});

function boqiiUploader(config) {
  console.log('>>>>>>>>>>>>>>七牛账号登陆...'.info, config.ak)
  const uploadPath = config.uploadPath;
  exec(`qshell account ${config.ak} ${config.sk}`)
  delete config.uploadPath
  console.log('>>>>>>>>>>>>>>生成七牛配置文件...'.info)
  if( config.delete_previous ){
    console.log('>>>>>>>>>>>>>>清空cdn之前的文件...'.info)
    let previousFolder = config.delete_previous;
    exec(`qshell batchdelete ${config.bucket} ${ uploadPath }`)
    delete config.delete_previous
    console.log('>>>>>>>>>>>>>>清空cdn之前的文件完成'.info)
  }
  fs.writeFile( uploadPath , JSON.stringify(config, null, 2), (err) => {
    if (err) {
      return console.log("error ======".error,err)
    }
    console.log('>>>>>>>>>>>>>>上传至cdn...'.info)
    exec(`qshell qupload 10 ${ uploadPath }`)
    console.log('>>>>>>>>>>>>>>上传成功'.info)
  })
}
module.exports = boqiiUploader


