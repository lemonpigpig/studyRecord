let boqiiUploader = require('./boqii-cdn');
const path = require('path')
let localConf = require('./local.conf.json');
let clientConf = require(path.join( path.resolve(), './cdn.conf.json' ));
if( !clientConf.src_dir ){
  console.error("src_dir can not be empty for uploader config");
  return;
}
if( !clientConf.key_prefix ){
  console.error("key_prefix can not be empty for uploader config");
  return;
}
let uploadConf = Object.assign( {}, localConf, clientConf );
uploadConf.src_dir = path.join( path.resolve(), uploadConf.src_dir );
uploadConf.uploadPath = path.join( path.resolve(), '/boqii.qiniu.json' )
boqiiUploader(uploadConf)